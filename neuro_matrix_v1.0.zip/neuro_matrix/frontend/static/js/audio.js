/* ===== 音频系统 - 程序化音效 ===== */
class AudioSystem {
    constructor() {
        this.ctx = null;
        this.initialized = false;
        this.masterGain = null;
        this.bgmGain = null;
        this.sfxGain = null;
    }

    async init() {
        if (this.initialized) return;
        try {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
            this.masterGain = this.ctx.createGain();
            this.masterGain.gain.value = 0.5;
            this.masterGain.connect(this.ctx.destination);

            this.bgmGain = this.ctx.createGain();
            this.bgmGain.gain.value = 0.3;
            this.bgmGain.connect(this.masterGain);

            this.sfxGain = this.ctx.createGain();
            this.sfxGain.gain.value = 0.6;
            this.sfxGain.connect(this.masterGain);

            this.initialized = true;
        } catch (e) {
            console.warn('Web Audio API not supported');
        }
    }

    // 多巴胺：获得战利品音效 - 清脆的硬币声（C大调）
    playLootSound(quality) {
        if (!this.initialized) return;
        const now = this.ctx.currentTime;

        const notes = {
            'common': [523.25, 659.25],    // C5, E5
            'epic': [523.25, 659.25, 783.99, 1046.50], // C5, E5, G5, C6
            'mythic': [523.25, 659.25, 783.99, 1046.50, 1318.51] // C大调琶音
        };

        const freqs = notes[quality] || notes['common'];

        freqs.forEach((freq, i) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now + i * 0.08);

            gain.gain.setValueAtTime(0.3, now + i * 0.08);
            gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.08 + 0.3);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now + i * 0.08);
            osc.stop(now + i * 0.08 + 0.3);
        });

        // 添加金属质感
        if (quality === 'mythic' || quality === 'epic') {
            const metal = this.ctx.createOscillator();
            const metalGain = this.ctx.createGain();
            metal.type = 'square';
            metal.frequency.setValueAtTime(2000, now);
            metalGain.gain.setValueAtTime(0.05, now);
            metalGain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
            metal.connect(metalGain);
            metalGain.connect(this.sfxGain);
            metal.start(now);
            metal.stop(now + 0.5);
        }
    }

    // 内啡肽：战斗音效
    playCombatSound(type) {
        if (!this.initialized) return;
        const now = this.ctx.currentTime;

        if (type === 'hit') {
            // 打击音效
            const bufferSize = this.ctx.sampleRate * 0.1;
            const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
            const data = buffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.1));
            }
            const source = this.ctx.createBufferSource();
            source.buffer = buffer;
            const gain = this.ctx.createGain();
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
            source.connect(gain);
            gain.connect(this.sfxGain);
            source.start(now);
        } else if (type === 'critical') {
            // 暴击音效 - 高音
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(800, now);
            osc.frequency.exponentialRampToValueAtTime(2000, now + 0.1);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
            osc.connect(gain);
            gain.connect(this.sfxGain);
            osc.start(now);
            osc.stop(now + 0.2);
        } else if (type === 'near-miss') {
            // 濒死音效 - 心跳
            for (let i = 0; i < 3; i++) {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(60, now + i * 0.3);
                gain.gain.setValueAtTime(0.4, now + i * 0.3);
                gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.3 + 0.15);
                osc.connect(gain);
                gain.connect(this.sfxGain);
                osc.start(now + i * 0.3);
                osc.stop(now + i * 0.3 + 0.15);
            }
        } else if (type === 'victory') {
            // 胜利音效 - 神圣空灵
            const freqs = [523.25, 659.25, 783.99, 1046.50, 1318.51, 1567.98];
            freqs.forEach((freq, i) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, now + i * 0.15);
                gain.gain.setValueAtTime(0, now + i * 0.15);
                gain.gain.linearRampToValueAtTime(0.15, now + i * 0.15 + 0.1);
                gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.15 + 1.5);
                osc.connect(gain);
                gain.connect(this.sfxGain);
                osc.start(now + i * 0.15);
                osc.stop(now + i * 0.15 + 1.5);
            });

            // 静音效果
            setTimeout(() => {
                this.masterGain.gain.linearRampToValueAtTime(0.1, this.ctx.currentTime + 0.5);
                setTimeout(() => {
                    this.masterGain.gain.linearRampToValueAtTime(0.5, this.ctx.currentTime + 0.5);
                }, 1500);
            }, 100);
        }
    }

    // 催产素：伴侣互动音效
    playCompanionSound(type) {
        if (!this.initialized) return;
        const now = this.ctx.currentTime;

        if (type === 'talk') {
            // 温柔的铃声
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(880, now);
            osc.frequency.exponentialRampToValueAtTime(1100, now + 0.3);
            gain.gain.setValueAtTime(0.1, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
            osc.connect(gain);
            gain.connect(this.sfxGain);
            osc.start(now);
            osc.stop(now + 0.5);
        } else if (type === 'bond') {
            // 羁绊提升音效
            const freqs = [880, 1100, 1320];
            freqs.forEach((freq, i) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, now + i * 0.1);
                gain.gain.setValueAtTime(0.15, now + i * 0.1);
                gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.1 + 0.4);
                osc.connect(gain);
                gain.connect(this.sfxGain);
                osc.start(now + i * 0.1);
                osc.stop(now + i * 0.1 + 0.4);
            });
        }
    }

    // 探索音效
    playExploreSound(rarity) {
        if (!this.initialized) return;
        const now = this.ctx.currentTime;

        const sounds = {
            'common': () => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(300, now);
                gain.gain.setValueAtTime(0.1, now);
                gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
                osc.connect(gain);
                gain.connect(this.sfxGain);
                osc.start(now);
                osc.stop(now + 0.2);
            },
            'rare': () => {
                const freqs = [440, 554, 659];
                freqs.forEach((freq, i) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, now + i * 0.1);
                    gain.gain.setValueAtTime(0.15, now + i * 0.1);
                    gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.1 + 0.3);
                    osc.connect(gain);
                    gain.connect(this.sfxGain);
                    osc.start(now + i * 0.1);
                    osc.stop(now + i * 0.1 + 0.3);
                });
            },
            'legendary': () => {
                // 史诗级音效
                const freqs = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50];
                freqs.forEach((freq, i) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, now + i * 0.08);
                    gain.gain.setValueAtTime(0, now + i * 0.08);
                    gain.gain.linearRampToValueAtTime(0.12, now + i * 0.08 + 0.05);
                    gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.08 + 0.8);
                    osc.connect(gain);
                    gain.connect(this.sfxGain);
                    osc.start(now + i * 0.08);
                    osc.stop(now + i * 0.08 + 0.8);
                });
            }
        };

        (sounds[rarity] || sounds['common'])();
    }

    // 背景音乐 - 动态生成
    playBGM(mood) {
        if (!this.initialized) return;
        // 简化版：根据心情播放不同频率的drone
        const freqs = {
            'calm': [110, 164.81, 220],
            'tense': [130.81, 155.56, 196],
            'epic': [82.41, 110, 164.81, 220],
            'mystic': [98, 146.83, 196, 293.66]
        };

        const now = this.ctx.currentTime;
        const baseFreqs = freqs[mood] || freqs['calm'];

        baseFreqs.forEach(freq => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now);
            gain.gain.setValueAtTime(0.02, now);
            osc.connect(gain);
            gain.connect(this.bgmGain);
            osc.start(now);
            // 持续播放，需要外部管理停止
        });
    }
}

window.audioSystem = new AudioSystem();
