/* ===== 心智矩阵 - 核心游戏引擎 ===== */
class NeuroMatrix {
    constructor() {
        this.playerId = 'player_' + Math.random().toString(36).substr(2, 9);
        this.ws = null;
        this.canvas = null;
        this.ctx = null;
        this.particleSystem = null;
        this.gameState = null;
        this.currentRoom = null;
        this.enemies = [];
        this.player = { x: 400, y: 300, size: 20, color: '#00d4ff' };
        this.selectedEnemy = null;
        this.actionCount = 0;
        this.lastApmReport = Date.now();
        this.sessionStart = Date.now();
        this.achievementsShown = new Set();
        this.companionBond = 0;
        this.isInCombat = false;
        this.slowMoActive = false;
        this.flowState = 0;

        this.keys = {};
        this.mouse = { x: 0, y: 0 };

        this.init();
    }

    async init() {
        // 初始化音频
        await window.audioSystem.init();

        // 初始化画布
        this.canvas = document.getElementById('game-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.resizeCanvas();

        // 初始化粒子系统
        this.particleSystem = new ParticleSystem('particle-canvas');
        this.particleSystem.resize();
        this.particleSystem.start();

        // 绑定事件
        this.bindEvents();

        // 连接WebSocket
        this.connectWebSocket();

        // 开始游戏循环
        this.gameLoop();

        // 开始APM报告
        setInterval(() => this.reportAPM(), 5000);

        // 开始会话计时器
        setInterval(() => this.updateSessionTime(), 1000);

        // 心跳
        setInterval(() => this.heartbeat(), 3000);

        // 环境粒子生成
        setInterval(() => {
            if (this.currentRoom) {
                this.particleSystem.spawnAmbientParticles(this.currentRoom.type);
            }
        }, 500);

        // 心流粒子
        setInterval(() => {
            if (this.flowState > 0.5) {
                this.particleSystem.spawnFlowParticles();
            }
        }, 200);
    }

    resizeCanvas() {
        const mainArea = document.getElementById('main-area');
        if (mainArea) {
            this.canvas.width = mainArea.clientWidth;
            this.canvas.height = mainArea.clientHeight;
            this.player.x = this.canvas.width / 2;
            this.player.y = this.canvas.height / 2;
        }
    }

    connectWebSocket() {
        const wsUrl = `ws://${window.location.host}/ws/${this.playerId}`;
        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
            console.log('Connected to Neuro-Matrix server');
            this.addLog('系统', '神经连接已建立...', 'system');
        };

        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleServerMessage(data);
        };

        this.ws.onclose = () => {
            console.log('Disconnected, reconnecting...');
            this.addLog('系统', '连接断开，正在重连...', 'system');
            setTimeout(() => this.connectWebSocket(), 3000);
        };

        this.ws.onerror = (err) => {
            console.error('WebSocket error:', err);
        };
    }

    handleServerMessage(data) {
        switch (data.type) {
            case 'init':
                this.gameState = data.player;
                this.updateUI();
                this.addLog('系统', '欢迎来到心智矩阵。你的旅程开始了...', 'system');
                break;

            case 'room_entered':
                this.handleRoomEntered(data);
                break;

            case 'combat_result':
                this.handleCombatResult(data);
                break;

            case 'position_update':
                this.player.x = data.position.x;
                this.player.y = data.position.y;
                break;

            case 'loot_collected':
                this.handleLootCollected(data);
                break;

            case 'companion_response':
                this.handleCompanionResponse(data);
                break;

            case 'status_sync':
                this.gameState = data.player;
                this.updateAchievements(data.achievements);
                this.updateWorldFeedback(data.world);
                this.updateUI();
                break;
        }
    }

    handleRoomEntered(data) {
        this.currentRoom = data.room;
        this.enemies = data.room.enemies || [];

        // 房间过渡动画
        const transition = document.getElementById('room-transition');
        const title = document.getElementById('room-title');
        const desc = document.getElementById('room-desc');
        const rarity = document.getElementById('room-rarity');

        title.textContent = data.room.type === 'legendary' ? '★ 传说领域 ★' :
                           data.room.type === 'rare' ? '✦ 神秘空间 ✦' :
                           data.room.type === 'normal' ? '探索区域' : '普通房间';
        desc.textContent = data.room.description;
        rarity.textContent = data.room.type.toUpperCase();
        rarity.className = 'rarity-badge rarity-' + data.room.type;

        transition.classList.remove('hidden');

        // 播放音效
        window.audioSystem.playExploreSound(data.room.type);

        // 多巴胺爆发
        if (data.dopamine_hit) {
            this.particleSystem.spawnDopamineBurst(this.canvas.width / 2, this.canvas.height / 2);
            this.showDopamineBurst();
        }

        setTimeout(() => {
            transition.classList.add('hidden');
        }, 2000);

        // 更新房间类型显示
        document.getElementById('room-type').textContent = 
            data.room.type === 'legendary' ? '传说领域' :
            data.room.type === 'rare' ? '神秘空间' :
            data.room.type === 'normal' ? '探索区域' : '普通房间';

        document.getElementById('dda-indicator').textContent = `DDA: ${data.dda_multiplier.toFixed(1)}x`;

        // 更新按钮状态
        this.updateCombatButtons();

        this.addLog('探索', `进入了${data.room.description}`, 'dopamine');
    }

    handleCombatResult(data) {
        const result = data.result;

        // 显示伤害数字
        if (result.enemy_damage > 0) {
            this.showDamageText(result.enemy_damage, 'enemy', result.critical);
            this.particleSystem.spawnCombatParticles(
                this.selectedEnemy ? this.selectedEnemy.x : this.canvas.width / 2,
                this.selectedEnemy ? this.selectedEnemy.y : this.canvas.height / 2,
                result.critical ? 'critical' : 'normal'
            );

            if (result.critical) {
                window.audioSystem.playCombatSound('critical');
                document.getElementById('critical-flash').style.opacity = '1';
                setTimeout(() => {
                    document.getElementById('critical-flash').style.opacity = '0';
                }, 100);
            } else {
                window.audioSystem.playCombatSound('hit');
            }
        }

        if (result.player_damage > 0) {
            this.showDamageText(result.player_damage, 'player');

            // Near-Miss效果
            if (result.near_miss) {
                document.getElementById('near-miss-effect').style.opacity = '1';
                document.getElementById('near-miss-effect').textContent = '⚠️ 濒死！';
                window.audioSystem.playCombatSound('near-miss');
                this.addLog('战斗', '★ 濒死反杀！内啡肽大量分泌！', 'endorphin');
                setTimeout(() => {
                    document.getElementById('near-miss-effect').style.opacity = '0';
                }, 1500);
            }
        }

        // 敌人被击败
        if (result.enemy_defeated) {
            this.enemies = this.enemies.filter(e => e.id !== this.selectedEnemy?.id);
            this.selectedEnemy = null;

            // 内啡肽：胜利效果
            if (result.endorphin_rush) {
                window.audioSystem.playCombatSound('victory');
                this.addLog('战斗', `🎉 胜利！获得 ${result.xp_gain} XP`, 'endorphin');

                // 子弹时间效果
                this.activateSlowMo();

                // 显示战利品
                setTimeout(() => {
                    this.showVictoryOverlay(result);
                }, 500);
            }

            // 升级
            if (result.level_up) {
                this.addLog('系统', '⭐ 升级了！力量增强！', 'serotonin');
                this.particleSystem.spawnAchievementParticles(this.canvas.width / 2, this.canvas.height / 2);
            }
        }

        // 更新连击
        document.getElementById('combo-display').textContent = result.combo || 0;

        // 更新游戏状态
        this.gameState = data.player;
        this.updateUI();
        this.updateCombatButtons();
    }

    handleLootCollected(data) {
        const loot = data.loot;

        // 多巴胺音效
        window.audioSystem.playLootSound(loot.quality);

        // 粒子特效
        this.particleSystem.spawnLootParticles(
            this.player.x, this.player.y, loot.quality
        );

        // 更新背包
        this.updateInventory(data.inventory);

        // 日志
        const qualityText = loot.quality === 'mythic' ? '★★★ 神器' :
                           loot.quality === 'epic' ? '★★ 史诗' : '普通';
        this.addLog('战利品', `获得了 ${qualityText} ${loot.name}`, 'dopamine');

        // 多巴胺爆发
        if (data.dopamine_hit) {
            this.showDopamineBurst();
        }
    }

    handleCompanionResponse(data) {
        const modal = document.getElementById('companion-modal');
        const text = document.getElementById('companion-dialogue-text');

        text.textContent = data.response;
        text.style.animation = 'none';
        text.offsetHeight; // 触发重排
        text.style.animation = 'fadeIn 0.5s ease';

        this.companionBond = data.bond;
        this.updateCompanionUI();

        // 催产素光晕
        if (data.oxytocin_trigger) {
            document.getElementById('companion-glow').classList.add('active');
            window.audioSystem.playCompanionSound('bond');
            this.addLog('星灵', '💕 羁绊加深了...', 'oxytocin');
        } else {
            window.audioSystem.playCompanionSound('talk');
        }
    }

    activateSlowMo() {
        this.slowMoActive = true;
        this.canvas.style.filter = 'brightness(1.5) saturate(1.3)';

        setTimeout(() => {
            this.slowMoActive = false;
            this.canvas.style.filter = 'none';
        }, 2000);
    }

    showVictoryOverlay(result) {
        const overlay = document.getElementById('victory-overlay');
        const lootDiv = document.getElementById('victory-loot');

        lootDiv.innerHTML = `
            <div class="victory-xp">+${result.xp_gain} XP</div>
            ${result.level_up ? '<div class="victory-level">⭐ 升级!</div>' : ''}
        `;

        overlay.classList.remove('hidden');

        document.getElementById('victory-continue').onclick = () => {
            overlay.classList.add('hidden');
        };
    }

    showDamageText(damage, type, isCritical = false) {
        const container = document.getElementById('damage-text-container');
        const el = document.createElement('div');
        el.className = `damage-text ${type} ${isCritical ? 'critical' : ''}`;
        el.textContent = isCritical ? `暴击! ${damage}` : `-${damage}`;
        el.style.left = (this.canvas.width / 2 + (Math.random() - 0.5) * 100) + 'px';
        el.style.top = (this.canvas.height / 2 - 50) + 'px';
        container.appendChild(el);

        setTimeout(() => el.remove(), 1000);
    }

    showDopamineBurst() {
        const burst = document.getElementById('dopamine-burst');
        burst.classList.remove('hidden');

        this.particleSystem.spawnDopamineBurst(this.canvas.width / 2, this.canvas.height / 2);

        setTimeout(() => {
            burst.classList.add('hidden');
        }, 1500);
    }

    // 游戏循环
    gameLoop() {
        this.update();
        this.render();
        requestAnimationFrame(() => this.gameLoop());
    }

    update() {
        // 玩家移动
        const speed = this.slowMoActive ? 2 : 5;
        if (this.keys['w'] || this.keys['arrowup']) this.player.y -= speed;
        if (this.keys['s'] || this.keys['arrowdown']) this.player.y += speed;
        if (this.keys['a'] || this.keys['arrowleft']) this.player.x -= speed;
        if (this.keys['d'] || this.keys['arrowright']) this.player.x += speed;

        // 边界限制
        this.player.x = Math.max(20, Math.min(this.canvas.width - 20, this.player.x));
        this.player.y = Math.max(20, Math.min(this.canvas.height - 20, this.player.y));

        // 发送位置更新
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            // 节流位置更新
        }

        // 更新敌人
        this.enemies.forEach(enemy => {
            const dx = this.player.x - enemy.x;
            const dy = this.player.y - enemy.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist > 30) {
                enemy.x += (dx / dist) * enemy.speed * (this.slowMoActive ? 0.3 : 1);
                enemy.y += (dy / dist) * enemy.speed * (this.slowMoActive ? 0.3 : 1);
            }
        });

        // 计算心流状态
        this.calculateFlowState();
    }

    calculateFlowState() {
        // 基于APM和操作流畅度计算心流
        const now = Date.now();
        const timeSinceLastAction = now - this.lastApmReport;

        if (this.actionCount > 10 && timeSinceLastAction < 10000) {
            this.flowState = Math.min(1, this.flowState + 0.01);
        } else {
            this.flowState = Math.max(0, this.flowState - 0.005);
        }
    }

    render() {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // 绘制背景
        if (this.currentRoom) {
            const theme = this.currentRoom.theme;
            ctx.fillStyle = theme.bg || '#0d1b2a';
            ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

            // 绘制网格
            ctx.strokeStyle = 'rgba(255,255,255,0.03)';
            ctx.lineWidth = 1;
            for (let x = 0; x < this.canvas.width; x += 40) {
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x, this.canvas.height);
                ctx.stroke();
            }
            for (let y = 0; y < this.canvas.height; y += 40) {
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(this.canvas.width, y);
                ctx.stroke();
            }
        }

        // 绘制玩家
        ctx.save();
        ctx.translate(this.player.x, this.player.y);

        // 玩家光晕
        const glowSize = 15 + Math.sin(Date.now() / 500) * 5;
        ctx.beginPath();
        ctx.arc(0, 0, glowSize, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0, 212, 255, 0.2)';
        ctx.fill();

        // 玩家本体
        ctx.beginPath();
        ctx.arc(0, 0, 10, 0, Math.PI * 2);
        ctx.fillStyle = this.player.color;
        ctx.shadowColor = this.player.color;
        ctx.shadowBlur = 15;
        ctx.fill();
        ctx.restore();

        // 绘制伴侣（催产素）
        if (this.companionBond > 0) {
            const bondDist = 30 + (1 - this.companionBond) * 50;
            const angle = Date.now() / 2000;
            const companionX = this.player.x + Math.cos(angle) * bondDist;
            const companionY = this.player.y + Math.sin(angle) * bondDist;

            ctx.save();
            ctx.beginPath();
            ctx.arc(companionX, companionY, 8, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 107, 157, ${0.3 + this.companionBond * 0.7})`;
            ctx.shadowColor = '#ff6b9d';
            ctx.shadowBlur = 10 + this.companionBond * 10;
            ctx.fill();

            // 连接线与玩家的线
            ctx.beginPath();
            ctx.moveTo(this.player.x, this.player.y);
            ctx.lineTo(companionX, companionY);
            ctx.strokeStyle = `rgba(255, 107, 157, ${this.companionBond * 0.5})`;
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.restore();

            // 伴侣粒子
            if (Math.random() < 0.1) {
                this.particleSystem.spawnCompanionGlow(companionX, companionY, this.companionBond);
            }
        }

        // 绘制敌人
        this.enemies.forEach(enemy => {
            ctx.save();
            ctx.translate(enemy.x, enemy.y);

            // 敌人光晕
            ctx.beginPath();
            ctx.arc(0, 0, enemy.size + 5, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(255, 71, 87, 0.15)';
            ctx.fill();

            // 敌人本体
            ctx.beginPath();
            ctx.arc(0, 0, enemy.size, 0, Math.PI * 2);
            ctx.fillStyle = '#ff4757';
            ctx.shadowColor = '#ff4757';
            ctx.shadowBlur = 10;
            ctx.fill();

            // HP条
            const hpRatio = enemy.hp / enemy.max_hp;
            ctx.fillStyle = '#333';
            ctx.fillRect(-15, -enemy.size - 10, 30, 4);
            ctx.fillStyle = hpRatio > 0.5 ? '#2ed573' : hpRatio > 0.2 ? '#f39c12' : '#ff4757';
            ctx.fillRect(-15, -enemy.size - 10, 30 * hpRatio, 4);

            // 选中高亮
            if (this.selectedEnemy && this.selectedEnemy.id === enemy.id) {
                ctx.strokeStyle = '#ffd700';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(0, 0, enemy.size + 8, 0, Math.PI * 2);
                ctx.stroke();
            }

            ctx.restore();
        });

        // 绘制战利品
        if (this.currentRoom && this.currentRoom.loot) {
            this.currentRoom.loot.forEach(loot => {
                ctx.save();
                ctx.translate(loot.x, loot.y);

                const pulse = Math.sin(Date.now() / 300) * 3;
                ctx.beginPath();
                ctx.arc(0, 0, 8 + pulse, 0, Math.PI * 2);

                const colors = {
                    'common': '#888',
                    'epic': '#9b59b6',
                    'mythic': '#ffd700'
                };
                ctx.fillStyle = colors[loot.quality] || '#888';
                ctx.shadowColor = ctx.fillStyle;
                ctx.shadowBlur = 15;
                ctx.fill();

                ctx.restore();
            });
        }

        // 心流效果 - 隧道视觉
        if (this.flowState > 0.6) {
            const gradient = ctx.createRadialGradient(
                this.canvas.width / 2, this.canvas.height / 2, 100,
                this.canvas.width / 2, this.canvas.height / 2, Math.max(this.canvas.width, this.canvas.height)
            );
            gradient.addColorStop(0, 'rgba(0,0,0,0)');
            gradient.addColorStop(1, `rgba(0,0,0,${(this.flowState - 0.6) * 0.5})`);
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        }
    }

    // UI更新
    updateUI() {
        if (!this.gameState) return;

        // HP
        const hpRatio = this.gameState.hp / this.gameState.max_hp;
        document.getElementById('hp-bar').style.width = (hpRatio * 100) + '%';
        document.getElementById('hp-text').textContent = `${this.gameState.hp}/${this.gameState.max_hp}`;

        // 等级和XP
        document.getElementById('level-text').textContent = `Lv.${this.gameState.level}`;
        const xpRatio = this.gameState.xp / (this.gameState.level * 100);
        document.getElementById('xp-bar').style.width = (Math.min(xpRatio, 1) * 100) + '%';

        // 战利品
        document.getElementById('loot-count').textContent = this.gameState.total_loot || 0;

        // 伴侣羁绊
        this.updateCompanionUI();
    }

    updateCompanionUI() {
        const bond = this.companionBond || (this.gameState ? this.gameState.companion_bond : 0);
        document.getElementById('bond-bar').style.width = (bond * 100) + '%';
        document.getElementById('bond-text').textContent = `羁绊: ${(bond * 100).toFixed(0)}%`;

        if (bond > 0.5) {
            document.getElementById('companion-glow').classList.add('active');
        }
    }

    updateInventory(inventory) {
        const container = document.getElementById('inventory');
        container.innerHTML = '';

        const icons = {
            '星尘碎片': '✨', '能量晶体': '💎', '旧地图': '🗺️',
            '虚空之刃': '⚔️', '时间沙漏': '⏳', '灵魂容器': '🔮',
            '创世核心': '☀️', '无限矩阵': '♾️', '命运之轮': '🎡'
        };

        inventory.forEach(item => {
            const div = document.createElement('div');
            div.className = `inventory-item ${item.quality}`;
            div.textContent = icons[item.name] || '📦';
            div.title = `${item.name} (${item.quality})`;
            container.appendChild(div);
        });
    }

    updateAchievements(achievements) {
        const container = document.getElementById('achievements');
        container.innerHTML = '';

        achievements.forEach(ach => {
            if (this.achievementsShown.has(ach.name)) {
                // 已显示过，直接添加
                this.addAchievementItem(ach);
            } else {
                // 新成就，显示弹窗
                this.achievementsShown.add(ach.name);
                this.showAchievementPopup(ach);
                this.addAchievementItem(ach);

                // 血清素：成就粒子
                this.particleSystem.spawnAchievementParticles(
                    this.canvas.width / 2, this.canvas.height / 2
                );
            }
        });
    }

    addAchievementItem(ach) {
        const container = document.getElementById('achievements');
        const div = document.createElement('div');
        div.className = 'achievement-item';
        div.innerHTML = `
            <span class="ach-icon">${ach.icon}</span>
            <div>
                <div style="font-weight:bold;color:var(--accent-gold)">${ach.name}</div>
                <div style="font-size:0.75rem;color:var(--text-secondary)">${ach.desc}</div>
            </div>
        `;
        container.appendChild(div);
    }

    showAchievementPopup(ach) {
        const popup = document.getElementById('achievement-popup');
        document.getElementById('achievement-icon').textContent = ach.icon;
        document.getElementById('achievement-name').textContent = ach.name;
        document.getElementById('achievement-desc').textContent = ach.desc;

        popup.classList.remove('hidden');
        window.audioSystem.playLootSound('epic');

        setTimeout(() => {
            popup.classList.add('hidden');
        }, 3000);
    }

    updateWorldFeedback(world) {
        const container = document.getElementById('world-feedback');
        if (!world || !world.title) return;

        container.innerHTML = `
            <div class="feedback-title">${world.title}</div>
            <div>${world.npc_reaction}</div>
            <div style="margin-top:5px;color:var(--accent-cyan)">${world.environment_effect}</div>
            ${world.statue_desc ? `<div style="margin-top:5px;color:var(--accent-gold)">🏛️ ${world.statue_desc}</div>` : ''}
        `;
    }

    updateCombatButtons() {
        const hasEnemies = this.enemies.length > 0;
        const hasLoot = this.currentRoom && this.currentRoom.loot && this.currentRoom.loot.length > 0;

        document.getElementById('btn-attack').classList.toggle('hidden', !hasEnemies);
        document.getElementById('btn-dodge').classList.toggle('hidden', !hasEnemies);
        document.getElementById('btn-collect').classList.toggle('hidden', !hasLoot);
    }

    // 日志系统
    addLog(category, message, type = 'normal') {
        const container = document.getElementById('game-log');
        const entry = document.createElement('div');
        entry.className = `log-entry ${type}`;
        entry.innerHTML = `<span style="color:var(--text-secondary)">[${category}]</span> ${message}`;
        container.appendChild(entry);
        container.scrollTop = container.scrollHeight;

        // 限制日志数量
        while (container.children.length > 50) {
            container.removeChild(container.firstChild);
        }
    }

    // APM报告
    reportAPM() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            const now = Date.now();
            const timeWindow = (now - this.lastApmReport) / 1000;
            this.ws.send(JSON.stringify({
                action: 'apm_report',
                actions: this.actionCount,
                time_window: timeWindow
            }));
            this.actionCount = 0;
            this.lastApmReport = now;
        }
    }

    // 会话时间
    updateSessionTime() {
        const elapsed = Math.floor((Date.now() - this.sessionStart) / 1000);
        const mins = Math.floor(elapsed / 60).toString().padStart(2, '0');
        const secs = (elapsed % 60).toString().padStart(2, '0');
        document.getElementById('session-time').textContent = `${mins}:${secs}`;
    }

    // 心跳
    heartbeat() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ action: 'heartbeat' }));
        }
    }

    // 事件绑定
    bindEvents() {
        // 键盘
        window.addEventListener('keydown', (e) => {
            this.keys[e.key.toLowerCase()] = true;
            this.actionCount++;

            // 发送移动
            const dx = e.key === 'a' || e.key === 'arrowleft' ? -5 :
                      e.key === 'd' || e.key === 'arrowright' ? 5 : 0;
            const dy = e.key === 'w' || e.key === 'arrowup' ? -5 :
                      e.key === 's' || e.key === 'arrowdown' ? 5 : 0;

            if (dx !== 0 || dy !== 0) {
                if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                    this.ws.send(JSON.stringify({
                        action: 'move',
                        dx: dx,
                        dy: dy
                    }));
                }
            }
        });

        window.addEventListener('keyup', (e) => {
            this.keys[e.key.toLowerCase()] = false;
        });

        // 鼠标点击（选择敌人）
        this.canvas.addEventListener('click', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            // 检查是否点击了敌人
            this.selectedEnemy = null;
            this.enemies.forEach(enemy => {
                const dist = Math.sqrt((x - enemy.x) ** 2 + (y - enemy.y) ** 2);
                if (dist < enemy.size + 10) {
                    this.selectedEnemy = enemy;
                }
            });

            this.actionCount++;
        });

        // 窗口大小调整
        window.addEventListener('resize', () => {
            this.resizeCanvas();
            this.particleSystem.resize();
        });

        // 按钮事件
        document.getElementById('start-btn').addEventListener('click', () => {
            document.getElementById('loading-screen').classList.add('hidden');
            document.getElementById('game-container').classList.remove('hidden');
            this.resizeCanvas();
            this.particleSystem.resize();
            window.audioSystem.init();
        });

        document.getElementById('btn-explore').addEventListener('click', () => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({ action: 'explore' }));
                this.actionCount += 5;
            }
        });

        document.getElementById('btn-attack').addEventListener('click', () => {
            if (this.selectedEnemy && this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({
                    action: 'combat',
                    enemy_id: this.selectedEnemy.id,
                    combat_action: 'attack'
                }));
                this.actionCount += 3;
            } else if (this.enemies.length > 0) {
                // 自动选择最近的敌人
                this.selectedEnemy = this.enemies[0];
                this.ws.send(JSON.stringify({
                    action: 'combat',
                    enemy_id: this.selectedEnemy.id,
                    combat_action: 'attack'
                }));
                this.actionCount += 3;
            }
        });

        document.getElementById('btn-dodge').addEventListener('click', () => {
            if (this.selectedEnemy && this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({
                    action: 'combat',
                    enemy_id: this.selectedEnemy.id,
                    combat_action: 'dodge'
                }));
                this.actionCount += 2;
            }
        });

        document.getElementById('btn-collect').addEventListener('click', () => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({ action: 'collect_loot' }));
                this.actionCount += 2;
            }
        });

        // 伴侣系统
        document.getElementById('btn-companion').addEventListener('click', () => {
            document.getElementById('companion-modal').classList.remove('hidden');
            window.audioSystem.playCompanionSound('talk');
        });

        document.getElementById('btn-close-companion').addEventListener('click', () => {
            document.getElementById('companion-modal').classList.add('hidden');
        });

        // 伴侣互动按钮
        document.querySelectorAll('.dialogue-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.target.dataset.action;
                this.interactWithCompanion(action);
            });
        });

        // 伴侣聊天
        document.getElementById('btn-send-chat').addEventListener('click', () => {
            this.sendCompanionChat();
        });

        document.getElementById('companion-chat-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendCompanionChat();
        });

        // 模拟加载完成
        setTimeout(() => {
            document.getElementById('start-btn').classList.remove('hidden');
        }, 3000);
    }

    interactWithCompanion(action) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            // 使用REST API进行互动
            fetch(`/api/companion/interact/${this.playerId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: action })
            })
            .then(r => r.json())
            .then(data => {
                const text = document.getElementById('companion-dialogue-text');
                text.textContent = data.response;
                text.style.animation = 'none';
                text.offsetHeight;
                text.style.animation = 'fadeIn 0.5s ease';

                this.companionBond = data.bond;
                this.updateCompanionUI();

                window.audioSystem.playCompanionSound('bond');
                this.addLog('星灵', data.response, 'oxytocin');

                // 催产素粒子
                const rect = document.getElementById('companion-avatar').getBoundingClientRect();
                this.particleSystem.spawnCompanionGlow(
                    rect.left + rect.width / 2, rect.top + rect.height / 2, data.bond_increase * 10
                );
            });
        }
    }

    sendCompanionChat() {
        const input = document.getElementById('companion-chat-input');
        const message = input.value.trim();
        if (!message) return;

        input.value = '';

        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                action: 'companion_talk',
                message: message,
                context: {
                    situation: this.currentRoom ? this.currentRoom.type : 'exploring',
                    playerHp: this.gameState ? this.gameState.hp : 100
                }
            }));
        }
    }
}

// 启动游戏
window.addEventListener('DOMContentLoaded', () => {
    window.game = new NeuroMatrix();
});
