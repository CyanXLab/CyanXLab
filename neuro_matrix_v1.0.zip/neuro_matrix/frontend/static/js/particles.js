/* ===== 粒子系统 - 视觉特效 ===== */
class ParticleSystem {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.width = this.canvas.width;
        this.height = this.canvas.height;
        this.animationId = null;
        this.running = false;
    }

    resize() {
        const rect = this.canvas.parentElement.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
        this.width = this.canvas.width;
        this.height = this.canvas.height;
    }

    start() {
        if (this.running) return;
        this.running = true;
        this.animate();
    }

    stop() {
        this.running = false;
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
    }

    animate() {
        if (!this.running) return;

        this.ctx.clearRect(0, 0, this.width, this.height);

        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.update();
            p.draw(this.ctx);

            if (p.life <= 0) {
                this.particles.splice(i, 1);
            }
        }

        this.animationId = requestAnimationFrame(() => this.animate());
    }

    // 多巴胺：获得战利品粒子
    spawnLootParticles(x, y, quality) {
        const colors = {
            'common': ['#888', '#aaa'],
            'epic': ['#9b59b6', '#3498db', '#a55eea'],
            'mythic': ['#ffd700', '#ff6b35', '#ff4757', '#fff']
        };

        const colorSet = colors[quality] || colors['common'];
        const count = quality === 'mythic' ? 50 : quality === 'epic' ? 30 : 15;

        for (let i = 0; i < count; i++) {
            this.particles.push(new Particle({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 8,
                vy: (Math.random() - 0.5) * 8 - 2,
                size: Math.random() * 4 + 2,
                color: colorSet[Math.floor(Math.random() * colorSet.length)],
                life: 1.0,
                decay: 0.015,
                gravity: 0.1,
                type: 'sparkle'
            }));
        }

        // 文字粒子
        if (quality === 'mythic' || quality === 'epic') {
            this.particles.push(new Particle({
                x: x,
                y: y - 30,
                vx: 0,
                vy: -1,
                size: 20,
                color: quality === 'mythic' ? '#ffd700' : '#9b59b6',
                life: 1.5,
                decay: 0.008,
                gravity: 0,
                type: 'text',
                text: quality === 'mythic' ? '★ 神器 ★' : '★ 稀有 ★'
            }));
        }
    }

    // 内啡肽：战斗粒子
    spawnCombatParticles(x, y, type) {
        const colors = type === 'critical' 
            ? ['#ffd700', '#ff6b35', '#fff']
            : ['#ff4757', '#c0392b', '#e74c3c'];

        for (let i = 0; i < 20; i++) {
            this.particles.push(new Particle({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 10,
                vy: (Math.random() - 0.5) * 10,
                size: Math.random() * 5 + 2,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: 0.8,
                decay: 0.02,
                gravity: 0.2,
                type: 'burst'
            }));
        }
    }

    // 内源性大麻素：心流粒子
    spawnFlowParticles() {
        for (let i = 0; i < 3; i++) {
            this.particles.push(new Particle({
                x: Math.random() * this.width,
                y: this.height + 10,
                vx: (Math.random() - 0.5) * 0.5,
                vy: -Math.random() * 2 - 0.5,
                size: Math.random() * 2 + 1,
                color: `rgba(0, 212, 255, ${Math.random() * 0.5})`,
                life: 2.0,
                decay: 0.005,
                gravity: 0,
                type: 'ambient'
            }));
        }
    }

    // 催产素：伴侣光晕粒子
    spawnCompanionGlow(x, y, intensity) {
        const count = Math.floor(intensity * 10);
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * 30 + 10;
            this.particles.push(new Particle({
                x: x + Math.cos(angle) * dist,
                y: y + Math.sin(angle) * dist,
                vx: Math.cos(angle) * 0.5,
                vy: Math.sin(angle) * 0.5,
                size: Math.random() * 3 + 1,
                color: `rgba(255, 107, 157, ${Math.random() * 0.6})`,
                life: 1.0,
                decay: 0.02,
                gravity: 0,
                type: 'glow'
            }));
        }
    }

    // 血清素：成就粒子
    spawnAchievementParticles(x, y) {
        const colors = ['#ffd700', '#f39c12', '#e74c3c', '#9b59b6', '#3498db'];
        for (let i = 0; i < 40; i++) {
            this.particles.push(new Particle({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 12,
                vy: (Math.random() - 0.5) * 12 - 3,
                size: Math.random() * 6 + 2,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: 1.5,
                decay: 0.012,
                gravity: 0.15,
                type: 'celebration'
            }));
        }
    }

    // 多巴胺爆发
    spawnDopamineBurst(x, y) {
        const colors = ['#ffd700', '#ff6b35', '#fff', '#ff4757'];
        for (let i = 0; i < 80; i++) {
            const angle = (Math.PI * 2 / 80) * i + Math.random() * 0.5;
            const speed = Math.random() * 6 + 3;
            this.particles.push(new Particle({
                x: x,
                y: y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: Math.random() * 5 + 2,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: 1.2,
                decay: 0.015,
                gravity: 0.1,
                type: 'explosion'
            }));
        }
    }

    // 环境粒子
    spawnAmbientParticles(theme) {
        const colors = {
            'common': ['rgba(100,100,100,0.3)', 'rgba(150,150,150,0.2)'],
            'normal': ['rgba(100,180,255,0.2)', 'rgba(150,200,255,0.15)'],
            'rare': ['rgba(150,100,255,0.3)', 'rgba(100,150,255,0.2)'],
            'legendary': ['rgba(255,215,0,0.3)', 'rgba(255,100,50,0.2)', 'rgba(255,255,255,0.2)']
        };

        const colorSet = colors[theme] || colors['common'];

        for (let i = 0; i < 5; i++) {
            this.particles.push(new Particle({
                x: Math.random() * this.width,
                y: Math.random() * this.height,
                vx: (Math.random() - 0.5) * 0.3,
                vy: (Math.random() - 0.5) * 0.3,
                size: Math.random() * 2 + 0.5,
                color: colorSet[Math.floor(Math.random() * colorSet.length)],
                life: 5.0,
                decay: 0.002,
                gravity: 0,
                type: 'ambient'
            }));
        }
    }
}

class Particle {
    constructor(config) {
        this.x = config.x;
        this.y = config.y;
        this.vx = config.vx;
        this.vy = config.vy;
        this.size = config.size;
        this.color = config.color;
        this.life = config.life;
        this.decay = config.decay;
        this.gravity = config.gravity || 0;
        this.type = config.type;
        this.text = config.text || '';
        this.initialSize = config.size;
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.vy += this.gravity;
        this.life -= this.decay;

        if (this.type === 'sparkle' || this.type === 'glow') {
            this.size = this.initialSize * this.life;
        }
    }

    draw(ctx) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, this.life);

        if (this.type === 'text') {
            ctx.font = `bold ${this.size}px Arial`;
            ctx.fillStyle = this.color;
            ctx.textAlign = 'center';
            ctx.shadowColor = this.color;
            ctx.shadowBlur = 10;
            ctx.fillText(this.text, this.x, this.y);
        } else {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = this.color;
            ctx.shadowColor = this.color;
            ctx.shadowBlur = this.type === 'glow' ? 15 : 5;
            ctx.fill();
        }

        ctx.restore();
    }
}

window.ParticleSystem = ParticleSystem;
