#!/usr/bin/env python3
"""
Neuro-Matrix 启动脚本
心智矩阵 - 多维神经递质劫持系统
"""
import os
import sys
import subprocess

def main():
    print("=" * 50)
    print("  心智矩阵 (Neuro-Matrix) v1.0")
    print("  多维神经递质劫持系统")
    print("=" * 50)
    print()

    # 检查依赖
    print("[1/3] 检查依赖...")
    try:
        import fastapi
        import uvicorn
        import websockets
        import httpx
        print("  ✓ 所有依赖已安装")
    except ImportError as e:
        print(f"  ✗ 缺少依赖: {e}")
        print("  正在安装依赖...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("  ✓ 依赖安装完成")

    # 检查环境变量
    print("[2/3] 检查环境变量...")
    if not os.getenv("MODELSCOPE_API_KEY"):
        os.environ["MODELSCOPE_API_KEY"] = "ms-a300ec43-a4f3-49d2-9044-2fdbc269f3b9"
        print("  ✓ 已设置 ModelScope API Key")
    else:
        print("  ✓ ModelScope API Key 已配置")

    if not os.getenv("MODELSCOPE_BASE_URL"):
        os.environ["MODELSCOPE_BASE_URL"] = "https://api-inference.modelscope.cn/v1"
        print("  ✓ 已设置 ModelScope Base URL")

    if not os.getenv("MODELSCOPE_MODEL"):
        os.environ["MODELSCOPE_MODEL"] = "Qwen/Qwen3.5-122B-A10B"
        print("  ✓ 已设置 ModelScope Model")

    # 启动服务器
    print("[3/3] 启动服务器...")
    print()
    print("  🎮 游戏地址: http://localhost:8000/game")
    print("  📚 API文档: http://localhost:8000/docs")
    print()
    print("  按 Ctrl+C 停止服务器")
    print("=" * 50)

    # 切换到backend目录并启动
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    subprocess.run([sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"])

if __name__ == "__main__":
    main()
