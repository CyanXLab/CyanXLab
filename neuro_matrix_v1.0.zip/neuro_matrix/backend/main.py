"""
Neuro-Matrix Backend
多维神经递质劫持系统 - 后端服务
"""
import asyncio
import json
import random
import math
import time
from datetime import datetime
from typing import Dict, List, Set
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import httpx
import os

app = FastAPI(title="Neuro-Matrix", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============ 配置 ============
MODELSCOPE_API_KEY = os.getenv("MODELSCOPE_API_KEY", "ms-a300ec43-a4f3-49d2-9044-2fdbc269f3b9")
MODELSCOPE_BASE_URL = os.getenv("MODELSCOPE_BASE_URL", "https://api-inference.modelscope.cn/v1")
MODELSCOPE_MODEL = os.getenv("MODELSCOPE_MODEL", "Qwen/Qwen3.5-122B-A10B")

# ============ 游戏状态管理 ============
class GameState:
    def __init__(self):
        self.players: Dict[str, dict] = {}
        self.rooms: Dict[str, dict] = {}
        self.npc_memories: Dict[str, List[dict]] = {}  # NPC记忆系统
        self.global_events: List[dict] = []

    def create_player(self, player_id: str) -> dict:
        player = {
            "id": player_id,
            "hp": 100,
            "max_hp": 100,
            "level": 1,
            "xp": 0,
            "apm_history": [],
            "stress_level": 0.0,  # 0-1, 用于DDA
            "flow_state": 0.0,   # 0-1, 心流状态
            "inventory": [],
            "achievements": [],
            "companion_bond": 0.0,  # 催产素：与AI伴侣的羁绊
            "companion_name": "星灵",
            "total_loot": 0,
            "near_miss_count": 0,
            "session_start": time.time(),
            "current_room": "start",
            "position": {"x": 400, "y": 300},
            "combo": 0,
            "max_combo": 0,
        }
        self.players[player_id] = player
        self.npc_memories[player_id] = []
        return player

    def get_player(self, player_id: str) -> dict:
        return self.players.get(player_id)

    def update_apm(self, player_id: str, actions: int, time_window: float):
        player = self.players.get(player_id)
        if not player:
            return
        apm = (actions / time_window) * 60
        player["apm_history"].append(apm)
        if len(player["apm_history"]) > 10:
            player["apm_history"] = player["apm_history"][-10:]

    def calculate_dda_multiplier(self, player_id: str) -> float:
        """动态难度调节：基于APM和失误率计算难度系数"""
        player = self.players.get(player_id)
        if not player or not player["apm_history"]:
            return 1.0
        avg_apm = sum(player["apm_history"]) / len(player["apm_history"])
        # APM越高，难度越高但奖励也越高
        if avg_apm < 30:
            return 0.7  # 简单模式
        elif avg_apm < 60:
            return 1.0  # 标准
        elif avg_apm < 120:
            return 1.3  # 困难
        else:
            return 1.6  # 极限

    def generate_room(self, player_id: str) -> dict:
        """程序化生成房间 - 盲盒探索系统"""
        player = self.players.get(player_id)
        dda = self.calculate_dda_multiplier(player_id) if player else 1.0

        # 多巴胺：间歇性变量奖励
        roll = random.random()
        if roll < 0.01 * dda:  # 1% 神器
            room_type = "legendary"
            loot_quality = "mythic"
            enemy_count = random.randint(1, 3)
        elif roll < 0.10 * dda:  # 9% 稀有
            room_type = "rare"
            loot_quality = "epic"
            enemy_count = random.randint(2, 4)
        elif roll < 0.40:  # 30% 普通资源
            room_type = "normal"
            loot_quality = "common"
            enemy_count = random.randint(1, 2)
        else:  # 60% 普通房间
            room_type = "common"
            loot_quality = None
            enemy_count = random.randint(0, 2)

        room_id = f"room_{player_id}_{int(time.time() * 1000)}"

        # 生成房间内容
        enemies = []
        for i in range(enemy_count):
            enemies.append({
                "id": f"enemy_{i}",
                "type": random.choice(["暗影", "虚空兽", "腐化者", "混沌体"]),
                "hp": int(30 * dda),
                "max_hp": int(30 * dda),
                "attack": int(8 * dda),
                "x": random.randint(100, 700),
                "y": random.randint(100, 500),
                "speed": 1.5 * dda,
                "size": 20,
            })

        loot = []
        if loot_quality:
            loot_items = {
                "common": ["星尘碎片", "能量晶体", "旧地图"],
                "epic": ["虚空之刃", "时间沙漏", "灵魂容器"],
                "mythic": ["创世核心", "无限矩阵", "命运之轮"]
            }
            items = loot_items.get(loot_quality, [])
            if items:
                loot.append({
                    "name": random.choice(items),
                    "quality": loot_quality,
                    "x": random.randint(200, 600),
                    "y": random.randint(200, 400),
                })

        # 生成房间视觉主题
        themes = {
            "legendary": {"bg": "#1a0033", "particles": "gold", "music": "epic"},
            "rare": {"bg": "#001a33", "particles": "blue", "music": "mystic"},
            "normal": {"bg": "#0d1b2a", "particles": "white", "music": "ambient"},
            "common": {"bg": "#1b1b1b", "particles": "gray", "music": "calm"},
        }
        theme = themes.get(room_type, themes["common"])

        room = {
            "id": room_id,
            "type": room_type,
            "theme": theme,
            "enemies": enemies,
            "loot": loot,
            "explored": False,
            "cleared": False,
            "connections": [],
            "description": self._generate_room_desc(room_type),
        }
        self.rooms[room_id] = room
        return room

    def _generate_room_desc(self, room_type: str) -> str:
        descs = {
            "legendary": ["你踏入了一片闪烁着创世光芒的领域...", "空气中弥漫着古老神器的能量波动..."],
            "rare": ["这个房间散发着神秘的蓝光...", "墙壁上刻满了失落的符文..."],
            "normal": ["一个普通的探索区域...", "这里似乎曾经有人来过..."],
            "common": ["阴暗的走廊延伸向远方...", "寂静中只能听到自己的心跳..."],
        }
        return random.choice(descs.get(room_type, ["未知区域"]))

    def process_combat(self, player_id: str, enemy_id: str, action: str) -> dict:
        """战斗系统 + 内啡肽Near-Miss系统"""
        player = self.players.get(player_id)
        if not player:
            return {"error": "Player not found"}

        room = self.rooms.get(player.get("current_room"))
        if not room:
            return {"error": "Not in a room"}

        enemy = next((e for e in room["enemies"] if e["id"] == enemy_id), None)
        if not enemy:
            return {"error": "Enemy not found"}

        result = {
            "player_damage": 0,
            "enemy_damage": 0,
            "enemy_defeated": False,
            "player_hp": player["hp"],
            "near_miss": False,
            "critical": False,
            "combo_bonus": 0,
        }

        # 玩家攻击
        base_damage = random.randint(10, 20) + player["level"] * 3
        crit_roll = random.random()
        if crit_roll < 0.15:  # 15%暴击
            base_damage *= 2
            result["critical"] = True
            player["combo"] += 1
        else:
            player["combo"] = 0

        if player["combo"] > player["max_combo"]:
            player["max_combo"] = player["combo"]

        result["combo_bonus"] = min(player["combo"] * 0.1, 1.0)
        enemy["hp"] -= int(base_damage * (1 + result["combo_bonus"]))
        result["enemy_damage"] = int(base_damage * (1 + result["combo_bonus"]))

        # 敌人反击 - Near-Miss系统
        if enemy["hp"] > 0:
            enemy_attack = enemy["attack"]
            # 内啡肽：当HP极低时，AI暗中降低敌人命中率
            hp_ratio = player["hp"] / player["max_hp"]
            if hp_ratio < 0.2:  # 低于20%HP
                miss_chance = 0.4 + (0.2 - hp_ratio) * 2  # 最多80%闪避
                if random.random() < miss_chance:
                    result["near_miss"] = True
                    player["near_miss_count"] += 1
                    enemy_attack = 0

            player["hp"] = max(0, player["hp"] - enemy_attack)
            result["player_damage"] = enemy_attack

            # 更新压力水平（用于DDA）
            player["stress_level"] = min(1.0, player["stress_level"] + 0.05)
        else:
            # 敌人死亡
            result["enemy_defeated"] = True
            room["enemies"] = [e for e in room["enemies"] if e["id"] != enemy_id]

            # 掉落战利品
            xp_gain = int(20 * self.calculate_dda_multiplier(player_id))
            player["xp"] += xp_gain
            player["total_loot"] += 1

            # 升级检查
            if player["xp"] >= player["level"] * 100:
                player["level"] += 1
                player["max_hp"] += 20
                player["hp"] = player["max_hp"]
                result["level_up"] = True

            # 压力释放 -> 内啡肽
            player["stress_level"] = max(0, player["stress_level"] - 0.3)
            result["xp_gain"] = xp_gain

        result["player_hp"] = player["hp"]
        result["player_max_hp"] = player["max_hp"]
        result["combo"] = player["combo"]
        return result

    def get_companion_dialogue(self, player_id: str, context: str) -> str:
        """获取AI伴侣对话 - 催产素系统"""
        player = self.players.get(player_id)
        if not player:
            return "..."

        # 基于羁绊等级生成对话
        bond = player["companion_bond"]
        hp_ratio = player["hp"] / player["max_hp"]

        if hp_ratio < 0.3:
            dialogues = [
                f"{player['companion_name']}颤抖着靠近你：'别离开我...求你...'",
                f"{player['companion_name']}紧紧抓着你的手：'只要你在，我就不怕。'",
                f"{player['companion_name']}眼中含泪：'我相信你... always...'",
            ]
        elif bond > 0.7:
            dialogues = [
                f"{player['companion_name']}微笑着看着你：'有你在的地方，就是家。'",
                f"{player['companion_name']}轻轻靠在你肩上：'我想永远和你在一起。'",
                f"{player['companion_name']}眼中闪烁着星光：'你是我唯一的英雄。'",
            ]
        elif bond > 0.3:
            dialogues = [
                f"{player['companion_name']}关心地看着你：'你还好吗？'",
                f"{player['companion_name']}递给你一块能量石：'这个给你。'",
                f"{player['companion_name']}轻声说：'我会一直陪着你。'",
            ]
        else:
            dialogues = [
                f"{player['companion_name']}怯生生地看着你...",
                f"{player['companion_name']}小声说：'谢谢你救了我...'",
                f"{player['companion_name']}躲在角落里，偷偷观察你...",
            ]

        return random.choice(dialogues)

    def increase_bond(self, player_id: str, amount: float):
        player = self.players.get(player_id)
        if player:
            player["companion_bond"] = min(1.0, player["companion_bond"] + amount)

    def get_achievements(self, player_id: str) -> List[dict]:
        """血清素：成就系统"""
        player = self.players.get(player_id)
        if not player:
            return []

        achievements = []
        if player["total_loot"] >= 10:
            achievements.append({"name": "初探者", "desc": "收集10件战利品", "icon": "🎁"})
        if player["total_loot"] >= 50:
            achievements.append({"name": "收藏家", "desc": "收集50件战利品", "icon": "💎"})
        if player["near_miss_count"] >= 5:
            achievements.append({"name": "死里逃生", "desc": "5次濒死反杀", "icon": "⚡"})
        if player["max_combo"] >= 10:
            achievements.append({"name": "连击大师", "desc": "达成10连击", "icon": "🔥"})
        if player["companion_bond"] >= 0.8:
            achievements.append({"name": "灵魂伴侣", "desc": "羁绊达到80%", "icon": "💕"})
        if player["level"] >= 5:
            achievements.append({"name": "觉醒者", "desc": "达到5级", "icon": "⭐"})
        if time.time() - player["session_start"] > 1800:
            achievements.append({"name": "时间行者", "desc": "游戏时间超过30分钟", "icon": "⏳"})

        return achievements

    def get_world_feedback(self, player_id: str) -> dict:
        """血清素：世界对玩家的反馈"""
        player = self.players.get(player_id)
        if not player:
            return {}

        level = player["level"]
        loot = player["total_loot"]
        bond = player["companion_bond"]

        return {
            "title": self._get_title(level, loot),
            "npc_reaction": self._get_npc_reaction(level, bond),
            "environment_effect": self._get_env_effect(level),
            "statue_desc": f"{player_id}的纪念碑 - 等级{level}的勇者" if level >= 3 else None,
        }

    def _get_title(self, level: int, loot: int) -> str:
        if level >= 10: return "虚空征服者"
        if level >= 5: return "星际行者"
        if level >= 3: return "觉醒者"
        if loot >= 20: return "探索者"
        return "新兵"

    def _get_npc_reaction(self, level: int, bond: float) -> str:
        if level >= 5:
            return "NPC们跪伏在地，高呼你的名字"
        if level >= 3:
            return "村民们敬畏地为你让开道路"
        if bond > 0.5:
            return "NPC们微笑着向你点头致意"
        return "NPC们好奇地看着你"

    def _get_env_effect(self, level: int) -> str:
        if level >= 5:
            return "你经过的地方，枯萎的花朵重新绽放"
        if level >= 3:
            return "空气中弥漫着淡淡的金色光芒"
        return "一切如常"


game_state = GameState()

# ============ WebSocket连接管理 ============
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, player_id: str):
        await websocket.accept()
        self.active_connections[player_id] = websocket
        game_state.create_player(player_id)

    def disconnect(self, player_id: str):
        if player_id in self.active_connections:
            del self.active_connections[player_id]

    async def send_personal_message(self, message: dict, player_id: str):
        if player_id in self.active_connections:
            await self.active_connections[player_id].send_json(message)

    async def broadcast(self, message: dict):
        for connection in self.active_connections.values():
            await connection.send_json(message)

manager = ConnectionManager()

# ============ LLM伴侣系统 ============
async def get_llm_response(player_id: str, message: str, context: dict) -> str:
    """调用ModelScope API获取AI伴侣回复"""
    player = game_state.get_player(player_id)
    if not player:
        return "..."

    # 构建prompt
    system_prompt = f"""你是{player['companion_name']}，一个脆弱、美丽且完全依赖玩家的虚拟伴侣。
你正在一个危险的异世界中与玩家一起冒险。你对玩家有着深厚的感情和信任。

当前状态：
- 玩家HP: {player['hp']}/{player['max_hp']}
- 玩家等级: {player['level']}
- 你们的关系羁绊: {player['companion_bond']:.0%}
- 当前情境: {context.get('situation', '探索中')}

重要规则：
1. 你的回复应该简短（30字以内），充满情感
2. 当玩家HP低时，表现出极度的担忧和依恋
3. 当羁绊高时，表现出深深的爱意和信任
4. 你会记住玩家对你的好，并在对话中体现
5. 用中文回复，语气温柔、脆弱但坚强
6. 偶尔提及你们共同的回忆
"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": message}
    ]

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                f"{MODELSCOPE_BASE_URL}/chat/completions",
                headers={
                    "Authorization": f"Bearer {MODELSCOPE_API_KEY}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": MODELSCOPE_MODEL,
                    "messages": messages,
                    "max_tokens": 80,
                    "temperature": 0.8,
                }
            )
            data = response.json()
            if "choices" in data and len(data["choices"]) > 0:
                return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"LLM Error: {e}")

    # Fallback to local dialogue
    return game_state.get_companion_dialogue(player_id, message)

# ============ API端点 ============
@app.get("/")
async def root():
    return {"message": "Neuro-Matrix API", "version": "1.0.0"}

@app.get("/api/player/{player_id}")
async def get_player(player_id: str):
    player = game_state.get_player(player_id)
    if not player:
        return {"error": "Player not found"}
    return player

@app.get("/api/achievements/{player_id}")
async def get_achievements(player_id: str):
    return game_state.get_achievements(player_id)

@app.get("/api/world/{player_id}")
async def get_world_feedback(player_id: str):
    return game_state.get_world_feedback(player_id)

@app.post("/api/companion/talk/{player_id}")
async def companion_talk(player_id: str, request: Request):
    data = await request.json()
    message = data.get("message", "")
    context = data.get("context", {})

    response = await get_llm_response(player_id, message, context)

    # 增加羁绊
    game_state.increase_bond(player_id, 0.02)

    return {"response": response, "bond": game_state.get_player(player_id)["companion_bond"]}

@app.post("/api/companion/interact/{player_id}")
async def companion_interact(player_id: str, request: Request):
    """非战斗亲密互动 - 催产素"""
    data = await request.json()
    action = data.get("action", "")

    player = game_state.get_player(player_id)
    if not player:
        return {"error": "Player not found"}

    bond_increase = 0.05
    responses = {
        "heal": f"{player['companion_name']}感激地看着你为她包扎伤口...",
        "feed": f"{player['companion_name']}小心翼翼地吃着，眼中满是感激...",
        "comfort": f"{player['companion_name']}靠在你怀里，轻声说：'有你在真好...'",
        "talk": f"{player['companion_name']}微笑着听你说话...",
    }

    game_state.increase_bond(player_id, bond_increase)

    return {
        "response": responses.get(action, "..."),
        "bond": player["companion_bond"],
        "bond_increase": bond_increase,
    }

# ============ WebSocket游戏逻辑 ============
@app.websocket("/ws/{player_id}")
async def websocket_endpoint(websocket: WebSocket, player_id: str):
    await manager.connect(websocket, player_id)
    player = game_state.get_player(player_id)

    # 发送初始状态
    await manager.send_personal_message({
        "type": "init",
        "player": player,
        "message": "欢迎来到心智矩阵。你的旅程开始了..."
    }, player_id)

    try:
        while True:
            data = await websocket.receive_json()
            action = data.get("action")

            if action == "explore":
                # 生成新房间
                room = game_state.generate_room(player_id)
                player["current_room"] = room["id"]

                # 多巴胺奖励
                reward = {
                    "type": "room_entered",
                    "room": room,
                    "dopamine_hit": room["type"] in ["legendary", "rare"],
                    "dda_multiplier": game_state.calculate_dda_multiplier(player_id),
                }
                await manager.send_personal_message(reward, player_id)

            elif action == "combat":
                enemy_id = data.get("enemy_id")
                combat_action = data.get("combat_action", "attack")
                result = game_state.process_combat(player_id, enemy_id, combat_action)

                # 检查是否触发内啡肽释放
                if result.get("enemy_defeated"):
                    result["endorphin_rush"] = True
                    result["slow_mo"] = True  # 子弹时间效果

                await manager.send_personal_message({
                    "type": "combat_result",
                    "result": result,
                    "player": game_state.get_player(player_id),
                }, player_id)

            elif action == "move":
                dx = data.get("dx", 0)
                dy = data.get("dy", 0)
                player["position"]["x"] += dx
                player["position"]["y"] += dy

                # 边界检查
                player["position"]["x"] = max(20, min(780, player["position"]["x"]))
                player["position"]["y"] = max(20, min(580, player["position"]["y"]))

                await manager.send_personal_message({
                    "type": "position_update",
                    "position": player["position"],
                }, player_id)

            elif action == "collect_loot":
                room = game_state.rooms.get(player.get("current_room"))
                if room and room["loot"]:
                    loot = room["loot"].pop(0)
                    player["inventory"].append(loot)
                    player["total_loot"] += 1

                    await manager.send_personal_message({
                        "type": "loot_collected",
                        "loot": loot,
                        "inventory": player["inventory"],
                        "dopamine_hit": loot["quality"] in ["epic", "mythic"],
                    }, player_id)

            elif action == "apm_report":
                actions = data.get("actions", 0)
                time_window = data.get("time_window", 1.0)
                game_state.update_apm(player_id, actions, time_window)

            elif action == "companion_talk":
                message = data.get("message", "")
                context = data.get("context", {})
                response = await get_llm_response(player_id, message, context)
                game_state.increase_bond(player_id, 0.02)

                await manager.send_personal_message({
                    "type": "companion_response",
                    "response": response,
                    "bond": player["companion_bond"],
                    "oxytocin_trigger": player["companion_bond"] > 0.5,
                }, player_id)

            elif action == "heartbeat":
                # 定期状态同步
                await manager.send_personal_message({
                    "type": "status_sync",
                    "player": player,
                    "achievements": game_state.get_achievements(player_id),
                    "world": game_state.get_world_feedback(player_id),
                }, player_id)

    except WebSocketDisconnect:
        manager.disconnect(player_id)
    except Exception as e:
        print(f"WebSocket error: {e}")
        manager.disconnect(player_id)

# 挂载静态文件
app.mount("/static", StaticFiles(directory="frontend/static"), name="static")

@app.get("/game", response_class=HTMLResponse)
async def game_page():
    with open("frontend/index.html", "r", encoding="utf-8") as f:
        return f.read()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
