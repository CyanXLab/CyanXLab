/* 音效引擎 —— WebAudio 合成, 无外部资源 */
(function () {
  let ctx = null;
  let enabled = true;

  function ac() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, dur, type, vol, delay, slide) {
    const c = ac(); if (!c || !enabled) return;
    const t0 = c.currentTime + (delay || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, slide), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.12, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(c.destination);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  function noise(dur, vol, delay, freq) {
    const c = ac(); if (!c || !enabled) return;
    const t0 = c.currentTime + (delay || 0);
    const len = Math.floor(c.sampleRate * dur);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq || 2400;
    const g = c.createGain(); g.gain.value = vol || 0.08;
    src.connect(f).connect(g).connect(c.destination);
    src.start(t0);
  }

  window.SFX = {
    setEnabled(v) { enabled = !!v; if (v) ac(); },
    click() { tone(660, 0.05, 'square', 0.04); },
    fill() { tone(520, 0.08, 'triangle', 0.1); tone(780, 0.1, 'triangle', 0.08, 0.06); },
    profit(big) {
      tone(880, 0.1, 'sine', 0.12); tone(1174, 0.12, 'sine', 0.12, 0.09);
      tone(1568, 0.22, 'sine', 0.12, 0.18); noise(0.25, 0.05, 0.18, 5200);
      if (big) { tone(2093, 0.3, 'sine', 0.1, 0.3); }
    },
    loss() { tone(220, 0.22, 'sawtooth', 0.09, 0, 140); noise(0.12, 0.04, 0, 700); },
    liq() {
      for (let i = 0; i < 3; i++) tone(880 - i * 120, 0.16, 'square', 0.12, i * 0.19, 220);
      noise(0.5, 0.1, 0.1, 900);
    },
    achieve() { [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.14, 'sine', 0.11, i * 0.09)); },
    levelup() {
      [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, 0.16, 'triangle', 0.12, i * 0.08));
      noise(0.4, 0.05, 0.32, 6000);
    },
    news() { noise(0.32, 0.09, 0, 1500); tone(440, 0.18, 'sine', 0.06, 0.05, 660); },
    tp() { tone(988, 0.1, 'sine', 0.12); tone(1318, 0.16, 'sine', 0.12, 0.08); },
  };
})();
