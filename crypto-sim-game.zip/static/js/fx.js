/* 多巴胺特效: 彩带礼炮 / 浮动盈亏数字 / 屏幕震动 / Toast / 数字滚动 */
(function () {
  // ---------- Toast ----------
  const toastRoot = () => document.getElementById('toastRoot');
  window.toast = function (msg, kind, ms) {
    const root = toastRoot(); if (!root) return;
    const el = document.createElement('div');
    el.className = 'toast ' + (kind || 'info');
    el.innerHTML = msg;
    root.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 350); }, ms || 2600);
    while (root.children.length > 4) root.firstChild.remove();
  };

  // ---------- 彩带 ----------
  const fx = { parts: [], running: false };
  function fxCanvas() { return document.getElementById('fxCanvas'); }

  function resizeFx() {
    const c = fxCanvas(); if (!c) return;
    c.width = innerWidth * devicePixelRatio; c.height = innerHeight * devicePixelRatio;
  }
  addEventListener('resize', resizeFx);

  function loop() {
    const c = fxCanvas(); if (!c) { fx.running = false; return; }
    const ctx = c.getContext('2d');
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    const g = 0.16;
    fx.parts = fx.parts.filter(p => p.life > 0);
    for (const p of fx.parts) {
      p.vy += g; p.x += p.vx; p.y += p.vy; p.rot += p.vr; p.life -= 1;
      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, p.life / 30));
      ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h * (0.4 + 0.6 * Math.abs(Math.sin(p.rot * 2))));
      ctx.restore();
    }
    if (fx.parts.length) requestAnimationFrame(loop);
    else { ctx.clearRect(0, 0, innerWidth, innerHeight); fx.running = false; }
  }

  window.confetti = function (x, y, count, colors) {
    const cols = colors || ['#f0b90b', '#2ebd85', '#f6465d', '#3f8cff', '#ffffff', '#ffd700'];
    for (let i = 0; i < (count || 80); i++) {
      const a = Math.random() * Math.PI * 2, v = 4 + Math.random() * 9;
      fx.parts.push({
        x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 6,
        w: 5 + Math.random() * 6, h: 8 + Math.random() * 8,
        rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4,
        color: cols[(Math.random() * cols.length) | 0], life: 70 + Math.random() * 60,
      });
    }
    if (!fx.running) { fx.running = true; resizeFx(); requestAnimationFrame(loop); }
  };

  window.confettiRain = function (count) {
    for (let i = 0; i < (count || 140); i++) {
      fx.parts.push({
        x: Math.random() * innerWidth, y: -20 - Math.random() * 140,
        vx: (Math.random() - 0.5) * 2.4, vy: 1.5 + Math.random() * 2.5,
        w: 5 + Math.random() * 6, h: 8 + Math.random() * 8,
        rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.35,
        color: ['#f0b90b', '#2ebd85', '#ffd700', '#ffffff'][(Math.random() * 4) | 0],
        life: 150 + Math.random() * 90,
      });
    }
    if (!fx.running) { fx.running = true; resizeFx(); requestAnimationFrame(loop); }
  };

  // ---------- 浮动数字 ----------
  window.floatText = function (x, y, text, cls) {
    const el = document.createElement('div');
    el.className = 'float-num ' + (cls || '');
    el.textContent = text;
    el.style.left = x + 'px'; el.style.top = y + 'px';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1400);
  };

  // ---------- 震动 ----------
  window.shakeScreen = function (strong) {
    const app = document.getElementById('app');
    if (!app) return;
    app.classList.remove('shake', 'shake-strong');
    void app.offsetWidth;
    app.classList.add(strong ? 'shake-strong' : 'shake');
    if (navigator.vibrate) navigator.vibrate(strong ? [80, 40, 120] : 40);
  };

  // ---------- 数字滚动 ----------
  const tweens = new WeakMap();
  window.tweenNumber = function (el, to, fmt, dur) {
    if (!el) return;
    const from = tweens.get(el) !== undefined ? tweens.get(el) : (parseFloat(el.dataset.v) || to);
    if (from === to) { el.textContent = fmt(to); return; }
    const t0 = performance.now(), D = dur || 420;
    function step(t) {
      const k = Math.min(1, (t - t0) / D);
      const e = 1 - Math.pow(1 - k, 3);
      const v = from + (to - from) * e;
      el.textContent = fmt(v);
      if (k < 1) requestAnimationFrame(step);
      else tweens.set(el, to);
    }
    requestAnimationFrame(step);
    tweens.set(el, to);
  };

  // ---------- 模态框 ----------
  window.openModal = function (title, bodyHTML, opts) {
    closeModal();
    const root = document.getElementById('modalRoot');
    const wrap = document.createElement('div');
    wrap.className = 'modal-mask';
    wrap.id = 'modalWrap';
    wrap.innerHTML =
      '<div class="modal ' + ((opts && opts.wide) ? 'wide' : '') + '">' +
      '<div class="modal-head"><span>' + title + '</span><button class="modal-x" id="modalX">✕</button></div>' +
      '<div class="modal-body">' + bodyHTML + '</div></div>';
    root.appendChild(wrap);
    requestAnimationFrame(() => wrap.classList.add('show'));
    wrap.addEventListener('click', (e) => { if (e.target === wrap) closeModal(); });
    document.getElementById('modalX').onclick = closeModal;
    return wrap;
  };
  window.closeModal = function () {
    const w = document.getElementById('modalWrap');
    if (w) { w.classList.remove('show'); setTimeout(() => w.remove(), 200); }
  };
})();
