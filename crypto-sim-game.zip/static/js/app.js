/* CoinSprint 主控 —— 状态轮询 / 事件反应 / 交易动作 / 多巴胺调度 */
(function () {
  const S = {
    coin: "BTCUSDT",
    interval: "1m",
    lastEv: 0,
    pollTimer: null,
    klTimer: null,
    chart: null,
    settings: { sound: true, red_up: true },
    lastState: null,
    subTab: "pos",
    ready: false,
  };

  const $ = (id) => document.getElementById(id);

  // ---------- 初始化 ----------
  function init() {
    loadSettings();
    S.chart = new CandleChart($("chartCanvas"));
    window.__chart = S.chart;   // 调试/测试钩子
    bindTopbar();
    bindTradePanel();
    bindSubTabs();
    bindMobileNav();
    window.__started = () => { S.ready = true; };
    const firstTime = !localStorage.getItem("cs_seen");
    if (firstTime) localStorage.setItem("cs_seen", "1");
    if (firstTime) renderHelpModal(true);  // 仅首次访问自动弹出, 之后由顶栏 ❓ 按钮打开
    fetchKlines();
    poll();
    S.pollTimer = setInterval(poll, 1000);
    S.klTimer = setInterval(() => fetchKlines(true), 2000);
    document.addEventListener("pointerdown", () => SFX.setEnabled(S.settings.sound), { once: true });
  }

  // ---------- 设置 ----------
  function loadSettings() {
    try { Object.assign(S.settings, JSON.parse(localStorage.getItem("cs_settings") || "{}")); } catch (e) {}
    applySettings();
  }
  function saveSettings() {
    localStorage.setItem("cs_settings", JSON.stringify(S.settings));
    applySettings();
  }
  function applySettings() {
    document.body.classList.toggle("green-up", !S.settings.red_up);
    document.body.classList.toggle("red-up", !!S.settings.red_up);
    SFX.setEnabled(S.settings.sound);
  }

  // ---------- 顶栏事件 ----------
  function bindTopbar() {
    $("speedCtrl").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      if (b.id === "pauseBtn") {
        api("/api/pause", {}).then(() => {});
        return;
      }
      const sp = parseInt(b.dataset.s);
      api("/api/speed", { speed: sp });
      document.querySelectorAll("#speedCtrl button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
    });
    $("btnModel").onclick = async () => { SFX.click(); const r = await fetch("/api/model").then(r => r.json()); renderModelModal(r.meta, r.regime); };
    $("btnAch").onclick = () => { SFX.click(); const g = S.lastState?.game; if (g) renderAchModal(g.achievements); };
    $("btnNews").onclick = async () => { SFX.click(); const r = await fetch("/api/news").then(r => r.json()); renderNewsModal(r.news || []); };
    $("btnHelp").onclick = () => renderHelpModal(false);
    $("btnSettings").onclick = openSettings;
  }

  function openSettings() {
    const html = `
      <h4>🎨 涨跌颜色</h4>
      <p><label style="cursor:pointer"><input type="radio" name="cmode" id="cmRed" ${S.settings.red_up ? "checked" : ""}> 红涨绿跌 (中式)</label>
      &nbsp;&nbsp;<label style="cursor:pointer"><input type="radio" name="cmode" id="cmGreen" ${!S.settings.red_up ? "checked" : ""}> 绿涨红跌 (国际式)</label></p>
      <h4>🔊 音效</h4>
      <p><label style="cursor:pointer"><input type="checkbox" id="stSound" ${S.settings.sound ? "checked" : ""}> 开启交易音效 (成交/止盈/爆仓/成就)</label></p>
      <h4>🔄 重开一局</h4>
      <p class="dim">清空资金、仓位、成就与战绩, 引擎换一颗种子重新生成一个"平行市场"。</p>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button class="btn-ghost" onclick="closeModal()">取消</button>
        <button class="btn-danger" id="stReset">重置游戏</button>
      </div>`;
    const wrap = openModal("⚙️ 设置", html);
    wrap.querySelector("#cmRed").onchange = () => { S.settings.red_up = true; saveSettings(); refreshChart(true); };
    wrap.querySelector("#cmGreen").onchange = () => { S.settings.red_up = false; saveSettings(); refreshChart(true); };
    wrap.querySelector("#stSound").onchange = (e) => { S.settings.sound = e.target.checked; saveSettings(); };
    wrap.querySelector("#stReset").onclick = async () => {
      if (!confirm("确定重置? 所有进度将清空")) return;
      await api("/api/reset", {});
      localStorage.removeItem("cs_seen");
      S.lastEv = 0;
      location.reload();
    };
  }

  // ---------- 下单面板 ----------
  function marginInputOf(side) { return $(side === "long" ? "marginBuy" : "marginSell"); }

  function bindTradePanel() {
    document.querySelector(".tp-tabs").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      document.querySelectorAll(".tp-tabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      $("priceRow").style.display = b.dataset.t === "limit" ? "" : "none";
      $("triggerRow").style.display = b.dataset.t === "trigger" ? "" : "none";
      if (b.dataset.t === "limit") fillBestPx();
    });
    // 最优价: 填入当前标记价 (限价单快捷)
    const bestBtn = $("bestPx");
    if (bestBtn) bestBtn.onclick = () => { SFX.click(); fillBestPx(); };
    $("levSlider").addEventListener("input", (e) => {
      $("levVal").textContent = e.target.value + "x";
      document.querySelectorAll(".lev-quick button").forEach(x => x.classList.toggle("active", +x.dataset.l === +e.target.value));
      updatePreview();
    });
    document.querySelector(".lev-quick").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      $("levSlider").value = b.dataset.l;
      $("levSlider").dispatchEvent(new Event("input"));
    });
    // 双栏各自的 % 快捷 + 输入联动 (欧易式: 买/卖独立保证金)
    document.querySelectorAll(".pct-quick").forEach(q => {
      q.addEventListener("click", (e) => {
        const b = e.target.closest("button"); if (!b) return;
        SFX.click();
        const side = q.dataset.for === "sell" ? "short" : "long";
        const avail = S.lastState?.account?.available ?? 10000;
        marginInputOf(side).value = Math.max(5, Math.floor(avail * parseFloat(b.dataset.p)));
        updatePreview();
      });
    });
    ["marginBuy", "marginSell"].forEach(id => $(id).addEventListener("input", updatePreview));
    $("tslOn").addEventListener("change", (e) => { $("tslInputs").style.display = e.target.checked ? "flex" : "none"; });
    $("btnLong").onclick = () => placeOrder("long");
    $("btnShort").onclick = () => placeOrder("short");
    updatePreview();
  }

  function fillBestPx() {
    const px = S.lastState?.display?.[S.coin] ?? S.lastState?.coins?.[S.coin]?.price;
    if (px && $("priceInput")) $("priceInput").value = px;
  }

  function updatePreview() {
    const lev = +$("levSlider").value;
    const px = S.lastState?.coins?.[S.coin]?.price;
    const symShort = COIN_UI[S.coin].name.split("/")[0];
    for (const [side, inpId, prevId] of [["long", "marginBuy", "buyPreview"], ["short", "marginSell", "sellPreview"]]) {
      const margin = +$(inpId).value || 0;
      const notional = margin * lev;
      const qty = px ? notional / px : 0;
      const el = $(prevId);
      if (el) el.textContent = `≈ 价值 ${fmtN(notional, 0)} U · ${qty ? fmtQty(qty) : "--"} ${symShort}` +
        (lev >= 50 ? " ⚠️ 极高风险" : lev >= 20 ? " ⚠️ 高风险" : "");
    }
  }

  async function placeOrder(side) {
    const type = document.querySelector(".tp-tabs button.active").dataset.t;
    const lev = +$("levSlider").value;
    const margin = +marginInputOf(side).value || 0;
    const price = type === "limit" ? parseFloat($("priceInput").value) : null;
    const trigger = type === "trigger" ? parseFloat($("triggerInput").value) : null;
    const postOnly = $("postOnlyChk")?.checked || false;
    const useTsl = $("tslOn").checked;
    const tp_pct = useTsl ? parseFloat($("tpInput").value) || null : null;
    const sl_pct = useTsl ? parseFloat($("slInput").value) || null : null;
    if (margin < 5) return toast("最低保证金 5 USDT", "danger");
    if (type === "limit" && (!price || price <= 0)) return toast("请输入有效的限价", "danger");
    if (type === "trigger" && (!trigger || trigger <= 0)) return toast("请输入触发价", "danger");
    if (lev >= 50 && !confirm(`${lev}x 杠杆 — 价格反向波动 ${Math.round(100 / lev)}% 即刻爆仓, 确定开仓?`)) return;
    const r = await api("/api/order", { coin: S.coin, side, type, margin, leverage: lev, price, trigger, post_only: postOnly, tp_pct, sl_pct });
    if (r.ok) {
      SFX.fill();
      const sym = COIN_UI[S.coin].name.split("/")[0];
      const tag = type === "trigger" ? "🎯 计划委托已挂" : (type === "limit" ? "📌 限价挂单成功" : "已成交");
      toast(`${side === "long" ? "🟢 做多" : "🔴 做空"} ${sym} ${lev}x · ${fmtN(margin)} USDT ${tag}`, "success");
      fetchKlines();
    } else {
      toast("❌ " + r.msg, "danger");
    }
  }

  window.closePos = async function (pid, fraction) {
    const r = await api("/api/close", { position_id: pid, fraction });
    if (!r.ok) toast("❌ " + r.msg, "danger");
  };
  window.cancelOrder = async function (oid) {
    SFX.click();
    const r = await api("/api/cancel", { order_id: oid });
    if (r.ok) toast("挂单已撤销");
  };
  window.openTpsl = function (pid) {
    const p = S.lastState?.positions?.find(x => x.id === pid);
    if (!p) return;
    const html = `
      <p class="dim">当前标记价 ${fmtPrice(p.mark)} · 开仓价 ${fmtPrice(p.entry)} · ${p.side === 1 ? "做多" : "做空"} ${p.lev}x</p>
      <div class="tp-row" style="margin-top:10px"><span class="tp-label">止盈触发价 (留空取消)</span>
        <input type="number" id="mtp" step="any" value="${p.tp || ""}" placeholder="${p.side === 1 ? "高于开仓价" : "低于开仓价"}"></div>
      <div class="tp-row"><span class="tp-label">止损触发价 (留空取消)</span>
        <input type="number" id="msl" step="any" value="${p.sl || ""}" placeholder="${p.side === 1 ? "低于开仓价" : "高于开仓价"}"></div>
      <div style="text-align:right"><button class="btn-gold" id="mtpslOk">保存</button></div>`;
    const wrap = openModal("🎯 止盈 / 止损", html);
    wrap.querySelector("#mtpslOk").onclick = async () => {
      const r = await api("/api/tpsl", { position_id: pid, tp: wrap.querySelector("#mtp").value, sl: wrap.querySelector("#msl").value });
      toast(r.ok ? "✅ 已更新止盈止损" : "❌ " + r.msg, r.ok ? "success" : "danger");
      if (r.ok) closeModal();
    };
  };

  // ---------- 子面板 ----------
  function bindSubTabs() {
    $("subTabs").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      S.subTab = b.dataset.tab;
      document.querySelectorAll("#subTabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      rerenderSub();
    });
  }
  function rerenderSub() {
    const st = S.lastState; if (!st) return;
    if (S.subTab === "pos") renderPositions(st.positions, st.coins);
    else if (S.subTab === "orders") renderOrders(st.orders);
    else if (S.subTab === "hist") renderHistory(st.history);
    else renderStats(st.game);
  }

  function bindMobileNav() {
    const nav = $("mobileNav");
    if (!nav) return;
    nav.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      nav.querySelectorAll("button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      const t = $(b.dataset.target);
      if (t) t.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  // ---------- 数据轮询 ----------
  async function poll() {
    if (document.hidden) return;
    try {
      const r = await fetch(`/api/state?coin=${S.coin}&last_ev=${S.lastEv}`);
      const st = await r.json();
      if (!st.ok) return;
      S.lastState = st;
      window.__S = st;
      window.__coin = S.coin;
      S.lastEv = Math.max(S.lastEv, st.last_event_id || 0);
      renderState(st);
      for (const ev of st.events || []) handleEvent(ev);
      if (window.__tabRender) window.__tabRender(st);
    } catch (e) { /* 服务器重启等, 静默重试 */ }
  }

  function renderState(st) {
    applyCoinRules(st); // 逐币交易规则 (币安阶梯)
    // 顶栏
    tweenNumber($("equityVal"), st.account.equity, (v) => fmtN(v));
    const pnlEl = $("pnlTotalVal");
    tweenNumber(pnlEl, st.account.pnl_total, (v) => (v >= 0 ? "+" : "") + fmtN(v));
    pnlEl.className = "eq-val " + (st.account.pnl_total >= 0 ? "up" : "down");
    const g = st.game;
    $("lvNum").textContent = g.level;
    $("lvTitle").textContent = g.title;
    const pct = g.xp_next > g.xp_cur ? Math.min(100, (g.xp - g.xp_cur) / (g.xp_next - g.xp_cur) * 100) : 100;
    $("xpBar").style.width = pct + "%";
    // 币种 tabs
    renderCoinTabs(st.coins, S.coin);
    renderWatchlist(st.coins, S.coin);
    const c = st.coins[S.coin];
    renderChartHead(S.coin, c, st.display[S.coin] ?? c.price, st.funding_rate, st.regime_name, st.regime);
    // 盘口 / 成交流
    renderBook(st.book, st.display[S.coin] ?? c.price, S.coin);
    renderTape(st.tape);
    // 子面板
    rerenderSub();
    // 快讯条
    const lastNews = (st.events || []).filter(e => e.type === "news").pop();
    if (lastNews) setNewsBar(lastNews);
    // 暂停态
    const pb = $("pauseBtn");
    pb.textContent = st.paused ? "▶" : "⏸";
    pb.classList.toggle("active", st.paused);
    updatePreview();
  }

  function setNewsBar(n) {
    const bar = $("newsBar");
    bar.className = n.mood === "bull" ? "bull" : "bear";
    $("newsText").textContent = (n.mood === "bull" ? "📈 " : "📉 ") + n.text;
    $("newsTime").textContent = n.t;
  }

  // ---------- 事件反应 (多巴胺核心) ----------
  function handleEvent(ev) {
    if (ev.type === "fill") {
      SFX.fill();
      const sym = COIN_UI[ev.coin]?.name.split("/")[0] || ev.coin;
      toast(`${ev.maker ? "📌 挂单成交" : "⚡ 开仓"} ${sym} ${ev.side === 1 ? "做多" : "做空"} ${ev.lev}x @ ${fmtPrice(ev.price)}`, "success");
      shakeScreen(false);
      fetchKlines();
    } else if (ev.type === "close") {
      const sym = COIN_UI[ev.coin]?.name.split("/")[0] || ev.coin;
      const win = ev.pnl >= 0;
      const big = Math.abs(ev.roi) >= 15;
      if (ev.reason === "tp") SFX.tp(); else win ? SFX.profit(big) : SFX.loss();
      const cls = ev.reason === "tp" ? "gold" : (win ? "success" : "danger");
      const tag = { tp: "🎯 止盈触发", sl: "🛡️ 止损触发", manual: "✂️ 平仓" }[ev.reason] || "平仓";
      toast(`${tag} ${sym} ${ev.lev}x — <span class="t-big ${win ? "up" : "down"}">${ev.pnl >= 0 ? "+" : ""}${fmtN(ev.pnl)} U (${ev.roi >= 0 ? "+" : ""}${ev.roi}%)</span>`, cls, 3400);
      if (win && big) {
        confetti(innerWidth / 2, innerHeight * 0.35, 110);
        SFX.achieve();
      }
      if (navigator.vibrate) navigator.vibrate(win ? [30, 30, 60] : 60);
      fetchKlines();
    } else if (ev.type === "liq") {
      SFX.liq();
      shakeScreen(true);
      const veil = $("liqVeil");
      veil.classList.add("on");
      setTimeout(() => veil.classList.remove("on"), 1200);
      toast(`💀 <span class="t-big">爆仓!</span> ${COIN_UI[ev.coin]?.name.split("/")[0]} ${ev.lev}x — 保证金 ${fmtN(ev.margin)} U 全部损失`, "danger", 4200);
      confetti(innerWidth / 2, innerHeight * 0.4, 40, ["#f6465d", "#7a2c35", "#3a3a3a"]);
    } else if (ev.type === "news") {
      SFX.news();
      setNewsBar(ev);
      toast(`${ev.mood === "bull" ? "📈" : "📉"} <b>快讯</b> ${ev.text}`, ev.mood === "bull" ? "success" : "danger", 3600);
    } else if (ev.type === "regime") {
      toast(`🔄 市场切换 → <b>${ev.name}</b>`, "gold");
    } else if (ev.type === "achievement") {
      SFX.achieve();
      confetti(innerWidth * 0.5, innerHeight * 0.3, 90, ["#b78aff", "#f0b90b", "#ffffff", "#3f8cff"]);
      toast(`${ev.icon} <b>成就解锁: ${ev.name}</b><br><span class="dim">${ev.desc} · +50 XP</span>`, "achieve", 3800);
    } else if (ev.type === "funding") {
      const sign = ev.amount >= 0 ? "支付" : "收取";
      toast(`💰 资金费率结算: ${sign} ${fmtN(Math.abs(ev.amount))} U (费率 ${ev.rate}%)`, "info");
    } else if (ev.type === "levelup") {
      SFX.levelup();
      confettiRain(160);
      toast(`🎊 <span class="t-big">升级!</span> Lv.${ev.level} ${ev.title}`, "gold", 4200);
    }
    if (window.tabEvent) { try { window.tabEvent(ev); } catch (e) {} }
  }

  // ---------- K 线 ----------
  async function fetchKlines(keepView) {
    try {
      const r = await fetch(`/api/klines?coin=${S.coin}&interval=${S.interval}&limit=320`);
      const d = await r.json();
      if (!d.ok) return;
      S.chart.setData(d.candles, S.interval, keepView);
      updateChartLines();
    } catch (e) {}
  }
  function refreshChart(keepView) { S.chart.render(); }

  function updateChartLines() {
    const st = S.lastState; if (!st) { S.chart.setLines([]); return; }
    const css = getComputedStyle(document.body);
    const up = css.getPropertyValue("--up").trim(), down = css.getPropertyValue("--down").trim();
    const lines = [];
    for (const p of st.positions.filter(p => p.coin === S.coin)) {
      lines.push({ price: p.entry, color: "#f0b90b", dash: [8, 5], label: `开仓 ${p.lev}x` });
      lines.push({ price: p.liq, color: up, dash: [4, 4], label: "强平" });
      if (p.tp) lines.push({ price: p.tp, color: "#2ebd85", dash: [3, 4], label: "止盈" });
      if (p.sl) lines.push({ price: p.sl, color: "#f6465d", dash: [3, 4], label: "止损" });
    }
    S.chart.setLines(lines);
  }

  // ---------- 逐币交易规则 (对齐币安阶梯: 杠杆上限/快捷档位/MMR/最小名义) ----------
  let __rulesCoin = null;
  function applyCoinRules(st) {
    const m = st.coins?.[S.coin];
    if (!m || !m.max_lev || __rulesCoin === S.coin) return;
    __rulesCoin = S.coin;
    const slider = $("levSlider");
    slider.max = m.max_lev;
    if (+slider.value > m.max_lev) { slider.value = m.max_lev; $("levVal").textContent = m.max_lev + "x"; }
    const presets = [1, 5, 10, 20, 50, 100].filter(l => l <= m.max_lev);
    if (!presets.includes(m.max_lev)) presets.push(m.max_lev);   // 150x / 75x 尾档
    const q = document.querySelector(".lev-quick");
    q.innerHTML = presets.map(l =>
      `<button data-l="${l}"${+slider.value === l ? ' class="active"' : ""}>${l}x</button>`).join("");
    const tip = document.getElementById("tpFeeTip");
    if (tip) tip.textContent =
      `吃单 0.05% · 挂单 0.02% · ${S.coin.replace("USDT", "")} 最小名义 ${m.min_notional} USDT · 一档维持保证金率 MMR ${(m.mmr * 100).toFixed(1)}% (币安阶梯)`;
    updatePreview();
  }

  // ---------- 币种/周期切换 ----------
  window.switchCoin = function (sym) {
    if (S.coin === sym) return;
    SFX.click();
    S.coin = sym;
    __rulesCoin = null;   // 强制重新应用新币种规则 (滑杆上限/快捷档位/MMR提示)
    S.lastState = null;
    fetchKlines();
    poll();
  };

  window.__chartResize = function () { if (S.chart) S.chart.resize(); };
  window.__closeChartLines = updateChartLines;

  window.openCloseLimit = function (pid) {
    const p = S.lastState?.positions?.find(x => x.id === pid);
    if (!p) return;
    const html = `
      <p class="dim">为 ${COIN_UI[p.coin].name} ${p.side === 1 ? "多" : "空"}单挂一条 reduce-only 限价平仓委托 (maker 费率 0.02%)。</p>
      <div class="tp-row" style="margin-top:10px"><span class="tp-label">触发平仓价</span>
        <input type="number" id="clPrice" step="any" value="${p.side === 1 ? (p.mark * 1.01).toFixed(2) : (p.mark * 0.99).toFixed(2)}"></div>
      <div class="tp-row"><span class="tp-label">平仓比例</span>
        <select id="clFrac" style="width:100%;background:var(--panel2);border:1px solid var(--border);color:var(--text);border-radius:7px;padding:8px">
          <option value="0.25">25%</option><option value="0.5">50%</option><option value="1" selected>100%</option>
        </select></div>
      <div style="text-align:right"><button class="btn-gold" id="clOk">挂单</button></div>`;
    const wrap = openModal("📌 限价平仓 (Reduce-Only)", html);
    wrap.querySelector("#clOk").onclick = async () => {
      const r = await api("/api/close_limit", { position_id: pid, price: parseFloat(wrap.querySelector("#clPrice").value), fraction: parseFloat(wrap.querySelector("#clFrac").value) });
      toast(r.ok ? "✅ 限价平仓已挂出" : "❌ " + r.msg, r.ok ? "success" : "danger");
      if (r.ok) closeModal();
    };
  };

  function bindIvTabs() {
    $("ivTabs").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      document.querySelectorAll("#ivTabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      S.interval = b.dataset.iv;
      fetchKlines();
    });
    $("tgMA").onclick = () => { S.chart.showMA = !S.chart.showMA; $("tgMA").classList.toggle("active", S.chart.showMA); S.chart.render(); };
    $("tgBOLL").onclick = () => { S.chart.showBOLL = !S.chart.showBOLL; $("tgBOLL").classList.toggle("active", S.chart.showBOLL); S.chart.render(); };
    $("tgRSI").onclick = () => { toggleInd("rsi"); };
    $("tgMACD").onclick = () => { toggleInd("macd"); };
  }
  function toggleInd(name) {
    if (S.chart.indicator === name) { S.chart.indicator = "none"; }
    else S.chart.indicator = name;
    $("tgRSI").classList.toggle("active", S.chart.indicator === "rsi");
    $("tgMACD").classList.toggle("active", S.chart.indicator === "macd");
    S.chart.render();
  }

  // ---------- API ----------
  async function api(url, body) {
    try {
      const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
      return await r.json();
    } catch (e) { return { ok: false, msg: "网络错误" }; }
  }

  document.addEventListener("visibilitychange", () => { if (!document.hidden) { poll(); fetchKlines(true); } });
  addEventListener("resize", () => { if (S.chart) S.chart.resize(); });

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { init(); bindIvTabs(); });
  else { init(); bindIvTabs(); }
})();
