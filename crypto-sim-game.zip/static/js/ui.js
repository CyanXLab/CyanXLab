/* UI 渲染层 —— 盘口 / 成交流 / 持仓 / 挂单 / 历史 / 战绩 / 成就 / 模态内容 */
(function () {
  const COIN_UI = {
    BTCUSDT:  { icon: "₿", name: "BTC/USDT", cname: "比特币" },
    ETHUSDT:  { icon: "Ξ", name: "ETH/USDT", cname: "以太坊" },
    SOLUSDT:  { icon: "◎", name: "SOL/USDT", cname: "Solana" },
    DOGEUSDT: { icon: "Ð", name: "DOGE/USDT", cname: "狗狗币" },
    BNBUSDT:  { icon: "B", name: "BNB/USDT", cname: "币安币" },
  };
  window.COIN_UI = COIN_UI;

  function fmtN(n, d) {
    if (n == null || isNaN(n)) return "--";
    return Number(n).toLocaleString("zh-CN", { minimumFractionDigits: d == null ? 2 : d, maximumFractionDigits: d == null ? 2 : d });
  }
  window.fmtN = fmtN;
  function fmtQty(q) {
    if (q >= 1000) return fmtN(q, 0);
    if (q >= 1) return fmtN(q, 2);
    return q.toFixed(4);
  }
  window.fmtQty = fmtQty;
  function pnlClass(v) { return v >= 0 ? "up" : "down"; }
  function pnlStr(v, withSign) {
    const s = v >= 0 ? (withSign ? "+" : "") : "";
    return `<span class="${pnlClass(v)}">${s}${fmtN(v)}</span>`;
  }

  // ---------- 顶栏币种 Tabs ----------
  window.renderCoinTabs = function (coins, active) {
    const box = document.getElementById("coinTabs");
    if (!box) return;
    box.innerHTML = "";
    for (const [sym, c] of Object.entries(coins)) {
      const ui = COIN_UI[sym];
      const b = document.createElement("button");
      b.className = "coin-tab" + (sym === active ? " active" : "");
      b.dataset.sym = sym;
      const cls = c.chg24 >= 0 ? "up" : "down";
      b.innerHTML = `<span class="ct-icon">${ui.icon}</span><span class="ct-name">${ui.name.split("/")[0]}</span><span class="ct-price ${cls}">${window.fmtPrice(c.price)}</span>`;
      b.onclick = () => window.switchCoin(sym);
      box.appendChild(b);
    }
  };

  // ---------- 左侧市场列表 (欧易式) ----------
  window.renderWatchlist = function (coins, active) {
    const el = document.getElementById("watchList");
    if (!el) return;
    el.innerHTML = Object.entries(coins).map(([sym, c]) => {
      const ui = COIN_UI[sym];
      const cls = c.chg24 >= 0 ? "up" : "down";
      return `<div class="wl-item${sym === active ? " active" : ""}" onclick="window.switchCoin('${sym}')">
        <span class="wl-icon">${ui.icon}</span>
        <span class="wl-mid"><b>${ui.name.split("/")[0]}<i>/USDT</i></b><small>${ui.cname}</small></span>
        <span class="wl-right"><span class="wl-px ${cls}">${window.fmtPrice(c.price)}</span>
        <span class="wl-chip ${cls}">${c.chg24 >= 0 ? "+" : ""}${c.chg24.toFixed(2)}%</span></span>
      </div>`;
    }).join("");
  };

  // ---------- 盘口 ----------
  window.renderBook = function (book, last, coin) {
    const asksEl = document.getElementById("bookAsks");
    const bidsEl = document.getElementById("bookBids");
    if (!book || !book.asks || !book.asks.length) return;
    const maxSum = Math.max(...book.asks.slice(0, 10).map(a => a[1]), ...book.bids.slice(0, 10).map(b => b[1])) || 1;
    const rowHtml = (p, q, side) => {
      const pct = Math.min(100, q / maxSum * 100);
      return `<div class="bk-row ${side}">
        <span class="bk-p">${window.fmtPrice(p)}</span>
        <span>${fmtQty(q)}</span>
        <span class="bk-sum">${(p * q / 1e4).toFixed(1)}</span>
        <i class="bk-depth" style="width:${pct}%;background:${side === "asks" ? "var(--down)" : "var(--up)"}"></i>
      </div>`;
    };
    asksEl.innerHTML = book.asks.slice(0, 9).reverse().map(a => rowHtml(a[0], a[1], "asks")).join("");
    bidsEl.innerHTML = book.bids.slice(0, 9).map(b => rowHtml(b[0], b[1], "bids")).join("");
    const lastEl = document.getElementById("bookLast");
    lastEl.textContent = window.fmtPrice(last);
    lastEl.className = last >= book.asks[0][0] ? "up" : (last <= book.bids[0][0] ? "down" : "");
    const spread = book.asks[0][0] - book.bids[0][0];
    document.getElementById("bookSpread").textContent = `价差 ${window.fmtPrice(spread)} (${(spread / last * 100).toFixed(3)}%)`;
    document.getElementById("bookCoin").textContent = COIN_UI[coin].name;
    // 买卖力量比 (欧易式红绿条)
    const bSum = book.bids.slice(0, 9).reduce((s, b) => s + b[1] * b[0], 0);
    const aSum = book.asks.slice(0, 9).reduce((s, a) => s + a[1] * a[0], 0);
    const bPct = (bSum / (bSum + aSum) * 100) || 50;
    const br = document.getElementById("brBuy"), bt = document.getElementById("brTxt");
    if (br) br.style.width = bPct.toFixed(1) + "%";
    if (bt) bt.textContent = `B ${bPct.toFixed(0)}%`;
    const sellPct = (100 - bPct).toFixed(0);
    const brEl = document.querySelector(".book-ratio");
    if (brEl) {
      let sTxt = brEl.querySelector(".br-sell");
      if (!sTxt) { sTxt = document.createElement("span"); sTxt.className = "br-txt br-sell"; brEl.appendChild(sTxt); }
      sTxt.textContent = `S ${sellPct}%`;
    }
  };

  // ---------- 成交流 ----------
  window.renderTape = function (tape) {
    const el = document.getElementById("tapeList");
    if (!el || !tape) return;
    el.innerHTML = tape.slice(0, 22).map(t => `
      <div class="tape-row">
        <span class="${t.side === "buy" ? "t-buy" : "t-sell"}">${window.fmtPrice(t.p)}</span>
        <span>${fmtQty(t.q)}</span>
        <span class="${t.side === "buy" ? "t-buy" : "t-sell"}">${t.side === "buy" ? "B" : "S"} ${fmtN(t.usd, 0)}</span>
      </div>`).join("");
  };

  // ---------- 图表头 ----------
  window.renderChartHead = function (sym, c, displayPrice, fundingRate, regimeName, regime) {
    const ui = COIN_UI[sym];
    document.getElementById("chIcon").textContent = ui.icon;
    document.getElementById("chName").textContent = ui.name;
    document.getElementById("chRegime").textContent = regimeName;
    document.getElementById("chRegime").className = "regime-chip r" + regime;
    let realEl = document.getElementById("chRealPx");
    const real = (window.__S && window.__S.real_prices) ? window.__S.real_prices[sym] : null;
    if (real && real.price) {
      if (!realEl) {
        realEl = document.createElement("span");
        realEl.id = "chRealPx";
        realEl.className = "realpx-badge";
        realEl.title = "币安现货实时价格 (ccxt 公开行情, 离线时隐藏)";
        document.getElementById("chName").parentElement.appendChild(realEl);
      }
      realEl.style.display = "inline-block";
      realEl.textContent = `币安实时 $${window.fmtPrice(real.price)} ${real.chg >= 0 ? "+" : ""}${real.chg}%`;
    } else if (realEl) {
      realEl.style.display = "none";
    }
    const priceEl = document.getElementById("chPrice");
    const prev = parseFloat(priceEl.dataset.v || 0);
    priceEl.textContent = window.fmtPrice(displayPrice);
    if (prev && displayPrice !== prev) {
      priceEl.classList.remove("up", "down");
      void priceEl.offsetWidth;
      priceEl.classList.add(displayPrice > prev ? "up" : "down");
    }
    priceEl.dataset.v = displayPrice;
    const chg = document.getElementById("chChg");
    chg.textContent = `${c.chg24 >= 0 ? "+" : ""}${c.chg24.toFixed(2)}%`;
    chg.className = "chg-chip " + (c.chg24 >= 0 ? "up" : "down");
    document.getElementById("chHigh").textContent = window.fmtPrice(c.high24);
    document.getElementById("chLow").textContent = window.fmtPrice(c.low24);
    document.getElementById("chVol").textContent = window.fmtVol ? window.fmtVol(c.vol24) : fmtN(c.vol24, 0);
    const markEl = document.getElementById("chMark");
    if (markEl) markEl.textContent = window.fmtPrice(displayPrice);
    const amtEl = document.getElementById("chAmt");
    if (amtEl) amtEl.textContent = window.fmtVol ? window.fmtVol((c.vol24 || 0) * (displayPrice || c.price || 0)) : "--";
    const fEl = document.getElementById("chFund");
    fEl.textContent = (fundingRate >= 0 ? "+" : "") + fundingRate.toFixed(4) + "%";
    fEl.className = fundingRate >= 0 ? "up" : "down";
  };

  // ---------- 持仓 ----------
  window.renderPositions = function (poss, marks) {
    const el = document.getElementById("subPanel");
    document.getElementById("posCount").textContent = poss.length;
    if (!poss.length) {
      el.innerHTML = '<div class="empty-tip">暂无持仓 — 用右侧(或下方)下单面板开仓, 体验杠杆的助推与撕裂 ⚡</div>';
      return;
    }
    let html = '<table class="grid"><tr><th>合约</th><th>方向</th><th>保证金</th><th>开仓价</th><th>标记价</th><th>强平价</th><th>未实现盈亏</th><th>回报率</th><th>操作</th></tr>';
    for (const p of poss) {
      html += `<tr>
        <td>${COIN_UI[p.coin].name} <span class="lev-chip">${p.lev}x</span></td>
        <td><span class="side-badge ${p.side === 1 ? "long" : "short"}">${p.side === 1 ? "做多" : "做空"}</span></td>
        <td>${fmtN(p.margin)}</td>
        <td>${window.fmtPrice(p.entry)}</td>
        <td>${window.fmtPrice(p.mark)}</td>
        <td class="down">${window.fmtPrice(p.liq)}</td>
        <td class="${pnlClass(p.u_pnl)}">${p.u_pnl >= 0 ? "+" : ""}${fmtN(p.u_pnl)}<br><small>${p.u_roi >= 0 ? "+" : ""}${p.u_roi.toFixed(2)}%</small></td>
        <td class="${pnlClass(p.u_pnl)}">${p.u_roi >= 0 ? "+" : ""}${p.u_roi.toFixed(2)}%</td>
        <td>
          <button class="row-btn" onclick="window.openTpsl(${p.id})">止盈损</button>
          <button class="row-btn" onclick="window.openCloseLimit(${p.id})">限价平</button>
          <button class="row-btn danger" onclick="window.closePos(${p.id}, 0.5)">平半</button>
          <button class="row-btn danger" onclick="window.closePos(${p.id}, 1)">平仓</button>
        </td>
      </tr>`;
    }
    el.innerHTML = html + "</table>";
  };

  // ---------- 挂单 ----------
  window.renderOrders = function (orders) {
    const el = document.getElementById("subPanel");
    document.getElementById("ordCount").textContent = orders.length;
    if (!orders.length) { el.innerHTML = '<div class="empty-tip">暂无限价挂单</div>'; return; }
    let html = '<table class="grid"><tr><th>合约</th><th>方向</th><th>杠杆</th><th>委托价</th><th>保证金</th><th>操作</th></tr>';
    for (const o of orders) {
      html += `<tr>
        <td>${COIN_UI[o.coin].name}</td>
        <td><span class="side-badge ${o.side === 1 ? "long" : "short"}">${o.side === 1 ? "买入开多" : "卖出开空"}</span></td>
        <td class="lev-chip">${o.lev}x</td>
        <td>${window.fmtPrice(o.price)}</td>
        <td>${fmtN(o.margin)}</td>
        <td><button class="row-btn danger" onclick="window.cancelOrder(${o.id})">撤销</button></td>
      </tr>`;
    }
    el.innerHTML = html + "</table>";
  };

  // ---------- 平仓记录 ----------
  window.renderHistory = function (hist) {
    const el = document.getElementById("subPanel");
    if (!hist || !hist.length) { el.innerHTML = '<div class="empty-tip">还没有平仓记录</div>'; return; }
    const reasonMap = { tp: "止盈", sl: "止损", liq: "强平", manual: "手动" };
    let html = '<table class="grid"><tr><th>合约</th><th>方向</th><th>杠杆</th><th>开仓→平仓</th><th>盈亏</th><th>回报率</th><th>来源</th></tr>';
    for (const h of hist) {
      html += `<tr>
        <td>${COIN_UI[h.coin].name}</td>
        <td><span class="side-badge ${h.side === 1 ? "long" : "short"}">${h.side === 1 ? "多" : "空"}</span></td>
        <td class="lev-chip">${h.lev}x</td>
        <td>${window.fmtPrice(h.entry)} → ${window.fmtPrice(h.close)}</td>
        <td>${pnlStr(h.pnl, true)}</td>
        <td class="${pnlClass(h.roi)}">${h.roi >= 0 ? "+" : ""}${h.roi.toFixed(2)}%</td>
        <td class="dim">${reasonMap[h.reason] || h.reason}</td>
      </tr>`;
    }
    el.innerHTML = html + "</table>";
  };

  // ---------- 战绩 ----------
  window.renderStats = function (g) {
    const el = document.getElementById("subPanel");
    const streakTxt = g.streak >= 3 ? ` 🔥x${g.streak}` : "";
    const missions = (window.__S && window.__S.daily_missions) || [];
    const missionHtml = missions.length ? `
      <div class="missions">
        <div class="panel-title" style="padding:8px 12px 2px">🎯 每日任务 <span class="panel-sub">模拟日刷新 · 奖励自动到账</span></div>
        ${missions.map(m => `
          <div class="mission ${m.done ? "done" : ""}">
            <span>${m.done ? "✅" : "🎯"} ${m.desc}</span>
            <span class="dim11">${Math.min(m.progress, m.target)}/${m.target} · +${m.reward} U</span>
            <div class="mission-bar"><i style="width:${Math.min(100, m.progress / m.target * 100)}%"></i></div>
          </div>`).join("")}
      </div>` : "";
    el.innerHTML = `
      <div class="stats-grid">
        <div class="sg-item"><span>总收益率</span><b class="${pnlClass(g.roi)}">${g.roi >= 0 ? "+" : ""}${g.roi.toFixed(2)}%</b></div>
        <div class="sg-item"><span>胜率 (${g.trades}笔)</span><b>${g.win_rate}%</b></div>
        <div class="sg-item"><span>盈利因子</span><b>${g.profit_factor}</b></div>
        <div class="sg-item"><span>最大回撤</span><b class="down">${g.max_dd}%</b></div>
        <div class="sg-item"><span>当前连胜</span><b>${g.streak}${streakTxt}</b></div>
        <div class="sg-item"><span>最长连胜</span><b>${g.best_streak}</b></div>
        <div class="sg-item"><span>历史峰值</span><b>${fmtN(g.peak)}</b></div>
        <div class="sg-item"><span>盈/亏笔数</span><b><span class="up">${g.wins}</span>/<span class="down">${g.losses}</span></b></div>
      </div>
      <canvas id="equityMini"></canvas>${missionHtml}`;
    window.drawEquityMini(g.equity_curve);
  };

  window.drawEquityMini = function (curve) {
    const cv = document.getElementById("equityMini");
    if (!cv || !curve || curve.length < 2) return;
    const dpr = devicePixelRatio || 1;
    const w = cv.clientWidth || cv.parentElement.clientWidth, h = 120;
    cv.width = w * dpr; cv.height = h * dpr; cv.style.height = h + "px";
    const ctx = cv.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const vals = curve.map(p => p[1]);
    const lo = Math.min(...vals), hi = Math.max(...vals);
    const span = hi - lo || 1;
    const css = getComputedStyle(document.body);
    const up = css.getPropertyValue("--up").trim(), down = css.getPropertyValue("--down").trim();
    const base = 10000;
    const col = vals[vals.length - 1] >= base ? up : down;
    ctx.clearRect(0, 0, w, h);
    // 基准线 10000
    const y0 = 10 + (hi - base) / span * (h - 24);
    ctx.strokeStyle = "#3a4149"; ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(0, y0); ctx.lineTo(w, y0); ctx.stroke(); ctx.setLineDash([]);
    ctx.strokeStyle = col; ctx.lineWidth = 1.6;
    ctx.beginPath();
    curve.forEach((p, i) => {
      const x = i / (curve.length - 1) * (w - 8) + 4;
      const y = 10 + (hi - p[1]) / span * (h - 24);
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    });
    ctx.stroke();
    // 渐变填充
    ctx.lineTo(w - 4, h); ctx.lineTo(4, h); ctx.closePath();
    ctx.globalAlpha = 0.12; ctx.fillStyle = col; ctx.fill(); ctx.globalAlpha = 1;
  };

  // ---------- 成就模态 ----------
  window.renderAchModal = function (achs) {
    const unlocked = achs.filter(a => a.unlocked).length;
    let html = `<p class="dim">已解锁 <b class="hl">${unlocked}</b> / ${achs.length} 项成就 · 解锁成就获得 +50 XP</p><div class="ach-grid" style="margin-top:10px">`;
    for (const a of achs) {
      html += `<div class="ach-card ${a.unlocked ? "unlocked" : ""}">
        <span class="a-icon">${a.unlocked ? a.icon : "🔒"}</span>
        <div><b>${a.name}</b><span>${a.desc}</span></div>
      </div>`;
    }
    window.openModal(`🏆 成就殿堂 (${unlocked}/${achs.length})`, html + "</div>", { wide: true });
  };

  // ---------- 模型揭秘模态 ----------
  window.renderModelModal = function (meta, regime) {
    const symList = Object.keys(meta);
    const m = meta["BTCUSDT"];
    const rn = ["牛市", "熊市", "震荡"];
    const srcMap = { binance_real: "Binance 真实历史行情", synthetic_fallback: "校准合成行情(离线兜底)" };
    let html = `
      <h4>🧠 引擎学习摘要 (以 BTCUSDT 为例)</h4>
      <div class="model-sec">
        <div class="ms-row"><span>训练数据</span><b>${srcMap[m.source] || m.source} · ${m.n_samples.toLocaleString()} 根小时线</b></div>
        <div class="ms-row"><span>年化波动率</span><b>${(m.ann_vol * 100).toFixed(1)}%</b></div>
        <div class="ms-row"><span>收益峰度 (正态=3)</span><b>${m.kurt.toFixed(1)} → 胖尾 t 分布 ν=${m.nu.toFixed(1)}</b></div>
        <div class="ms-row"><span>GARCH(1,1) α / β / ω</span><b>${m.garch.alpha} / ${m.garch.beta} / ${m.garch.omega.toExponential(1)}</b></div>
        <div class="ms-row"><span>跳变强度 λ</span><b>${(m.jump_lambda * 100).toFixed(2)}% /小时 · 历史极端池 ${m.jump_pool_n} 次</b></div>
      </div>
      <h4>🔀 市态转移矩阵 (行=当前, 列=下一小时, 已做游戏节奏加速)</h4>
      <div class="markov-grid">`;
    m.markov.forEach((row, i) => {
      row.forEach((p, j) => {
        const a = Math.round(p * 255);
        html += `<div class="markov-cell" style="background:rgba(240,185,11,${(p * 0.55).toFixed(2)})">
          <b>${(p * 100).toFixed(1)}%</b><i>${rn[i]}→${rn[j]}</i></div>`;
      });
    });
    html += `</div>
      <h4>🌊 日内波动率季节曲线 (24h, 学习自历史)</h4>
      <div class="season-bars">`;
    const se = m.season, seMax = Math.max(...se);
    for (const v of se) html += `<i style="height:${(v / seMax * 100).toFixed(0)}%"></i>`;
    html += `</div><p class="dim" style="margin-top:4px">UTC+8 时间轴 — 亚洲/欧美盘交替造成的波动起伏被引擎捕获</p>`;
    html += `<h4>🪙 各币种学习参数</h4><div class="model-sec">`;
    for (const s of symList) {
      const mm = meta[s];
      html += `<div class="ms-row"><span>${COIN_UI[s].icon} ${COIN_UI[s].cname}</span>
        <b>年化 ${(mm.ann_vol * 100).toFixed(0)}% · β(vs BTC) ${mm.beta_btc.toFixed(2)} · ν ${mm.nu.toFixed(1)}</b></div>`;
    }
    html += `</div>
      <p class="dim">生成机制: GARCH(1,1) 波动率动态 + 三态马尔可夫市态链 + 标准化 Student-t 胖尾 + 稀疏跳变(联动新闻) + 布朗桥分钟级分配 + 共享市场因子跨币相关。所有参数均从上方真实历史数据估计而来, 每局行情都是"从未存在但统计上像真的一样"的新路径。</p>`;
    window.openModal("🧠 模型揭秘 — 引擎从历史数据学到了什么", html, { wide: true });
  };

  // ---------- 快讯模态 ----------
  window.renderNewsModal = function (news) {
    let html = "";
    if (!news.length) html = '<p class="dim">暂无快讯</p>';
    for (const n of news) {
      html += `<div class="news-item"><span class="n-time">${n.t}</span>
        <span class="${n.mood === "bull" ? "up" : "down"}">${n.mood === "bull" ? "📈" : "📉"}</span> ${n.text}</div>`;
    }
    window.openModal("📰 市场快讯", html);
  };

  // ---------- 帮助 / 开局模态 ----------
  window.renderHelpModal = function (firstTime) {
    const html = `
      <h4>🎮 你是谁</h4>
      <p>你是1名合约交易员, 初始资金 <span class="hl">10,000 USDT</span>。市场由 AI 引擎驱动 — 它从 5 大币种 2 年真实行情中学习了波动率聚集、牛熊市态、胖尾分布与极端跳变, 生成统计特征一致的全新行情。默认 <span class="hl">1x 实时流速</span> (与现实一致), 顶栏可切 10x/60x/300x 加速 — 60x 下 1 分钟 K 线 1 秒走完, 是短线肾上腺素模式。</p>
      <h4>⚡ 怎么玩 (短线投机)</h4>
      <p>· 选择币种 → 杠杆 (BTC/ETH 1~150x, 山寨 1~75x · 币安阶梯) → 保证金 → <b>做多/做空</b>。市价立即成交, 限价挂单等回调。<br>
      · 建议设置<b>止盈止损</b>: 到价自动平仓。杠杆放大收益也放大爆仓速度 — 强平价会画在图上。<br>
      · 资金费率每 8 模拟小时结算一次, 持仓过久会被磨损。<br>
      · 利空快讯 → 暴跌; 利好快讯 → 拉升。盯紧顶部快讯条, 抢消息就是抢钱。</p>
      <h4>🏆 成长系统</h4>
      <p>每笔交易获得 XP → 升级头衔 (韭菜新兵 → 币圈传奇) · 20 项成就 · 连胜火焰 · 权益曲线战绩。爆仓不可怕 — 那也是一枚成就 🐣。</p>
      <h4>🧠 学习模式</h4>
      <p>点击顶栏 🧠 <b>模型揭秘</b>, 查看引擎从历史数据学到的全部参数。理解"为什么杠杆会爆仓"、"什么是波动率聚集", 比赚钱更重要。</p>
      <p class="dim">⚠️ 本游戏仅为编程演示与市场教育用途, 所有行情均为算法模拟, 不构成任何投资建议。真实交易远比模拟残酷, 请敬畏风险。</p>
      <div style="text-align:center;display:flex;gap:10px;justify-content:center;align-items:center">
        <button class="btn-ghost" onclick="window.closeModal();window.__started()">跳过引导 →</button>
        <button class="btn-gold" onclick="window.closeModal();window.__started()">⚡ 开始冲单</button>
      </div>
      <p class="dim" style="text-align:center;margin-top:8px;font-size:11px">提示: 点击弹窗外部空白处也可随时关闭 · 玩法说明见顶栏 ❓</p>`;
    window.openModal(firstTime ? "⚡ CoinSprint 合约冲刺" : "❓ 玩法说明", html, { wide: true });
  };
})();
