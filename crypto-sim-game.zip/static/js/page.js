/* CoinSprint v1.1 —— 子站共享脚本 */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

async function api(path, opts = {}) {
  const r = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...opts,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  try {
    return await r.json();
  } catch {
    return { ok: false, msg: "HTTP " + r.status };
  }
}

function toast(msg, type = "") {
  const d = document.createElement("div");
  d.className = "toast " + type;
  d.textContent = msg;
  $("#toastRoot").appendChild(d);
  setTimeout(() => d.remove(), 3200);
}

const fmt = (n, d = 2) => (n === null || n === undefined || isNaN(n)) ? "--" :
  Number(n).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const fmtPct = n => (n >= 0 ? "+" : "") + Number(n).toFixed(2) + "%";
const cls = n => n >= 0 ? "up" : "down";
const shortAddr = a => a ? a.slice(0, 8) + "…" + a.slice(-6) : "--";
const timeStr = ts => new Date(ts * 1000).toLocaleTimeString("zh-CN", { hour12: false });

/* 顶栏余额 (赌场钱包视角) */
async function updateNavBalance() {
  try {
    const r = await api("/api/games/state");
    if (r.ok) {
      $("#snBalance").textContent = "Wallet " + fmt(r.balance) + " USDT";
      localStorage.setItem("cs_username", r.username);
      $("#snUser").textContent = "👤 " + r.username.slice(0, 6);
    }
  } catch {}
}
if (typeof $ !== "undefined" && $("#snBalance")) updateNavBalance();
