/* CandleChart —— 专业级 Canvas K 线图 (无依赖)
 * 支持: 蜡烛图 + 成交量 + MA/BOLL 叠加 + RSI/MACD 副图 + 十字光标 + 拖拽平移 + 滚轮/双指缩放
 */
(function () {
  const PAD_R = 66, PAD_B = 22, VOL_H_RATIO = 0.16, SUB_H = 86, GAP = 8;

  function fmtPrice(p) {
    if (p == null || isNaN(p)) return '--';
    const a = Math.abs(p);
    if (a >= 10000) return p.toLocaleString('zh-CN', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
    if (a >= 100) return p.toFixed(2);
    if (a >= 1) return p.toFixed(3);
    if (a >= 0.01) return p.toFixed(5);
    return p.toFixed(6);
  }
  function fmtVol(v) {
    if (v >= 1e9) return (v / 1e9).toFixed(2) + 'B';
    if (v >= 1e6) return (v / 1e6).toFixed(2) + 'M';
    if (v >= 1e3) return (v / 1e3).toFixed(2) + 'K';
    return v.toFixed(1);
  }
  function fmtTime(ts, iv) {
    const d = new Date(ts * 1000);
    const p = (n) => (n < 10 ? '0' + n : n);
    if (iv === '1m' || iv === '5m' || iv === '15m') return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
    if (iv === '1h' || iv === '4h') return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:00`;
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }

  class CandleChart {
    constructor(canvas, opts) {
      this.cv = canvas;
      this.ctx = canvas.getContext('2d');
      this.opts = opts || {};
      this.data = [];          // [ts,o,h,l,c,v]
      this.interval = '1m';
      this.view = { right: 0, cw: 8 };   // right: 最右可见K线索引(浮点, 负=右留白), cw: 每根宽度
      this.cross = null;       // {x, y}
      this.lines = [];         // 持仓线 {price, color, dash, label}
      this.indicator = 'none'; // none | rsi | macd
      this.showMA = true;
      this.showBOLL = false;
      this.drag = null;
      this.pinch = null;
      this._bind();
      this._resize();
      this.render();
    }

    _resize() {
      const r = this.cv.parentElement.getBoundingClientRect();
      this.w = Math.max(300, r.width);
      this.h = Math.max(240, r.height);
      const dpr = devicePixelRatio || 1;
      this.cv.width = this.w * dpr; this.cv.height = this.h * dpr;
      this.cv.style.width = this.w + 'px'; this.cv.style.height = this.h + 'px';
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    resize() { this._resize(); this.render(); }

    setData(candles, interval, keepView) {
      const prevLen = this.data.length;
      this.data = candles || [];
      this.interval = interval || this.interval;
      if (!keepView || this.view.right === 0) {
        this.view.right = 0;                 // 跟随最新
        if (this.view.cw < 3 || this.view.cw > 26) this.view.cw = Math.min(14, Math.max(5, this.w / 90));
      } else if (this.data.length !== prevLen) {
        this.view.right += (this.data.length - prevLen);  // 保持相对位置
      }
      this.render();
    }

    setLines(lines) { this.lines = lines || []; this.render(); }

    // 可视区价格范围
    _visibleRange() {
      const n = this.data.length;
      const plotW = this.w - PAD_R;
      const count = Math.max(10, Math.floor(plotW / this.view.cw));
      let end = n - 1 + this.view.right;   // 含 forming
      let start = end - count + 1;
      if (start < 0) { end -= start; start = 0; }
      if (end > n - 1) end = n - 1;
      return { start: Math.max(0, Math.floor(start)), end: Math.max(0, Math.ceil(end)), count, plotW };
    }

    _xOf(i, vr) {
      const plotW = this.w - PAD_R;
      const right = this.data.length - 1 + this.view.right;
      return plotW - (right - i) * this.view.cw - this.view.cw / 2;
    }

    render() {
      const ctx = this.ctx, W = this.w, H = this.h;
      const css = getComputedStyle(document.body);
      const C = {
        bg: css.getPropertyValue('--panel').trim() || '#161a1e',
        grid: css.getPropertyValue('--grid').trim() || '#1c2127',
        text: css.getPropertyValue('--muted').trim() || '#848e9c',
        up: css.getPropertyValue('--up').trim() || '#f6465d',
        down: css.getPropertyValue('--down').trim() || '#2ebd85',
        border: css.getPropertyValue('--border').trim() || '#2b3139',
        yellow: '#f0b90b',
      };
      this.colors = C;
      ctx.clearRect(0, 0, W, H);
      if (!this.data.length) {
        ctx.fillStyle = C.text; ctx.font = '13px sans-serif';
        ctx.fillText('等待行情数据...', W / 2 - 50, H / 2);
        return;
      }
      const vr = this._visibleRange();
      const subH = this.indicator !== 'none' ? SUB_H : 0;
      const mainH = (H - PAD_B - subH - (subH ? GAP : 0)) * (1 - VOL_H_RATIO);
      const volH = (H - PAD_B - subH - (subH ? GAP : 0)) * VOL_H_RATIO;
      const volY = mainH;
      const subY = mainH + volH + (subH ? GAP : 0);

      // ---- 价格范围 ----
      let lo = Infinity, hi = -Infinity, vMax = 0;
      for (let i = vr.start; i <= vr.end; i++) {
        const d = this.data[i];
        if (d[2] > hi) hi = d[2];
        if (d[3] < lo) lo = d[3];
        if (d[5] > vMax) vMax = d[5];
      }
      for (const ln of this.lines) {
        if (ln.price > hi * 0.7 && ln.price < hi * 1.4) { hi = Math.max(hi, ln.price); lo = Math.min(lo, ln.price); }
      }
      const padP = (hi - lo) * 0.08 || hi * 0.001;
      hi += padP; lo -= padP;
      const priceH = mainH - 8;
      const yOf = (p) => 4 + (hi - p) / (hi - lo) * priceH;
      const pOf = (y) => hi - (y - 4) / priceH * (hi - lo);

      // ---- 网格 + 价格轴 ----
      ctx.strokeStyle = C.grid; ctx.fillStyle = C.text;
      ctx.font = '10px -apple-system, sans-serif'; ctx.lineWidth = 1;
      const steps = 5;
      for (let s = 0; s <= steps; s++) {
        const y = 4 + priceH * s / steps;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W - PAD_R + 6, y); ctx.stroke();
        const p = pOf(y);
        ctx.textAlign = 'left';
        ctx.fillText(fmtPrice(p), W - PAD_R + 10, y + 3);
      }
      // 时间轴
      const tEvery = Math.max(1, Math.ceil(64 / this.view.cw));   // 保证标签间 >= 64px 不重叠
      ctx.textAlign = 'center';
      for (let i = vr.start; i <= vr.end; i++) {
        if ((i % tEvery) !== 0) continue;
        const x = this._xOf(i, vr);
        if (x < 0 || x > W - PAD_R) continue;
        ctx.strokeStyle = C.grid;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, mainH + volH); ctx.stroke();
        ctx.fillText(fmtTime(this.data[i][0], this.interval), x, H - 8);
      }

      // ---- 成交量 ----
      for (let i = vr.start; i <= vr.end; i++) {
        const d = this.data[i], x = this._xOf(i, vr);
        const bw = Math.max(1, this.view.cw * 0.66);
        const vh = vMax > 0 ? (d[5] / vMax) * (volH - 6) : 0;
        ctx.fillStyle = d[4] >= d[1] ? this._upA(0.45) : this._downA(0.45);
        ctx.fillRect(x - bw / 2, volY + volH - vh, bw, vh);
      }

      // ---- BOLL ----
      if (this.showBOLL) {
        const b = this._boll(20, 2);
        this._line(ctx, b.mid, vr, yOf, '#b78aff', 1);
        this._line(ctx, b.up, vr, yOf, '#b78aff66', 1);
        this._line(ctx, b.low, vr, yOf, '#b78aff66', 1);
      }
      // ---- MA ----
      if (this.showMA) {
        const mas = [[7, '#f0b90b'], [25, '#3f8cff'], [99, '#b78aff']];
        for (const [n, col] of mas) this._line(ctx, this._ma(n), vr, yOf, col, 1);
      }

      // ---- 蜡烛 ----
      const bw = Math.max(1, Math.round(this.view.cw * 0.66));
      for (let i = vr.start; i <= vr.end; i++) {
        const d = this.data[i], x = Math.round(this._xOf(i, vr));
        const up = d[4] >= d[1];
        const col = up ? C.up : C.down;
        ctx.strokeStyle = col; ctx.fillStyle = col;
        ctx.beginPath();
        const cx = Math.round(x) + 0.5;
        ctx.moveTo(cx, yOf(d[2])); ctx.lineTo(cx, yOf(d[3])); ctx.stroke();
        const y1 = yOf(Math.max(d[1], d[4])), y2 = yOf(Math.min(d[1], d[4]));
        if (up && this.view.cw > 2.5) {
          ctx.strokeStyle = C.up; ctx.strokeRect(x - bw / 2 + 0.5, y1 + 0.5, bw - 1, Math.max(1, y2 - y1));
        } else {
          ctx.fillRect(x - bw / 2, y1, bw, Math.max(1, y2 - y1));
        }
      }

      // ---- 最新价线 + 标签 ----
      const last = this.data[this.data.length - 1];
      const lastUp = last[4] >= last[1];
      const yl = yOf(last[4]);
      ctx.setLineDash([4, 3]); ctx.strokeStyle = lastUp ? C.up : C.down; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, yl); ctx.lineTo(W - PAD_R, yl); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = lastUp ? C.up : C.down;
      ctx.fillRect(W - PAD_R + 2, yl - 8, PAD_R - 4, 16);
      ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.font = 'bold 10px monospace';
      ctx.fillText(fmtPrice(last[4]), W - PAD_R + 6, yl + 3);

      // ---- 持仓/强平/TPSL 线 ----
      for (const ln of this.lines) {
        if (ln.price == null) continue;
        const y = yOf(ln.price);
        if (y < 0 || y > mainH) continue;
        ctx.setLineDash(ln.dash || [6, 4]);
        ctx.strokeStyle = ln.color; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W - PAD_R, y); ctx.stroke();
        ctx.setLineDash([]);
        if (ln.label) {
          ctx.fillStyle = ln.color;
          const tw = ctx.measureText(ln.label).width + 10;
          ctx.fillRect(6, y - 8, tw, 15);
          ctx.fillStyle = '#111'; ctx.textAlign = 'left'; ctx.font = 'bold 10px sans-serif';
          ctx.fillText(ln.label, 11, y + 3);
          ctx.font = '10px sans-serif';
        }
      }

      // ---- 副图指标 ----
      if (this.indicator !== 'none') {
        ctx.strokeStyle = C.border;
        ctx.strokeRect(0.5, subY + 0.5, W - PAD_R - 1, subH - 1);
        if (this.indicator === 'rsi') this._renderRSI(ctx, vr, subY, subH, C);
        else this._renderMACD(ctx, vr, subY, subH, C);
      } else {
        ctx.strokeStyle = C.border;
        ctx.beginPath(); ctx.moveTo(0, mainH + volH + 0.5); ctx.lineTo(W - PAD_R, mainH + volH + 0.5); ctx.stroke();
      }

      // ---- 十字光标 ----
      if (this.cross) {
        const { x, y } = this.cross;
        if (x < W - PAD_R && y < H - PAD_B) {
          ctx.setLineDash([3, 3]); ctx.strokeStyle = '#8895a7';
          ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H - PAD_B); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W - PAD_R, y); ctx.stroke();
          ctx.setLineDash([]);
          // 价格标签
          const pv = pOf(y);
          ctx.fillStyle = '#363c46'; ctx.fillRect(W - PAD_R + 2, y - 8, PAD_R - 4, 16);
          ctx.fillStyle = '#fff'; ctx.font = '10px monospace'; ctx.textAlign = 'left';
          ctx.fillText(fmtPrice(pv), W - PAD_R + 6, y + 3);
        }
      }
      this._vr = vr; this._yOf = yOf;
    }

    _upA(a) { const c = this.colors.up; return c + Math.round(a * 255).toString(16).padStart(2, '0'); }
    _downA(a) { const c = this.colors.down; return c + Math.round(a * 255).toString(16).padStart(2, '0'); }

    _ma(n) {
      const key = '_ma' + n;
      if (this[key] && this[key].len === this.data.length && !this._dirty) return this[key].arr;
      const arr = new Array(this.data.length).fill(null);
      let sum = 0;
      for (let i = 0; i < this.data.length; i++) {
        sum += this.data[i][4];
        if (i >= n) sum -= this.data[i - n][4];
        if (i >= n - 1) arr[i] = sum / n;
      }
      this[key] = { len: this.data.length, arr };
      return arr;
    }

    _boll(n, k) {
      const mid = new Array(this.data.length).fill(null);
      const up = mid.slice(), low = mid.slice();
      for (let i = n - 1; i < this.data.length; i++) {
        let s = 0;
        for (let j = i - n + 1; j <= i; j++) s += this.data[j][4];
        const m = s / n;
        let v = 0;
        for (let j = i - n + 1; j <= i; j++) v += (this.data[j][4] - m) ** 2;
        const sd = Math.sqrt(v / n);
        mid[i] = m; up[i] = m + k * sd; low[i] = m - k * sd;
      }
      return { mid, up, low };
    }

    _line(ctx, arr, vr, yOf, color, width) {
      ctx.strokeStyle = color; ctx.lineWidth = width || 1;
      ctx.beginPath();
      let started = false;
      for (let i = vr.start; i <= vr.end; i++) {
        const v = arr[i];
        if (v == null) { started = false; continue; }
        const x = this._xOf(i, vr), y = yOf(v);
        if (!started) { ctx.moveTo(x, y); started = true; }
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    _renderRSI(ctx, vr, y, h, C) {
      const n = 14;
      const rsi = new Array(this.data.length).fill(null);
      let ag, al;
      for (let i = 1; i < this.data.length; i++) {
        const ch = this.data[i][4] - this.data[i - 1][4];
        const g = Math.max(0, ch), l = Math.max(0, -ch);
        if (i <= n) { ag = (ag || 0) + g / n; al = (al || 0) + l / n; }
        else { ag = (ag * (n - 1) + g) / n; al = (al * (n - 1) + l) / n; }
        if (i >= n) rsi[i] = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
      }
      const yOf = (v) => y + 6 + (100 - v) / 100 * (h - 12);
      ctx.font = '9px sans-serif'; ctx.fillStyle = C.text; ctx.textAlign = 'left';
      ctx.fillText('RSI(14)', 8, y + 12);
      ctx.strokeStyle = '#b78aff'; ctx.lineWidth = 1;
      ctx.beginPath();
      let st = false;
      for (let i = vr.start; i <= vr.end; i++) {
        if (rsi[i] == null) { st = false; continue; }
        const x = this._xOf(i, vr);
        st ? ctx.lineTo(x, yOf(rsi[i])) : ctx.moveTo(x, yOf(rsi[i])); st = true;
      }
      ctx.stroke();
      ctx.strokeStyle = C.grid; ctx.setLineDash([2, 3]);
      for (const lv of [30, 70]) {
        ctx.beginPath(); ctx.moveTo(0, yOf(lv)); ctx.lineTo(this.w - PAD_R, yOf(lv)); ctx.stroke();
      }
      ctx.setLineDash([]);
    }

    _renderMACD(ctx, vr, y, h, C) {
      const ef = (n) => {
        const out = new Array(this.data.length).fill(null);
        let e = null; const a = 2 / (n + 1);
        for (let i = 0; i < this.data.length; i++) {
          e = e == null ? this.data[i][4] : this.data[i][4] * a + e * (1 - a);
          out[i] = e;
        }
        return out;
      };
      const e12 = ef(12), e26 = ef(26);
      const dif = e12.map((v, i) => v - e26[i]);
      let dea = 0;
      const deaArr = dif.map((v, i) => { dea = i === 0 ? v : v * 0.2 + dea * 0.8; return dea; });
      const all = dif.flatMap((v, i) => [v, deaArr[i], (v - deaArr[i]) * 2]);
      const m = Math.max(...all.map(Math.abs).filter(x => isFinite(x)), 1e-9);
      const yOf = (v) => y + h / 2 - v / m * (h / 2 - 8);
      ctx.font = '9px sans-serif'; ctx.fillStyle = C.text; ctx.textAlign = 'left';
      ctx.fillText('MACD(12,26,9)', 8, y + 12);
      const bw = Math.max(1, this.view.cw * 0.5);
      for (let i = vr.start; i <= vr.end; i++) {
        const v = (dif[i] - deaArr[i]) * 2;
        const x = this._xOf(i, vr);
        ctx.fillStyle = v >= 0 ? this._upA(0.7) : this._downA(0.7);
        const y0 = yOf(0), y1 = yOf(v);
        ctx.fillRect(x - bw / 2, Math.min(y0, y1), bw, Math.max(1, Math.abs(y1 - y0)));
      }
      this._line(ctx, dif, vr, yOf, '#f0b90b', 1);
      this._line(ctx, deaArr, vr, yOf, '#3f8cff', 1);
    }

    // ---------- 交互 ----------
    _bind() {
      const cv = this.cv;
      const pos = (e) => {
        const r = cv.getBoundingClientRect();
        return { x: e.clientX - r.left, y: e.clientY - r.top };
      };
      cv.addEventListener('pointerdown', (e) => {
        cv.setPointerCapture(e.pointerId);
        const p = pos(e);
        if (this.drag) { // 第二根手指 -> 缩放
          this.pinch = { d0: Math.abs(e.clientX - this.drag.sx), cw0: this.view.cw };
          return;
        }
        this.drag = { sx: e.clientX, right0: this.view.right, moved: false, pid: e.pointerId };
      });
      cv.addEventListener('pointermove', (e) => {
        const p = pos(e);
        if (this.drag && e.buttons) {
          const dx = e.clientX - this.drag.sx;
          if (Math.abs(dx) > 3) this.drag.moved = true;
          this.view.right = this.drag.right0 + dx / this.view.cw;
          const maxRight = Math.max(0, Math.floor(this.data.length * 0.35));
          this.view.right = Math.max(-30, Math.min(maxRight, this.view.right));
          this.render();
        }
        this.cross = p;
        this.render();
        this._tooltip(p);
      });
      const endDrag = () => { this.drag = null; this.pinch = null; };
      cv.addEventListener('pointerup', endDrag);
      cv.addEventListener('pointercancel', endDrag);
      cv.addEventListener('pointerleave', () => { this.cross = null; this.render(); this._hideTip(); });
      cv.addEventListener('wheel', (e) => {
        e.preventDefault();
        // 向上滚动 = 放大 (蜡烛变宽), 向下 = 缩小 (对齐 OKX/TradingView)
        const k = e.deltaY > 0 ? 0.89 : 1.12;
        this.view.cw = Math.max(3, Math.min(30, this.view.cw * k));   // 下限 3px: 防蜡烛变成发丝级细线
        this.render();
      }, { passive: false });
      cv.addEventListener('dblclick', () => this.resetZoom());
      addEventListener('resize', () => this.resize());
    }

    resetZoom() {
      // 默认 1x 视图: 跟随最新 + 中性蜡烛宽度
      this.view.right = 0;
      this.view.cw = Math.min(14, Math.max(5, this.w / 90));
      this.render();
    }

    _tooltip(p) {
      const tip = document.getElementById('ohlcTip');
      if (!tip) return;
      const vr = this._vr || this._visibleRange();
      const plotW = this.w - PAD_R;
      if (p.x > plotW) { tip.style.display = 'none'; return; }
      const right = this.data.length - 1 + this.view.right;
      const i = Math.round(right - (plotW - p.x) / this.view.cw);
      if (i < 0 || i >= this.data.length) { tip.style.display = 'none'; return; }
      const d = this.data[i];
      const chg = (d[4] / d[1] - 1) * 100;
      const cls = d[4] >= d[1] ? 'up' : 'down';
      tip.style.display = 'block';
      tip.innerHTML =
        `<span>${fmtTime(d[0], this.interval)}</span>` +
        `<span>开 <b class="${cls}">${fmtPrice(d[1])}</b></span>` +
        `<span>高 <b class="${cls}">${fmtPrice(d[2])}</b></span>` +
        `<span>低 <b class="${cls}">${fmtPrice(d[3])}</b></span>` +
        `<span>收 <b class="${cls}">${fmtPrice(d[4])}</b></span>` +
        `<span class="${cls}">${chg >= 0 ? '+' : ''}${chg.toFixed(2)}%</span>`;
    }
    _hideTip() { const t = document.getElementById('ohlcTip'); if (t) t.style.display = 'none'; }
  }

  window.CandleChart = CandleChart;
  window.fmtPrice = fmtPrice;
  window.fmtVol = fmtVol;
})();
