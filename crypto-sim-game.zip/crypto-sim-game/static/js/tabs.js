/* tabs.js —— 多页面路由与渲染: 现货 / 链上(Web3) / 搬砖 / 广场 / 实验室 */
(function () {
  const $ = (id) => document.getElementById(id);
  const PAGE = { current: "contract" };
  const COIN_UI = window.COIN_UI;
  const refreshers = {};          // page -> fn

  // ================= 页面路由 =================
  function bindTabs() {
    $("mainTabs").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      document.querySelectorAll("#mainTabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      PAGE.current = b.dataset.page;
      document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
      $("page-" + PAGE.current).classList.add("active");
      const r = refreshers[PAGE.current];
      if (r) r(true);
    });
  }

  // ================= 现货页 =================
  const SP = { chart: null, interval: "1m", type: "market" };

  function initSpot() {
    SP.chart = new CandleChart($("spotChartCanvas"));
    // 复用 ohlcTip 逻辑: chart.js 用 #ohlcTip, 给现货图一个别名容器
    $("spIvTabs").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      document.querySelectorAll("#spIvTabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      SP.interval = b.dataset.iv;
      fetchSpotKlines(false);
    });
    $("spTypeTabs").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      SFX.click();
      document.querySelectorAll("#spTypeTabs button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      SP.type = b.dataset.t;
      $("spPriceRow").style.display = SP.type === "limit" ? "" : "none";
      if (SP.type === "limit") $("spPriceInput").value = ($("spPrice").textContent || "").replace(/,/g, "");
    });
    $("spAmount").addEventListener("input", updateSpotPreview);
    document.querySelector("#spAmount").parentElement.querySelector(".pct-quick").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      const avail = window.__S?.account?.available ?? 10000;
      $("spAmount").value = Math.max(5, Math.floor(avail * parseFloat(b.dataset.p)));
      updateSpotPreview();
    });
    $("spBuy").onclick = () => spotTrade("buy");
    $("spSell").onclick = () => spotTrade("sell");
    fetchSpotKlines(false);
    setInterval(() => { if (PAGE.current === "spot") fetchSpotKlines(true); }, 2000);
  }

  async function fetchSpotKlines(keep) {
    try {
      const coin = window.__coin || "BTCUSDT";
      const r = await fetch(`/api/klines?coin=${coin}&interval=${SP.interval}&limit=320`).then(r => r.json());
      if (!r.ok) return;
      SP.chart.setData(r.candles, SP.interval, keep);
    } catch (e) {}
  }

  function updateSpotPreview() {
    const amt = +$("spAmount").value || 0;
    const px = window.__S?.coins?.[window.__coin]?.price;
    $("spPreview").textContent = px ? `≈ ${(amt / px).toFixed(6)} ${window.__coin.replace("USDT", "")} · 现价 ${window.fmtPrice(px)}` : "≈ --";
  }

  async function spotTrade(side) {
    const amt = +$("spAmount").value || 0;
    const price = SP.type === "limit" ? parseFloat($("spPriceInput").value) : null;
    if (amt < 5) return toast("最低 5 USDT", "danger");
    const r = await api(`/api/spot`, { coin: window.__coin, side, type: SP.type, usdt: amt, price });
    if (r.ok) {
      SFX.fill();
      toast(`${side === "buy" ? "🟢 买入" : "🔴 卖出"} ${window.__coin.replace("USDT", "")} 现货 ${amt} USDT`, "success");
      fetchSpotKlines(true);
    } else toast("❌ " + r.msg, "danger");
  }

  function renderSpot(st) {
    const c = st.coins[window.__coin];
    if (!c) return;
    const ui = COIN_UI[window.__coin];
    $("spIcon").textContent = ui.icon;
    $("spName").textContent = ui.name + " 现货";
    $("spPrice").textContent = window.fmtPrice(st.display[window.__coin] ?? c.price);
    const chg = $("spChg");
    chg.textContent = `${c.chg24 >= 0 ? "+" : ""}${c.chg24.toFixed(2)}%`;
    chg.className = "chg-chip " + (c.chg24 >= 0 ? "up" : "down");
    $("spAvail").textContent = fmtN(st.account.available) + " USDT";
    // 持仓
    const holds = st.account.spot_hold || [];
    $("spotHoldings").innerHTML = !holds.length
      ? '<div class="empty-tip">暂无现货 — 买入后可提币到链上钱包 🎒</div>'
      : '<table class="grid"><tr><th>币种</th><th>数量</th><th>现价</th><th>成本</th><th>市值</th><th>盈亏</th><th>操作</th></tr>' +
        holds.map(h => `<tr>
          <td>${h.coin.replace("USDT", "")}/USDT</td><td>${h.qty}</td>
          <td>${window.fmtPrice(h.price)}</td><td>${fmtN(h.cost)}</td><td>${fmtN(h.value)}</td>
          <td class="${h.pnl >= 0 ? "up" : "down"}">${h.pnl >= 0 ? "+" : ""}${fmtN(h.pnl)} (${h.pnl_pct}%)</td>
          <td><button class="row-btn danger" onclick="window.__spotSellAll('${h.coin}')">市价卖出</button></td>
        </tr>`).join("") + "</table>";
  }
  window.__spotSellAll = async function (coin) {
    const r = await api("/api/spot", { coin, side: "sell", type: "market", usdt: 0 });
    if (r.ok) { SFX.fill(); toast(`已市价卖出全部 ${coin.replace("USDT", "")}`); } else toast("❌ " + r.msg, "danger");
  };

  // ================= 链上页 =================
  function renderChain(d) {
    const wc = $("walletCard");
    if (!d.has_wallet) {
      wc.innerHTML = `
        <div class="panel-title">🎒 Web3 钱包</div>
        <div class="wallet-create">
          <p>还没有钱包。创建将生成一套<b>标准 BIP39 助记词</b>，并用手写的 secp256k1 / Keccak-256 派生出<b>真实格式</b>的 ETH / BTC 地址。</p>
          <p class="dim11">⚠️ 真实世界里：助记词 = 一切资产。谁拿到助记词，谁就是资产的主人。本演示钱包运行在教学模拟链上。</p>
          <button class="btn-gold" id="createWalletBtn">创建钱包</button>
        </div>`;
      $("createWalletBtn").onclick = createWallet;
      $("explorerCard").innerHTML = `<div class="panel-title">🧭 区块浏览器</div><div class="explorer-body">${explorerHtml(d)}</div>`;
      $("defiCard").innerHTML = `<div class="panel-title">🔄 DEX (AMM)</div><div class="dim11" style="padding:12px">创建钱包后可使用 DEX 与质押</div>`;
      $("stakeCard").innerHTML = `<div class="panel-title">🏦 质押金库</div><div class="dim11" style="padding:12px">创建钱包后可使用</div>`;
      return;
    }
    const w = d.wallet;
    wc.innerHTML = `
      <div class="panel-title">🎒 我的钱包
        <button class="row-btn" style="margin-left:auto" id="backupBtn">备份助记词</button>
      </div>
      <div class="wallet-body">
        <div class="addr-row"><span class="addr-net">ETH</span><code class="addr">${w.eth.slice(0, 10)}…${w.eth.slice(-8)}</code><button class="row-btn" data-copy="${w.eth}">复制</button></div>
        <div class="addr-row"><span class="addr-net">BTC</span><code class="addr">${w.btc.slice(0, 10)}…${w.btc.slice(-8)}</code><button class="row-btn" data-copy="${w.btc}">复制</button></div>
        <div class="bal-grid">
          <div class="bal-cell"><span>USDT</span><b>${fmtN(w.balances.USDT || 0)}</b></div>
          <div class="bal-cell"><span>SOL</span><b>${(w.balances.SOL || 0).toFixed(4)}</b></div>
          <div class="bal-cell"><span>ETH</span><b>${(w.balances.ETH || 0).toFixed(5)}</b></div>
          <div class="bal-cell"><span>DOGE</span><b>${fmtN(w.balances.DOGE || 0, 0)}</b></div>
          <div class="bal-cell"><span>BNB</span><b>${(w.balances.BNB || 0).toFixed(4)}</b></div>
          <div class="bal-cell hl"><span>总资产</span><b>${fmtN(w.total_usd)} U</b></div>
        </div>
        <div class="xfer-grid">
          <div class="xfer-box">
            <b>⬇️ 交易所提币到钱包</b>
            <select id="wdCoin">${["USDT", "SOL", "ETH", "DOGE", "BNB"].map(c => `<option>${c}</option>`).join("")}</select>
            <input type="number" id="wdAmt" placeholder="数量" step="any">
            <button class="btn-gold" id="wdBtn">提币 (gas 0.12U · ${d.confirmations} 块确认)</button>
            <div class="dim11">提币币种需先在现货页买入</div>
          </div>
          <div class="xfer-box">
            <b>⬆️ 充币回交易所</b>
            <select id="dpCoin">${["USDT", "SOL", "ETH", "DOGE", "BNB"].map(c => `<option>${c}</option>`).join("")}</select>
            <input type="number" id="dpAmt" placeholder="数量" step="any">
            <button class="btn-ghost" id="dpBtn">充币 (需 ${d.confirmations} 块确认后到账)</button>
          </div>
        </div>
        ${w.nfts.length ? `<div class="nft-row">${w.nfts.map(n => `<span class="nft-chip">${n.name} <i>${n.id}</i></span>`).join("")}</div>` : ""}
      </div>`;
    $("explorerCard").innerHTML = `<div class="panel-title">🧭 区块浏览器 <span class="panel-sub">高度 #${d.height} · 内存池 ${d.mempool_n} 笔</span></div>
      <div class="explorer-body">${explorerHtml(d)}</div>`;
    // DEX
    $("defiCard").innerHTML = `
      <div class="panel-title">🔄 DEX · AMM 恒定乘积 <span class="panel-sub">与 CEX 存在价差 → 套利窗口</span></div>
      <div class="pool-list">
        ${Object.entries(d.pools).map(([pair, p]) => `
          <div class="pool-row">
            <b>${pair}</b>
            <span>DEX ${window.fmtPrice(p.price)}</span>
            <span>CEX ${window.fmtPrice(p.cex)}</span>
            <span class="${Math.abs(p.gap_pct) > 0.3 ? (p.gap_pct > 0 ? "up" : "down") : "dim11"}">价差 ${p.gap_pct > 0 ? "+" : ""}${p.gap_pct}%</span>
            <button class="row-btn" data-arb="${pair}" data-gap="${p.gap_pct}">Swap</button>
          </div>`).join("")}
      </div>
      <div class="swap-box">
        <select id="swapPair">${Object.keys(d.pools).map(k => `<option>${k}</option>`).join("")}</select>
        <select id="swapDir"><option value="usdt_to_coin">USDT → 币</option><option value="coin_to_usdt">币 → USDT</option></select>
        <input type="number" id="swapAmt" placeholder="输入数量" step="any">
        <button class="btn-gold" id="swapBtn">Swap (0.3% LP费 + gas)</button>
        <div class="dim11" id="swapResult"></div>
      </div>`;
    $("stakeCard").innerHTML = `
      <div class="panel-title">🏦 质押金库 <span class="panel-sub">APY ${d.stake_apy}% (浮动)</span></div>
      <div class="stake-body">
        <div class="pain-row"><span>我的质押</span><b>${fmtN(w.staked_usdt)} USDT</b></div>
        <div class="pain-row"><span>池子总量</span><b>${fmtN(d.stake_pool)} USDT</b></div>
        <input type="number" id="stakeAmt" placeholder="质押数量" step="any">
        <div style="display:flex;gap:8px">
          <button class="btn-gold" id="stakeBtn" style="flex:1">质押</button>
          <button class="btn-ghost" id="unstakeBtn" style="flex:1">全部赎回</button>
        </div>
        ${d.risk_events.length ? `<div class="dim11 down">⚠️ 历史风险事件: ${d.risk_events.map(r => `${r.t} -${r.loss}%`).join(" / ")}</div>` : '<div class="dim11">每 8 模拟小时结算利息 · 存在小概率协议风险事件（DeFi 不是存款）</div>'}
      </div>`;
    bindChainEvents(d);
  }

  function explorerHtml(d) {
    if (!d.txs.length) return '<div class="empty-tip">链上还没有交易 — 提币/充币/swap 都会在这里留下记录</div>';
    const typeMap = { transfer: "转账", swap: "Swap", stake: "质押", unstake: "赎回", mint: "Mint" };
    return '<div class="tx-list">' + d.txs.map(t => `
      <div class="tx-row">
        <span class="tx-hash" title="${t.hash}">${t.hash.slice(0, 10)}…${t.hash.slice(-6)}</span>
        <span class="tx-type">${typeMap[t.type] || t.type}</span>
        <span>${fmtN(t.amount, 4)} ${t.coin}</span>
        <span class="tx-conf ${t.confirms >= d.confirmations ? "ok" : "pending"}">${t.block ? (t.confirms >= d.confirmations ? "✓ 已确认" : t.confirms + "/" + d.confirmations) : "⏳ 待打包"}</span>
      </div>`).join("") + "</div>";
  }

  function bindChainEvents(d) {
    wcBind("backupBtn", backupModal);
    wcBind("wdBtn", async () => {
      const r = await api("/api/wallet/withdraw", { coin: $("wdCoin").value, amount: parseFloat($("wdAmt").value) });
      if (r.ok) { SFX.fill(); toast(`📤 提币已广播 ${r.hash.slice(0, 14)}…，等待 ${r.confirmations} 块确认`); refreshChain(); }
      else toast("❌ " + r.msg, "danger");
    });
    wcBind("dpBtn", async () => {
      const r = await api("/api/wallet/deposit", { coin: $("dpCoin").value, amount: parseFloat($("dpAmt").value) });
      if (r.ok) { SFX.click(); toast(`📥 充币已广播，${r.confirmations} 块确认后到账交易所`); refreshChain(); }
      else toast("❌ " + r.msg, "danger");
    });
    wcBind("swapBtn", async () => {
      const r = await api("/api/defi/swap", { pair: $("swapPair").value, direction: $("swapDir").value, amount: parseFloat($("swapAmt").value) });
      if (r.ok) { SFX.fill(); $("swapResult").innerHTML = `✅ 成交: 实际价 ${window.fmtPrice(r.eff_price)} · LP费 ${r.fee}`; refreshChain(); }
      else $("swapResult").textContent = "❌ " + r.msg;
    });
    wcBind("stakeBtn", async () => {
      const r = await api("/api/defi/stake", { amount: parseFloat($("stakeAmt").value) });
      if (r.ok) { SFX.fill(); toast("✅ 质押成功，开始赚 APY"); refreshChain(); } else toast("❌ " + r.msg, "danger");
    });
    wcBind("unstakeBtn", async () => {
      const r = await api("/api/defi/unstake", {});
      if (r.ok) { SFX.click(); toast("✅ 已赎回全部质押"); refreshChain(); } else toast("❌ " + r.msg, "danger");
    });
    document.querySelectorAll("[data-copy]").forEach(b => b.onclick = () => {
      navigator.clipboard?.writeText(b.dataset.copy);
      toast("📋 已复制地址");
    });
    document.querySelectorAll("[data-arb]").forEach(b => b.onclick = () => {
      $("swapPair").value = b.dataset.arb;
      toast(`已选择 ${b.dataset.arb} — 当前价差 ${b.dataset.gap}%，让套利开始`, "gold");
    });
  }
  function wcBind(id, fn) { const el = $(id); if (el) el.onclick = fn; }

  async function createWallet() {
    const r = await api("/api/wallet/create", {});
    if (!r.ok) return toast("❌ " + r.msg, "danger");
    SFX.achieve();
    confetti(innerWidth / 2, innerHeight / 3, 80);
    backupModal(r.wallet.mnemonic, true);
    refreshChain();
  }

  function backupModal(mnemonic, firstTime) {
    const words = mnemonic.split(" ");
    const html = `
      <p class="${firstTime ? "up" : ""}"><b>${firstTime ? "🎉 钱包创建成功！这是你的助记词，只展示这一次的完整备份：" : "请勿在任何联网设备明文保存助记词。"}</b></p>
      <div class="mnemonic-grid">${words.map((w, i) => `<span class="mn-word"><i>${i + 1}</i>${w}</span>`).join("")}</div>
      <p class="dim11">标准 BIP39 · 128-bit 熵 · PBKDF2-SHA512×2048 →种子 → secp256k1 私钥 → ETH (Keccak-256) / BTC (Base58Check) 地址。真实世界丢失助记词 = 永久失去资产，没有任何客服能帮你找回。</p>
      <div style="text-align:center"><button class="btn-gold" id="mnOk">我已安全备份</button></div>`;
    const wrap = openModal(firstTime ? "🔐 备份助记词（最重要的一步）" : "🔐 助记词备份", html, { wide: true });
    wrap.querySelector("#mnOk").onclick = closeModal;
  }

  async function refreshChain(force) {
    if (PAGE.current !== "chain" && !force) return;
    try {
      const d = await fetch("/api/wallet").then(r => r.json());
      if (d.ok) renderChain(d);
    } catch (e) {}
  }
  refreshers.chain = refreshChain;

  // ================= 搬砖页 =================
  const TOM = { sid: null, endTs: 0, timer: null, quiz: null };

  function initLabor() {
    $("tomatoBtn").onclick = tomatoToggle;
    $("mathBtn").onclick = startMath;
    $("wageInput").addEventListener("change", async () => {
      const v = parseFloat($("wageInput").value) || 30;
      await api("/api/config", { wage_cny: v });
      renderPain(window.__S);
      toast("✅ 时薪锚点已更新");
    });
    setInterval(laborTick, 1000);
  }

  async function tomatoToggle() {
    if (!TOM.sid) {
      const r = await api("/api/labor/start", {});
      if (!r.ok) return toast("❌ " + r.msg, "danger");
      TOM.sid = r.sid; TOM.endTs = r.end_ts * 1000;
      $("tomatoBtn").textContent = "放弃本次 (无工资)";
      $("tomatoState").textContent = "专注中… 这 25 分钟是真实的时间";
      SFX.click();
    } else {
      TOM.sid = null;
      $("tomatoBtn").textContent = "开始搬砖";
      $("tomatoState").textContent = "已放弃 · 时间不会退还";
      drawRing(0);
      $("tomatoTime").textContent = "25:00";
    }
  }

  function laborTick() {
    if (!TOM.sid) return;
    const left = Math.max(0, TOM.endTs - Date.now());
    const mm = Math.floor(left / 60000), ss = Math.floor(left % 60000 / 1000);
    $("tomatoTime").textContent = `${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
    drawRing(1 - left / (25 * 60 * 1000));
    if (left <= 0) claimTomato();
  }

  async function claimTomato() {
    const sid = TOM.sid; TOM.sid = null;
    const r = await api("/api/labor/claim", { sid });
    if (r.ok) {
      SFX.profit(true);
      confetti(innerWidth / 2, innerHeight * 0.4, 120);
      toast(`🧱 搬砖工资到账 +${fmtN(r.gain)} USDT —— 这是 25 分钟真实专注换来的`, "gold", 4000);
      $("tomatoBtn").textContent = "开始搬砖";
      $("tomatoState").textContent = "已结算 · 干得漂亮";
      drawRing(1);
      $("tomatoTime").textContent = "25:00";
    } else {
      toast("❌ " + r.msg, "danger");
      $("tomatoBtn").textContent = "开始搬砖";
    }
  }

  function drawRing(k) {
    const fg = $("ringFg");
    if (!fg) return;
    const C = 2 * Math.PI * 88;
    fg.style.strokeDasharray = C;
    fg.style.strokeDashoffset = C * (1 - k);
  }

  async function startMath() {
    const d = await fetch("/api/labor/math").then(r => r.json());
    if (!d.ok) return toast("❌ " + d.msg, "danger");
    TOM.quiz = d;
    $("mathBody").innerHTML = d.questions.map((q, i) => `
      <div class="math-q"><span>${i + 1}. ${q.q}</span><input type="number" id="mq${i}" step="any"></div>`).join("") +
      `<button class="btn-gold" id="mathSubmit" style="margin-top:8px">交卷 (全对 ${fmtN(d.reward)} U)</button>`;
    $("mathSubmit").onclick = submitMath;
    SFX.click();
  }

  async function submitMath() {
    const answers = TOM.quiz.questions.map((_, i) => $("mq" + i).value);
    const r = await api("/api/labor/math/submit", { sid: TOM.quiz.sid, answers });
    if (r.ok) {
      if (r.gain > 0) {
        SFX.profit();
        toast(`🧮 全对！工资 +${fmtN(r.gain)} USDT`, "gold");
      } else toast(`😅 ${r.msg}`, "info", 3200);
      $("mathBody").innerHTML = '<p class="dim11">交易员的基本功：心算盈亏、费率、强平价。答错不发工资。</p><button class="btn-ghost" id="mathBtn2">再来一轮</button>';
      $("mathBtn2").onclick = startMath;
    } else {
      toast("❌ " + r.msg, "danger");
    }
  }

  function renderLabor(st) {
    $("tomatoCount").textContent = `${st.labor.tomatos}/${st.labor.tomato_cap}`;
    $("mathCount").textContent = `今日 ${st.labor.math_done}/${st.labor.math_cap} 次`;
    $("painExamples").innerHTML = painExamples(st);
    $("laborLog").innerHTML = (st.labor.earned || 0) <= 0
      ? '<div class="dim11" style="padding:10px">还没有搬砖记录 — 你的第一笔本金将来自真实的专注</div>'
      : (window.__S?.labor_log || []).map(l => "").join("") + `<div class="dim11" style="padding:10px">累计搬砖收入 <b class="up">+${fmtN(st.labor.earned)}</b> USDT —— 每一分都锚定真实时间</div>`;
    // 成瘾仪表盘
    const sg = st.stage;
    const stageColors = { "兴奋期": "up", "追逐期": "up", "强迫期": "down", "负强化期": "down" };
    const stageIdx = ["兴奋期", "追逐期", "强迫期", "负强化期"].indexOf(sg.stage);
    $("addictBody").innerHTML = `
      <div class="stage-track">
        ${["兴奋期", "追逐期", "强迫期", "负强化期"].map((n, i) => `<div class="stage-step ${i <= stageIdx ? "on " + (i >= 2 ? "bad" : "warn") : ""}">${n}</div>`).join("")}
      </div>
      <div class="stage-score">成瘾风险指数 <b class="${stageIdx >= 2 ? "down" : stageIdx === 1 ? "" : "up"}">${sg.score}</b> / 100</div>
      <div class="stage-metrics">
        <div><span>24h 交易笔数</span><b>${sg.trades_24h}</b></div>
        <div><span>追损行为</span><b>${sg.chase_events} 次</b></div>
        <div><span>爆仓次数</span><b>${sg.liq_count}</b></div>
        <div><span>冷静期违规</span><b>${sg.violations}</b></div>
      </div>
      <div class="dim11" style="padding:0 12px 12px">${sg.advice}</div>
      ${st.cold_left > 0 ? `<div class="cold-banner">🧊 冷静期生效中 · 剩余 ${st.cold_left} 分钟 (设置中可关闭，但会被记录)</div>` : ""}`;
  }

  function painExamples(st) {
    const rate = st.pain.rate, wage = st.pain.wage_cny;
    const perHourU = wage / rate;
    const ex = [
      ["一杯蜜雪冰城", 8], ["一顿外卖", 25], ["一场电影", 45], ["一双球鞋", 400],
    ];
    return `<div class="pain-grid">` + ex.map(([name, cny]) => {
      const u = cny / rate;
      return `<div class="pain-cell"><span>${name}</span><b>≈ ${u.toFixed(1)} U</b><i>= ${(u / perHourU).toFixed(1)}h 工作</i></div>`;
    }).join("") + "</div>";
  }
  refreshers.labor = (force) => { if (window.__S) renderLabor(window.__S); };

  // ================= 广场页 =================
  let lastFeedId = 0;

  async function refreshSocial(force) {
    if (PAGE.current !== "social" && !force) return;
    try {
      const d = await fetch("/api/social").then(r => r.json());
      if (d.ok) {
        renderFeed(d);
        renderKolStats(d.kols);
      }
      const lb = await fetch("/api/leaderboard").then(r => r.json());
      if (lb.ok) renderLeaderboard(lb.rows);
    } catch (e) {}
  }
  refreshers.social = refreshSocial;

  function renderFeed(d) {
    const feed = d.feed;
    if (!feed.length) { $("kolFeed").innerHTML = '<div class="empty-tip">KOL 们正在盯盘，稍后开麦…</div>'; return; }
    const recent = feed.slice(-30).reverse();
    $("kolFeed").innerHTML = recent.map(m => `
      <div class="kol-msg">
        <div class="kol-avatar" style="border-color:${m.color}">${m.emoji}</div>
        <div class="kol-bubble">
          <div class="kol-head"><b style="color:${m.color}">${m.name}</b>
            <span class="kol-wr ${m.win_rate >= 50 ? "up" : "down"}">胜率 ${m.win_rate}%</span>
            <span class="kol-time">${m.t}</span></div>
          <div class="kol-text">${m.text}</div>
          ${m.signal ? `<div class="kol-sig">📡 信号: ${m.signal.coin.replace("USDT", "")} ${m.signal.side === 1 ? "做多" : "做空"} ${m.signal.lev}x
            <button class="row-btn gold-btn" onclick="window.__follow(${m.signal.id})">一键跟单</button></div>` : ""}
        </div>
      </div>`).join("");
  }

  function renderKolStats(kols) {
    // 侧栏顶部可以放 KOL 卡片; 简化: feed 已含胜率
  }

  function renderLeaderboard(rows) {
    $("leaderList").innerHTML = '<table class="grid"><tr><th>#</th><th>玩家</th><th>权益</th><th>收益率</th><th>胜率</th></tr>' +
      rows.slice(0, 15).map(r => `
        <tr class="${r.is_player ? "me-row" : ""}">
          <td>${r.rank <= 3 ? ["🥇", "🥈", "🥉"][r.rank - 1] : r.rank}</td>
          <td>${r.name}${r.is_player ? " <b class='hl'>(你)</b>" : ""}</td>
          <td>${fmtN(r.equity, 0)}</td>
          <td class="${r.roi >= 0 ? "up" : "down"}">${r.roi >= 0 ? "+" : ""}${r.roi.toFixed(1)}%</td>
          <td>${r.win_rate != null ? r.win_rate.toFixed(0) + "%" : "--"}</td>
        </tr>`).join("") + "</table>" +
      (rows.findIndex(r => r.is_player) >= 15 ? `<div class="dim11" style="padding:8px 12px">你的排名: #${rows.find(r => r.is_player).rank} / ${rows.length}</div>` : "");
  }

  window.__follow = async function (sigId) {
    const r = await api("/api/follow", { sig_id: sigId });
    if (r.ok) { SFX.fill(); toast("📡 已跟单 KOL 信号 — 记住，胜率发牌权在市场手里", "success"); }
    else toast("❌ " + r.msg, "danger");
  };

  // ---- 晒单卡 ----
  async function shareCard() {
    const d = await fetch("/api/share_data").then(r => r.json());
    if (!d.ok) return;
    const cv = document.createElement("canvas");
    cv.width = 640; cv.height = 840;
    const ctx = cv.getContext("2d");
    const g = ctx.createLinearGradient(0, 0, 640, 840);
    g.addColorStop(0, "#101418"); g.addColorStop(1, "#1a2026");
    ctx.fillStyle = g; ctx.fillRect(0, 0, 640, 840);
    ctx.fillStyle = "#f0b90b"; ctx.fillRect(0, 0, 640, 6);
    ctx.font = "bold 40px sans-serif"; ctx.fillStyle = "#f0b90b";
    ctx.fillText("⚡ CoinSprint 战绩卡", 40, 80);
    ctx.font = "16px sans-serif"; ctx.fillStyle = "#848e9c";
    ctx.fillText(`模拟时段 ${d.sim_str} · 市场处于${d.regime}`, 40, 112);
    const win = d.roi >= 0;
    ctx.font = "bold 76px sans-serif";
    ctx.fillStyle = win ? "#2ebd85" : "#f6465d";
    const roiTxt = `${d.roi >= 0 ? "+" : ""}${d.roi.toFixed(2)}%`;
    ctx.fillText(roiTxt, 40, 220);
    ctx.font = "20px sans-serif"; ctx.fillStyle = "#eaecef";
    ctx.fillText(`权益 ${fmtN(d.equity)} USDT`, 40, 262);
    const stats = [
      ["排名", `#${d.rank} / ${d.total}`], ["总交易", d.trades + " 笔"],
      ["胜率", d.win_rate + "%"], ["最长连胜", d.best_streak + " 连"],
      ["等级", `Lv.${d.level} ${d.title}`], ["成就", `${d.unlocked}/${d.total_ach} 项`],
    ];
    stats.forEach(([k, v], i) => {
      const x = 40 + (i % 2) * 300, y = 340 + Math.floor(i / 2) * 110;
      ctx.font = "16px sans-serif"; ctx.fillStyle = "#848e9c"; ctx.fillText(k, x, y);
      ctx.font = "bold 34px sans-serif"; ctx.fillStyle = "#eaecef"; ctx.fillText(String(v), x, y + 44);
    });
    ctx.font = "14px sans-serif"; ctx.fillStyle = "#848e9c";
    ctx.fillText("所有行情为算法模拟 · 教育用途 · 真实市场比这残酷得多", 40, 790);
    const url = cv.toDataURL("image/png");
    const wrap = openModal("📸 晒单卡片", `<div style="text-align:center"><img src="${url}" style="max-width:100%;border-radius:10px"><br><a class="btn-gold" style="text-decoration:none;display:inline-block;margin-top:10px" download="coinsprint_战绩卡.png" href="${url}">下载分享</a></div>`, { wide: true });
    SFX.click();
  }

  // ================= 实验室页 =================
  async function refreshLab(force) {
    if (PAGE.current !== "lab" && !force) return;
    try {
      const d = await fetch("/api/lab").then(r => r.json());
      if (!d.ok) return;
      $("labArch").textContent = "架构: " + d.arch + ` · 参数量 ${d.params} · 训练样本 ${d.n_samples} · 完成 ${d.epochs} epochs`;
      if (!d.ready) { $("labProb").textContent = "等待小时线收盘积累训练样本… (约 1 小时模拟时间)"; return; }
      drawLine($("labLoss"), d.loss_hist, "#f0b90b", "loss");
      drawLine($("labAcc"), d.acc_hist, "#2ebd85", "acc");
      const p = d.prob_up;
      $("labProb").innerHTML = `当前预测: 下一小时 <b class="${p >= 50 ? "up" : "down"}">BTC ${p >= 50 ? "上涨" : "下跌"} 概率 ${p}%</b> · 滚动准确率 <b>${d.acc_now}%</b> (随机 50%)`;
    } catch (e) {}
  }
  refreshers.lab = refreshLab;

  function drawLine(cv, data, color, kind) {
    if (!cv || !data || data.length < 2) return;
    const dpr = devicePixelRatio || 1;
    const w = cv.clientWidth || 300, h = 150;
    cv.width = w * dpr; cv.height = h * dpr; cv.style.height = h + "px"; cv.style.width = "100%";
    const ctx = cv.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    let lo = Math.min(...data), hi = Math.max(...data);
    if (kind === "acc") { lo = Math.min(lo, 45); hi = Math.max(hi, 55); }
    if (kind === "loss") lo = Math.max(0, lo);
    const span = hi - lo || 1;
    if (kind === "acc") {
      const y50 = 8 + (50 - lo) / span * (h - 16);
      ctx.strokeStyle = "#5a6472"; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(0, y50); ctx.lineTo(w, y50); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.strokeStyle = color; ctx.lineWidth = 1.6;
    ctx.beginPath();
    data.forEach((v, i) => {
      const x = i / (data.length - 1) * (w - 8) + 4;
      const y = 8 + (hi - v) / span * (h - 16);
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    });
    ctx.stroke();
  }

  // ================= 新事件反应 =================
  function tabEvent(ev) {
    switch (ev.type) {
      case "chase_warn":
        SFX.loss();
        toast(`⚠️ <b>追损警报</b> ${ev.text}`, "danger", 5200);
        shakeScreen(false);
        break;
      case "cooldown":
        SFX.news();
        toast(`🧊 <b>强制冷静期</b> ${ev.text}`, "gold", 5200);
        break;
      case "labor_paid":
        SFX.profit();
        toast(`💼 劳动收入 +${fmtN(ev.amount)} USDT`, "gold");
        break;
      case "defi_risk":
        SFX.liq();
        toast(`☠️ <b>DeFi 风险事件</b> ${ev.text}`, "danger", 5200);
        break;
      case "withdraw_submitted":
        toast(`📤 提币已上链 ${String(ev.hash).slice(0, 16)}…`, "info");
        break;
      case "deposit_ok":
        SFX.fill();
        toast(`📥 充币已确认到账 ${ev.amount} ${ev.coin}`, "success");
        break;
      case "trigger_fill":
        SFX.fill();
        toast(`🎯 计划委托触发 ${ev.coin.replace("USDT", "")} ${ev.side === 1 ? "做多" : "做空"} ${ev.lev}x @ ${window.fmtPrice(ev.price)}`, "success");
        break;
      case "maker_close":
        break;
      case "spot_fill":
        SFX.fill();
        toast(`💱 现货${ev.side === 1 ? "买入" : "卖出"}成交 @ ${window.fmtPrice(ev.price)}`);
        break;
      case "nft_minted":
        SFX.achieve();
        toast(`🖼️ NFT 铸造成功: ${ev.name}`, "achieve", 4000);
        break;
    }
    if (PAGE.current === "chain" && ["withdraw_submitted", "deposit_ok"].includes(ev.type)) refreshChain(true);
  }
  window.tabEvent = tabEvent;

  function api(url, body) {
    return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) })
      .then(r => r.json()).catch(() => ({ ok: false, msg: "网络错误" }));
  }
  window.__tabApi = api;

  // ================= 启动 =================
  function init() {
    bindTabs();
    initSpot();
    initLabor();
    $("shareBtn").onclick = shareCard;
    // app.js 每 1s 调 window.__tabRender(st)
    setInterval(() => {
      if (PAGE.current === "social") refreshSocial();
      if (PAGE.current === "chain") refreshChain();
      if (PAGE.current === "lab") refreshLab();
    }, 2500);
  }
  window.__tabRender = function (st) {
    if (PAGE.current === "spot") { renderSpot(st); updateSpotPreview(); }
    if (PAGE.current === "labor") renderLabor(st);
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
