# CyanXPan Open API v1 — 外部游戏接入文档

任何外部游戏/应用都可以把它的游戏币接入本平台: 玩家在游戏内把游戏币**充值**进平台 Web3 钱包 →
DEX 换成 USDT → 交易所合约/现货交易 → 提币回钱包 → 换回游戏币 → 游戏侧**提现**入账。
同时提供空投 / 转账 / 查询能力, 可作为 Web3 应用的完整测试沙盒 (无需任何真实链)。

## 1. 接入三步

1. 打开平台「🛠️ 开发者」页 → 注册应用 (名称 + 代币符号 2-8 位)
2. 获得 `api_key` (dk_开头) 与 `api_secret` (ds_开头) —— 代币自动上线 DEX, 平台提供初始流动性
3. 服务端按下述协议调用 API

> 代币符号全局唯一; 注册表独立持久化, 平台游戏重置 (reset) 不影响已注册应用与密钥。

## 2. 鉴权 (对齐主流交易所惯例)

每个请求携带三个请求头:

| 头 | 说明 |
|----|------|
| X-DEV-KEY | 应用 API Key |
| X-TIMESTAMP | 毫秒或秒级 Unix 时间戳, 窗口 ±120s |
| X-SIGNATURE | `HMAC_SHA256(api_secret, 签名字符串)` 的 hex |

签名字符串 (换行分隔):

```
{METHOD}\n{PATH}\n{TIMESTAMP}\n{BODY}
```

- `PATH` 为含 `/api/v1` 前缀的完整路径
- POST 的 `BODY` 为**原始请求体字符串** (建议紧凑 JSON, 与签名一致)
- GET 的 `BODY` 为**完整 query string** (如 `user_address=0xabc`)

错误码风格对齐交易所: `-1021` 时间戳越窗 / `-1022` 签名不匹配 / `-1100` 参数非法 /
`-1101` 地址不存在 / `-2015` 无效密钥 / `-2019` 余额不足 / `-2112` 限流 (120 req/min)。

## 3. 端点

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/v1/ping` | 连通性 |
| GET | `/api/v1/time` | 服务器时间 |
| GET | `/api/v1/meta` | 协议自描述 |
| GET | `/api/v1/app/info` | 应用信息 + DEX 价格 |
| POST | `/api/v1/app/deposit` | 游戏币 → 平台钱包 (桥接铸造, 真实上链) |
| POST | `/api/v1/app/withdraw` | 平台钱包 → 游戏币 (烧毁, 游戏侧入账) |
| POST | `/api/v1/app/airdrop` | 批量空投 (≤500 地址/批) |
| POST | `/api/v1/app/transfer` | 链上转账 |
| GET | `/api/v1/app/balance` | 查询余额 + DEX 估值 + 平台币持仓 |

### 请求/响应示例

**充值** `POST /api/v1/app/deposit`

```json
{"user_address": "0x玩家平台地址", "amount": 1000}
```

```json
{"code": 0, "msg": "充值已上链 (待确认)",
 "data": {"tx_hash": "0x2be6...", "symbol": "FARM", "amount": 1000,
          "credited": true, "confirmations_needed": 2}}
```

**提现** `POST /api/v1/app/withdraw` —— 返回 `{"data": {"burned": true, ...}}`;
游戏服务端收到 200 后应在游戏内为玩家入账相同数量。

**查询** `GET /api/v1/app/balance?user_address=0x...`

```json
{"code": 0, "data": {"address": "0x..", "symbol": "FARM", "balance": 550.0,
                     "usd_value": 55.0, "dex_price": 0.1,
                     "platform_coins": {"USDT": 12.5, "FARM": 550.0}}}
```

## 4. Python 接入示例

```python
import hmac, hashlib, time, json, requests

KEY, SECRET, HOST = "dk_xxx", "ds_xxx", "http://<host>:5000"

def call(method, path, body=None):
    ts = str(int(time.time()))
    if method == "GET":
        qs = "&".join(f"{k}={v}" for k, v in (body or {}).items())
        sign_src = qs
        url, payload = f"{HOST}{path}?{qs}", None
    else:
        sign_src = json.dumps(body, separators=(",", ":"))
        url, payload = f"{HOST}{path}", sign_src
    sig = hmac.new(SECRET.encode(), f"{method}\n{path}\n{ts}\n{sign_src}".encode(),
                   hashlib.sha256).hexdigest()
    return requests.request(method, url, data=payload, headers={
        "X-DEV-KEY": KEY, "X-TIMESTAMP": ts, "X-SIGNATURE": sig,
        "Content-Type": "application/json"}).json()

# 1) 玩家游戏币充值进平台
print(call("POST", "/api/v1/app/deposit", {"user_address": "0x..", "amount": 1000}))
# 2) 查询 (余额 + DEX 估值)
print(call("GET", "/api/v1/app/balance", {"user_address": "0x.."}))
# 3) 玩家离场: 销毁桥接币, 游戏侧入账
print(call("POST", "/api/v1/app/withdraw", {"user_address": "0x..", "amount": 300}))
```

## 5. 典型闭环 (外部游戏 ⇄ 平台)

```
外部游戏                     平台 (CyanXPan)
   │  POST /app/deposit  ──▶  桥接铸造 FARM → 玩家钱包 (上链)
   │                              │ 玩家: DEX Swap FARM→USDT
   │                              │       USDT 充入交易所 → 合约/现货
   │                              │       提币 USDT 回钱包 → Swap 回 FARM
   │  POST /app/withdraw ◀──  桥接烧毁 FARM (游戏侧为玩家入账)
```

## 6. 安全与限制

- Secret 仅在创建时完整展示于开发者控制台, 可随时「轮换密钥」(旧密钥立即失效)
- 限流 120 req/min/密钥; 超限返回 HTTP 429 / code -2112
- 单笔金额上限 1e12; 空投每批 ≤500 地址
- 平台为教学模拟链: mint/burn 全部真实写入链上交易并出块确认, 但**不涉及任何真实资产**
