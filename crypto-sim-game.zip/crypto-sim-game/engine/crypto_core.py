# -*- coding: utf-8 -*-
"""Web3 密码学核心 —— 纯 Python 手写实现, 零第三方依赖即可生成"真实格式"的区块链账户.

包含:
  - Keccak-256 (以太坊地址哈希, 手写 Keccak-f[1600] 置换)
  - secp256k1 椭圆曲线点乘 (私钥 -> 公钥, 手写 double-and-add)
  - RIPEMD-160 + SHA-256 -> Base58Check (比特币地址)
  - BIP39: 熵 -> 助记词 (2048 官方词表) -> PBKDF2-SHA512 种子
  - BIP32 风格派生 (简化: HMAC-SHA512 链码派生, m/44'/60'/0'/0/0 语义)
生成的地址在数学格式上与真实链一致 (可被区块浏览器结构校验), 但模拟链上没有真实资产。
"""
import hashlib
import hmac
import os

# ---------------- Keccak-256 (手写 Keccak-f[1600]) ----------------
_KECCAK_RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
    0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
_ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]
_MASK = (1 << 64) - 1


def _rol(x, n):
    n %= 64
    return ((x << n) | (x >> (64 - n))) & _MASK


def _keccak_f(state):
    """state: 25 个 64bit lane (5x5, x + 5y 索引)"""
    for rnd in range(24):
        # theta
        c = [state[x][0] ^ state[x][1] ^ state[x][2] ^ state[x][3] ^ state[x][4] for x in range(5)]
        d = [c[(x - 1) % 5] ^ _rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                state[x][y] ^= d[x]
        # rho + pi
        b = [[0] * 5 for _ in range(5)]
        for x in range(5):
            for y in range(5):
                b[y][(2 * x + 3 * y) % 5] = _rol(state[x][y], _ROT[x][y])
        # chi
        for x in range(5):
            for y in range(5):
                state[x][y] = b[x][y] ^ ((~b[(x + 1) % 5][y]) & b[(x + 2) % 5][y])
        # iota
        state[0][0] ^= _KECCAK_RC[rnd]
    return state


def _keccak_absorb(data, rate_bytes):
    state = [[0] * 5 for _ in range(5)]
    # 填充: 0x01 ... 0x80 (原始 Keccak, 非 SHA3 的 0x06)
    padded = bytearray(data)
    q = rate_bytes - (len(padded) % rate_bytes)
    padded += b"\x01" + b"\x00" * (q - 2) + b"\x80" if q >= 2 else b"\x81"
    for off in range(0, len(padded), rate_bytes):
        block = padded[off:off + rate_bytes]
        for i in range(rate_bytes // 8):
            lane = int.from_bytes(block[i * 8:(i + 1) * 8], "little")
            x, y = i % 5, i // 5
            state[x][y] ^= lane
        _keccak_f(state)
    # squeeze 32 字节
    out = bytearray()
    for i in range(4):  # 4*8 = 32 字节 < rate(136)
        x, y = i % 5, i // 5
        out += state[x][y].to_bytes(8, "little")
    return bytes(out)


def keccak256(data: bytes) -> bytes:
    return _keccak_absorb(data, 136)


# ---------------- secp256k1 椭圆曲线 ----------------
P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
Gx = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
Gy = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8


def _inv(a, m):
    return pow(a, -1, m)


def _ec_add(p1, p2):
    if p1 is None:
        return p2
    if p2 is None:
        return p1
    x1, y1 = p1
    x2, y2 = p2
    if x1 == x2 and (y1 + y2) % P == 0:
        return None
    if p1 == p2:
        lam = (3 * x1 * x1) * _inv(2 * y1, P) % P
    else:
        lam = (y2 - y1) * _inv(x2 - x1, P) % P
    x3 = (lam * lam - x1 - x2) % P
    y3 = (lam * (x1 - x3) - y1) % P
    return (x3, y3)


def _ec_mul(k, point):
    """double-and-add (仿射坐标, 单次生成足够快)"""
    result = None
    addend = point
    while k:
        if k & 1:
            result = _ec_add(result, addend)
        addend = _ec_add(addend, addend)
        k >>= 1
    return result


def privkey_to_pubkey(priv: bytes, compressed=True) -> bytes:
    d = int.from_bytes(priv, "big") % N
    pt = _ec_mul(d, (Gx, Gy))
    if pt is None:
        raise ValueError("bad privkey")
    x, y = pt
    if compressed:
        return b"\x02" + x.to_bytes(32, "big") if y % 2 == 0 else b"\x03" + x.to_bytes(32, "big")
    return b"\x04" + x.to_bytes(32, "big") + y.to_bytes(32, "big")


# ---------------- 地址编码 ----------------
_B58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def base58check(version: int, payload: bytes) -> str:
    data = bytes([version]) + payload
    chk = hashlib.sha256(hashlib.sha256(data).digest()).digest()[:4]
    full = data + chk
    num = int.from_bytes(full, "big")
    s = ""
    while num:
        num, r = divmod(num, 58)
        s = _B58_ALPHABET[r] + s
    pad = 0
    for b in full:
        if b == 0:
            pad += 1
        else:
            break
    return "1" * pad + s


def eth_address(priv: bytes) -> str:
    pub = privkey_to_pubkey(priv, compressed=False)
    h = keccak256(pub[1:])
    return "0x" + h[-20:].hex()


def btc_address(priv: bytes) -> str:
    pub = privkey_to_pubkey(priv, compressed=True)
    sha = hashlib.sha256(pub).digest()
    h160 = hashlib.new("ripemd160", sha).digest()
    return base58check(0x00, h160)


# ---------------- BIP39 ----------------
import pathlib

_WORDLIST = None


def _wordlist():
    global _WORDLIST
    if _WORDLIST is None:
        path = pathlib.Path(__file__).resolve().parent.parent / "data" / "bip39_english.txt"
        words = [w.strip() for w in path.read_text().splitlines() if w.strip()]
        assert len(words) == 2048, f"BIP39 词表异常: {len(words)}"
        _WORDLIST = words
    return _WORDLIST


def generate_mnemonic(strength_bits=128) -> str:
    """标准 BIP39: 熵 -> 校验位 -> 索引词组"""
    words = _wordlist()
    entropy = os.urandom(strength_bits // 8)
    bits = bin(int.from_bytes(entropy, "big"))[2:].zfill(strength_bits)
    chk_bits = bin(int.from_bytes(hashlib.sha256(entropy).digest(), "big"))[2:].zfill(256)[: strength_bits // 32]
    bits += chk_bits
    n = len(words)
    mnemonics = [words[int(bits[i * 11:(i + 1) * 11], 2)] for i in range(len(bits) // 11)]
    return " ".join(mnemonics)


def mnemonic_to_seed(mnemonic: str, passphrase="") -> bytes:
    """BIP39 标准: PBKDF2-HMAC-SHA512, 2048 轮, 盐 = 'mnemonic' + passphrase"""
    return hashlib.pbkdf2_hmac("sha512", mnemonic.encode(), ("mnemonic" + passphrase).encode(), 2048)


def validate_mnemonic(mnemonic: str) -> bool:
    """校验助记词 (词表 + 校验位)"""
    try:
        words = _wordlist()
        parts = mnemonic.strip().lower().split()
        if len(parts) not in (12, 15, 18, 21, 24):
            return False
        idxs = [words.index(w) for w in parts]
        bits = "".join(bin(i)[2:].zfill(11) for i in idxs)
        ent_bits = len(bits) * 32 // 33
        entropy = int(bits[:ent_bits], 2).to_bytes(ent_bits // 8, "big")
        chk = bin(int.from_bytes(hashlib.sha256(entropy).digest(), "big"))[2:].zfill(256)[: len(bits) - ent_bits]
        return bits[ent_bits:] == chk
    except Exception:
        return False


# ---------------- BIP32 风格派生 (简化语义版) ----------------
def derive_keypair(seed: bytes, path="m/44'/60'/0'/0/0"):
    """HMAC-SHA512 链式派生 (简化: 不做-hardened 曲线校验回退, 语义一致)
    返回 (eth_addr, btc_addr, priv_hex)"""
    I = hmac.new(b"Bitcoin seed", seed, hashlib.sha512).digest()
    key, chain = I[:32], I[32:]
    for seg in path.split("/")[1:]:
        hardened = seg.endswith("'")
        idx = int(seg.rstrip("'")) + (0x80000000 if hardened else 0)
        data = (b"\x00" + key) if hardened else privkey_to_pubkey(key, True)
        I = hmac.new(chain, data + idx.to_bytes(4, "big"), hashlib.sha512).digest()
        key = (int.from_bytes(I[:32], "big") % N).to_bytes(32, "big")
        chain = I[32:]
    priv = key
    return eth_address(priv), btc_address(priv), priv.hex()


def wallet_from_mnemonic(mnemonic: str, passphrase=""):
    seed = mnemonic_to_seed(mnemonic, passphrase)
    eth, btc, priv_hex = derive_keypair(seed)
    return {"eth": eth, "btc": btc, "priv_hex": priv_hex, "seed_hex": seed.hex()[:64]}


def wallet_from_random():
    return wallet_from_mnemonic(generate_mnemonic())


if __name__ == "__main__":
    import time
    t0 = time.time()
    m = generate_mnemonic()
    w = wallet_from_mnemonic(m)
    print("助记词:", m)
    print("ETH :", w["eth"])
    print("BTC :", w["btc"])
    print("耗时 %.2fs (含 BIP39 PBKDF2 2048 轮)" % (time.time() - t0))
    # 自检
    assert keccak256(b"") == bytes.fromhex("c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"), "keccak 自检失败"
    assert validate_mnemonic(m), "助记词校验失败"
    print("Keccak-256 空串自检通过 (与以太坊规范一致), 助记词校验通过")


# ---------------- ECDSA 签名/验签 (secp256k1, 确定性 k, 教学+开发者接口用) ----------------

def _msg_hash(msg) -> int:
    if isinstance(msg, str):
        msg = msg.encode("utf-8")
    return int.from_bytes(hashlib.sha256(msg).digest(), "big") % N


def ecdsa_sign(priv_hex: str, msg) -> str:
    """确定性 ECDSA (k 由 HMAC-SHA256(priv, z||counter) 派生, RFC6970 简化版) → hex(r||s)"""
    priv = bytes.fromhex(priv_hex)
    d = int.from_bytes(priv, "big") % N
    z = _msg_hash(msg)
    for counter in range(64):
        k = hmac.new(priv, z.to_bytes(32, "big") + counter.to_bytes(4, "big"),
                     hashlib.sha256).digest()
        k = int.from_bytes(k, "big") % N
        if k == 0:
            continue
        pt = _ec_mul(k, (Gx, Gy))
        r = pt[0] % N
        if r == 0:
            continue
        s = (_inv(k, N) * (z + r * d)) % N
        if s == 0:
            continue
        return f"{r:064x}{s:064x}"
    raise ValueError("签名失败")


def _decompress_pub(pub_hex: str):
    """压缩公钥 hex -> 仿射点"""
    b = bytes.fromhex(pub_hex)
    if len(b) == 65 and b[0] == 4:
        return (int.from_bytes(b[1:33], "big"), int.from_bytes(b[33:65], "big"))
    if len(b) == 33 and b[0] in (2, 3):
        x = int.from_bytes(b[1:], "big")
        y2 = (pow(x, 3, P) + 7) % P
        y = pow(y2, (P + 1) // 4, P)
        if (y * y) % P != y2:
            raise ValueError("invalid pubkey")
        if (y % 2) != (b[0] % 2):
            y = P - y
        return (x, y)
    raise ValueError("pubkey format")


def ecdsa_verify(pub_hex: str, msg, sig_hex: str) -> bool:
    try:
        q = _decompress_pub(pub_hex)
        sig = bytes.fromhex(sig_hex)
        r, s = int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big")
        if not (1 <= r < N and 1 <= s < N):
            return False
        z = _msg_hash(msg)
        w = _inv(s, N)
        u1 = (z * w) % N
        u2 = (r * w) % N
        pt = _ec_add(_ec_mul(u1, (Gx, Gy)), _ec_mul(u2, q))
        return pt is not None and pt[0] % N == r
    except Exception:
        return False
