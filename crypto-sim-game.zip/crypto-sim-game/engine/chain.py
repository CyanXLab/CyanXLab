# -*- coding: utf-8 -*-
"""模拟公链 + DeFi —— Web3 全仿真设施.

包含:
  - SimChain: 出块 (每 120 模拟分钟), mempool, tx 生命周期 (pending -> confirmed)
  - 钱包账户体系 (外部账户 EOA), 交易所热钱包充提币
  - 区块浏览器数据 (块 / 交易哈希 / 确认数 / gas)
  - AMM DEX: 恒定乘积 x*y=k, 与 CEX 价格偏差 -> 套利玩法; 模拟套利机器人缓慢搬平价差
  - 质押金库: 浮动 APY, 周期结算, 小概率"协议风险事件" (DeFi 风险教育)
"""
import hashlib
import json
import random
import time

from .crypto_core import wallet_from_mnemonic, generate_mnemonic

GAS_FEE_USD = 0.12          # 每笔链上操作的模拟 gas 费 (USDT 计价)
BLOCK_MINUTES = 120          # 2 模拟小时一个块
CONFIRMATIONS = 3            # 充币确认块数
ARBITRAGE_SPEED = 0.15       # 套利机器人每小时搬平价差的比例
STAKE_APY_BASE = 0.12
STAKE_RISK_P = 0.004         # 每 8h 协议风险事件概率
STAKE_RISK_LOSS = 0.10


def _tx_hash(payload):
    return "0x" + hashlib.sha256((str(payload) + str(time.time()) + str(random.random())).encode()).hexdigest()[:64]


class SimChain:
    def __init__(self, engine_ref):
        self.engine = engine_ref            # 引用 MarketEngine 读时间/价格
        self.wallets = {}                   # user: {"eth":addr,"btc":addr,"mnemonic":...,"balances":{coin:qty},"staked":...}
        self.mempool = []
        self.blocks = []                    # [{"height","ts","txs":[hash]}]
        self.txs = {}                       # hash -> {..., "confirms": n}
        self.faucet = None
        self.stake_pool = {"usdt": 0.0, "apy": STAKE_APY_BASE}
        self.stake_accrued = 0.0
        self.risk_events = []
        # DEX 池
        self.pools = {
            "SOL/USDT": {"x": 520000.0, "y": 520000.0 * 103.0, "coin": "SOLUSDT", "lp_fee": 0.003},
            "ETH/USDT": {"x": 48000.0, "y": 48000.0 * 2437.0, "coin": "ETHUSDT", "lp_fee": 0.003},
            "DOGE/USDT": {"x": 88000000.0, "y": 88000000.0 * 0.085, "coin": "DOGEUSDT", "lp_fee": 0.003},
        }

    # ---------- 钱包 ----------
    def create_wallet(self):
        mn = generate_mnemonic()
        w = wallet_from_mnemonic(mn)
        wid = "user-" + hashlib.sha256(w["eth"].encode()).hexdigest()[:8]
        self.wallets[wid] = {
            "id": wid, "mnemonic": mn, "eth": w["eth"], "btc": w["btc"],
            "balances": {"USDT": 0.0, "SOL": 0.0, "ETH": 0.0, "DOGE": 0.0, "BNB": 0.0},
            "staked_usdt": 0.0, "nfts": [], "created": time.time(),
        }
        return self.wallets[wid]

    # ---------- 交易 ----------
    def submit_tx(self, kind, frm, to, amount, coin="USDT", note=""):
        tx = {
            "hash": _tx_hash((kind, frm, to, amount, coin)),
            "type": kind,           # transfer / swap / stake / unstake / mint
            "from": frm, "to": to, "amount": round(amount, 8), "coin": coin,
            "fee": GAS_FEE_USD, "note": note,
            "ts": time.time(), "block": None, "confirms": 0,
            "sim_str": self.engine.sim_time_str(),
        }
        self.mempool.append(tx)
        self.txs[tx["hash"]] = tx
        return tx

    def on_minute(self, sim_minute):
        if sim_minute % BLOCK_MINUTES != 0:
            return
        height = len(self.blocks) + 1
        packed = self.mempool[:64]
        self.mempool = self.mempool[64:]
        block = {"height": height, "ts": self.engine.sim_time(), "sim_str": self.engine.sim_time_str(),
                 "txs": [t["hash"] for t in packed], "miner_reward": 0.5}
        self.blocks.append(block)
        for t in packed:
            t["block"] = height
            t["confirms"] = 1
        for t in self.txs.values():
            if t["block"] is not None:
                t["confirms"] = min(CONFIRMATIONS, t["confirms"] + 1)

    def wallet_balance(self, wid, coin="USDT"):
        w = self.wallets.get(wid)
        if not w:
            return 0.0
        return w["balances"].get(coin, 0.0)

    def explorer_recent(self, n=12):
        recent = sorted(self.txs.values(), key=lambda t: t["ts"], reverse=True)
        return recent[:n]

    # ---------- AMM DEX ----------
    def pool_price(self, pair):
        p = self.pools[pair]
        return p["y"] / p["x"]

    def swap_quote(self, pair, amount_in, direction):
        """direction: 'coin_to_usdt' 或 'usdt_to_coin'; 返回 (amount_out, price_effective, fee)"""
        p = self.pools[pair]
        f = p["lp_fee"]
        if direction == "coin_to_usdt":
            x_in = amount_in
        else:
            x_in = amount_in  # usdt 计为 y 输入 -> 输出 coin; 用对称公式处理
        if direction == "coin_to_usdt":
            amount_out = (p["y"] * x_in * (1 - f)) / (p["x"] + x_in * (1 - f))
            eff = amount_out / x_in
            return amount_out, eff, x_in * f
        else:
            amount_out = (p["x"] * amount_in * (1 - f)) / (p["y"] + amount_in * (1 - f))
            eff = amount_in / amount_out if amount_out > 0 else 0
            return amount_out, eff, amount_in * f

    def swap(self, pair, amount_in, direction):
        p = self.pools[pair]
        if direction == "coin_to_usdt":
            out, eff, fee = self.swap_quote(pair, amount_in, direction)
            p["x"] += amount_in
            p["y"] -= out
            return out, eff, fee
        else:
            out, eff, fee = self.swap_quote(pair, amount_in, direction)
            p["y"] += amount_in
            p["x"] -= out
            return out, eff, fee

    def arbitrage_tick(self, cex_prices):
        """套利机器人每小时搬平 DEX 与 CEX 价差 (创造可抢跑窗口)"""
        for pair, p in self.pools.items():
            cex = cex_prices.get(p["coin"])
            if not cex:
                continue
            dex = p["y"] / p["x"]
            gap = (dex - cex) / cex
            if abs(gap) < 0.0004:
                continue
            move = ARBITRAGE_SPEED * gap
            # 调整池子把 dex 价拉向 cex
            if gap > 0:   # dex 偏贵 -> 卖 coin 进池 (x 增 y 减)
                dx = p["x"] * move / (1 - move)
                p["x"] += dx
                p["y"] -= p["y"] * move
            else:         # dex 偏便宜 -> 买 coin (y 增 x 减)
                dy = p["y"] * (-move) / (1 - (-move))
                p["y"] += dy
                p["x"] -= p["x"] * (-move)

    # ---------- 质押 ----------
    def stake(self, wid, amount):
        w = self.wallets[wid]
        amount = round(float(amount), 2)
        if amount < 10:
            return False, "最低质押 10 USDT"
        if w["balances"].get("USDT", 0) < amount:
            return False, "钱包 USDT 不足"
        w["balances"]["USDT"] -= amount
        w["staked_usdt"] += amount
        self.stake_pool["usdt"] += amount
        self.submit_tx("stake", w["eth"], "0xSTAKE_POOL", amount, note="质押挖矿")
        return True, "ok"

    def unstake(self, wid, amount=None):
        w = self.wallets[wid]
        amt = min(w["staked_usdt"], amount if amount else w["staked_usdt"])
        if amt <= 0:
            return False, "无质押"
        w["staked_usdt"] -= amt
        w["balances"]["USDT"] = w["balances"].get("USDT", 0) + amt
        self.stake_pool["usdt"] -= amt
        self.submit_tx("unstake", "0xSTAKE_POOL", w["eth"], amt, note="赎回质押")
        return True, "ok"

    def stake_settle(self):
        """每 8 模拟小时结算一次利息"""
        total = self.stake_pool["usdt"]
        if total <= 0:
            return
        apy = self.stake_pool["apy"]
        interest = total * apy / (365 * 3)
        # 8h = 1/3 天
        for w in self.wallets.values():
            if w["staked_usdt"] > 0:
                gain = w["staked_usdt"] * apy / (365 * 3)
                w["staked_usdt"] += gain
        self.stake_pool["usdt"] += interest
        # 协议风险事件
        if random.random() < STAKE_RISK_P:
            loss = STAKE_RISK_LOSS
            for w in self.wallets.values():
                w["staked_usdt"] *= (1 - loss)
            self.stake_pool["usdt"] *= (1 - loss)
            self.risk_events.append({"t": self.engine.sim_time_str(), "loss": loss * 100})
            return {"risk": True, "loss_pct": loss * 100}
        return None

    # ---------- 快照 ----------
    def snapshot(self, wid=None, cex_prices=None):
        d = {
            "has_wallet": wid in self.wallets if wid else False,
            "wallet": None, "mempool_n": len(self.mempool),
            "height": len(self.blocks), "txs": self.explorer_recent(14),
            "pools": {pair: {"price": p["y"] / p["x"], "x": p["x"], "y": p["y"],
                             "cex": (cex_prices or {}).get(p["coin"]),
                             "gap_pct": round(((p["y"] / p["x"]) / (cex_prices or {}).get(p["coin"], p["y"] / p["x"]) - 1) * 100, 3)}
                      for pair, p in self.pools.items()},
            "stake_apy": round(self.stake_pool["apy"] * 100, 2),
            "stake_pool": round(self.stake_pool["usdt"], 2),
            "risk_events": self.risk_events[-5:],
            "confirmations": CONFIRMATIONS, "block_minutes": BLOCK_MINUTES,
        }
        w = self.wallets.get(wid) if wid else None
        if w:
            cex = cex_prices or {}
            total = w["balances"].get("USDT", 0.0)
            assets = []
            for coin, qty in w["balances"].items():
                if coin == "USDT" or qty <= 0:
                    continue
                px = next((cex[s] for s, meta in {"SOL": "SOLUSDT", "ETH": "ETHUSDT", "DOGE": "DOGEUSDT", "BNB": "BNBUSDT", "BTC": "BTCUSDT"}.items() if coin == meta.replace("USDT", "")), 0)
                if not px and (coin + "/USDT") in self.pools:
                    p0 = self.pools[coin + "/USDT"]           # 桥接代币: 按 DEX 池价估值
                    px = p0["y"] / p0["x"] if p0["x"] else 0
                val = qty * (px or 0)
                total += val
                assets.append({"coin": coin, "qty": round(qty, 6), "price": px, "value": round(val, 2)})
            d["wallet"] = {
                "id": w["id"], "eth": w["eth"], "btc": w["btc"],
                "balances": {k: round(v, 6) for k, v in w["balances"].items()},
                "assets": assets, "total_usd": round(total, 2),
                "staked_usdt": round(w["staked_usdt"], 2),
                "nfts": w["nfts"],
                "mnemonic": w["mnemonic"],   # 前端仅在"备份"时展示
            }
        return d


# faucet: 交易所热钱包地址
HOT_WALLET = "0x0000d8cA0F1eB4cAfeD8a9C0fF00000000000001"
