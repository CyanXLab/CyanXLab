# -*- coding: utf-8 -*-
"""CoinSprint —— 虚拟币短线投机模拟 · 完全仿真交易所 + Web3 + 社交 + 行为成瘾仪表盘

运行:  python3 app.py   ->  http://localhost:5000
"""
import hashlib
import hmac
import json
import os
import random
import secrets
import threading
import time
from collections import deque
import uuid

from flask import Flask, g, jsonify, render_template, request, session

from engine.ailab import AILab
from engine.accounts import Accounts
from engine.chain import SimChain, HOT_WALLET, CONFIRMATIONS, GAS_FEE_USD
from engine.exchange import Exchange
from engine.game import Game
from engine.history_data import COINS, COIN_META, load_all_models
from engine.market import MarketEngine
from engine.openapi import DevPlatform, ApiError
from engine.crypto_core import ecdsa_sign, ecdsa_verify, privkey_to_pubkey, wallet_from_mnemonic
from engine.social import Social

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAVE_PATH = os.path.join(BASE_DIR, "instance", "save.json")

app = Flask(__name__)
LOCK = threading.RLock()

# ---------------- 全局对象 ----------------
print("[CoinSprint] 正在学习历史数据并初始化引擎 ...")
_t0 = time.time()
MODELS, META = load_all_models()
ENGINE = MarketEngine(MODELS)
# ---------------- 多用户账户体系 (v1.5) ----------------
class UserState:
    """每用户独立的: 交易所账户 / 游戏化进度 / 个人事件流"""
    __slots__ = ("uid", "ex", "game", "feed")

    def __init__(self, uid):
        self.uid = uid
        self.ex = Exchange()
        self.game = Game()
        self.feed = deque(maxlen=120)


USERS = {}            # uid -> UserState
MAIN_UID = "main"     # 兼容旧 ver2 存档的默认账户
ACCOUNTS = Accounts(os.path.join(BASE_DIR, "instance", "accounts.json"))
EVENT_FEED = []       # 兼容占位 (已改为每用户 feed)
LAST_EVENT_ID = 0
SAVECounter = 0


def current_ustate():
    """请求上下文内返回当前用户; 无请求上下文(时钟线程/启动)回落主账户"""
    try:
        us = getattr(g, "ustate", None)
        if us is not None:
            return us
    except RuntimeError:
        pass
    return USERS.setdefault(MAIN_UID, UserState(MAIN_UID))


class _UProxy:
    """EX/GAME 动态代理: 属性与方法转发到当前用户状态 (含赋值)"""
    def __init__(self, attr):
        object.__setattr__(self, "_attr", attr)

    def _t(self):
        return getattr(current_ustate(), object.__getattribute__(self, "_attr"))

    def __getattr__(self, k):
        return getattr(self._t(), k)

    def __setattr__(self, k, v):
        setattr(self._t(), k, v)


EX = _UProxy("ex")    # 兼容旧代码的全局名 — 实际指向当前用户交易所
GAME = _UProxy("game")


def UID() -> str:
    return current_ustate().uid


def _ensure_user(uid) -> UserState:
    return USERS.setdefault(uid, UserState(uid))


CHAIN = SimChain(ENGINE)
SOCIAL = Social(ENGINE)
AILAB = AILab()
DEVP = DevPlatform(CHAIN)   # 开放平台: 跨游戏桥接 / 开发者 API (独立持久化, reset 不受影响)
SECRET_KEY_PATH = os.path.join(BASE_DIR, "instance", "secret.key")
if not os.path.exists(SECRET_KEY_PATH):
    os.makedirs(os.path.dirname(SECRET_KEY_PATH), exist_ok=True)
    with open(SECRET_KEY_PATH, "w") as _f:
        _f.write(secrets.token_hex(32))
app.secret_key = open(SECRET_KEY_PATH).read().strip()
USERS[MAIN_UID] = UserState(MAIN_UID)
_MAIN_CLAIMED = False   # 首位访客接管 main 账户(兼容旧存档); 标记必须放在模块级 — 存在 game.stats 里会被 reset 清掉
MATH_QUIZ = {}            # sid -> {"answers":[...], "ts":}
DEPOSIT_PENDING = []      # 待确认充币 {hash, coin, amount}
TOMATO_MINUTES = 25       # 真实时间搬砖
TOMATO_REWARD = 500.0
TOMATO_DAILY = 8
MATH_REWARD = 30.0
MATH_DAILY = 20


def push_events(evs, us=None):
    """事件写入指定用户(默认当前用户)的个人事件流; id 全局单调"""
    global LAST_EVENT_ID
    us = us or current_ustate()
    for e in evs:
        e["id"] = e.get("id") or (LAST_EVENT_ID + 1)
        LAST_EVENT_ID = max(LAST_EVENT_ID, e["id"])
        us.feed.append(e)


def marks_map():
    p = ENGINE.partial()
    return {s: ENGINE.coins[s].display_price(p) for s in COINS}


def process_game_hooks(evs, us=None):
    """交易事件 -> 游戏化/行为追踪/升级事件 (us: 目标用户, 默认当前)"""
    us = us or current_ustate()
    sim_ts = ENGINE.sim_time()
    sim_day = ENGINE.sim_day()
    mi = ENGINE.minute_index
    lv_before = us.game.level()
    for e in evs:
        t = e.get("type")
        if t == "fill":
            us.game.on_fill(e, evs)
            if e.get("maker"):
                us.game.on_maker_fill()
        elif t == "close":
            us.game.on_close(e, evs, sim_ts, sim_day)
            chase, extra = us.game.mark_trade(mi, e.get("pnl", 0), e.get("margin", 0) or 0)
            if chase:
                evs.append({"type": "chase_warn", "text": "检测到追损行为：上笔亏损后放大保证金再战。这是赌博成瘾的核心模式，请警惕。"})
            if extra == "cooldown":
                evs.append({"type": "cooldown", "text": "连亏 3 笔，强制冷静期 3 模拟小时。期间禁止开新仓（可在设置关闭）。"})
        elif t == "liq":
            us.game.on_liq(e, evs)
        elif t == "news":
            us.game.on_news(e, sim_ts)
    if us.game.level() > lv_before:
        lv, title, _, _ = us.game.level_info()
        evs.append({"type": "levelup", "level": lv, "title": title})


# ---------------- 币安实时参考价 (ccxt, 离线自动降级) ----------------
try:
    import ccxt
except ImportError:
    ccxt = None
REAL_TICKERS = {}          # sym -> {"price":, "chg":, "ts":}
_real_last = [0.0]


def refresh_real_tickers():
    """每 10 分钟拉一次币安现货实时价 (公开行情, 无需密钥); 失败静默保留旧值"""
    if time.time() - _real_last[0] < 600:
        return
    _real_last[0] = time.time()
    syms = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "DOGE/USDT", "BNB/USDT"]
    try:
        if ccxt is not None:
            ex = ccxt.binance({"enableRateLimit": True, "timeout": 8000})
            ts = ex.fetch_tickers(syms)
            for s in syms:
                t = ts.get(s) or {}
                if t.get("last"):
                    REAL_TICKERS[s.replace("/", "")] = {
                        "price": float(t["last"]),
                        "chg": round(float(t.get("percentage") or 0), 2)}
        else:
            import urllib.request as _u
            q = "%5B%22" + "%22,%22".join(syms) + "%22%5D"
            with _u.urlopen(f"https://api.binance.com/api/v3/ticker/24hr?symbols={q}", timeout=6) as r:
                for t in json.loads(r.read()):
                    REAL_TICKERS[t["symbol"]] = {"price": float(t["lastPrice"]),
                                                 "chg": round(float(t["priceChangePercent"]), 2)}
    except Exception:
        pass  # 离线/被墙 → 不显示参考价


def _real_refresher():
    while True:
        time.sleep(60)
        try:
            refresh_real_tickers()
        except Exception:
            pass


# ---------------- 存档 (多用户 users.json) ----------------
USERS_PATH = os.path.join(BASE_DIR, "instance", "users.json")


def save_state():
    with LOCK:
        os.makedirs(os.path.dirname(USERS_PATH), exist_ok=True)
        marks = marks_map()
        users_payload = {}
        wallets_payload = {}
        for uid, us in USERS.items():
            poss, orders = us.ex.snapshot(marks)
            users_payload[uid] = {
                "balance": us.ex.balance, "start_balance": us.ex.start_balance,
                "positions": poss,
                "orders": orders,
                "triggers": [{"id": t["id"], "coin": t["coin"], "side": t["side"], "margin": t["margin"],
                              "lev": t["lev"], "trigger": t["trigger"], "above": t["above"],
                              "tp_pct": t["tp_pct"], "sl_pct": t["sl_pct"]} for t in us.ex.triggers.values()],
                "close_orders": [{"id": c["id"], "pid": c["pid"], "price": c["price"], "fraction": c["fraction"]}
                                 for c in us.ex.close_orders.values()],
                "spot_hold": us.ex.spot_hold,
                "spot_orders": [{"id": o["id"], "coin": o["coin"], "side": o["side"], "usdt": o["usdt"],
                                 "price": o["price"], "qty": o["qty"]} for o in us.ex.spot_orders.values()],
                "history": list(us.ex.history)[:120],
                "fee_paid_total": us.ex.fee_paid_total, "funding_paid_total": us.ex.funding_paid_total,
                "maker_fills": us.ex.maker_fills,
                "game": {
                    "xp": us.game.xp, "achievements": us.game.achievements, "stats": us.game.stats,
                    "behavior": {"chase_events": us.game.behavior["chase_events"],
                                 "violations": us.game.behavior["violations"],
                                 "liq_count": us.game.behavior["liq_count"],
                                 "trade_marks": list(us.game.behavior["trade_marks"])[-120:]},
                    "cold_until": us.game.cold_until,
                    "config": us.game.config,
                    "labor": {"day": us.game.labor["day"], "tomatos": us.game.labor["tomatos"],
                              "math_done": us.game.labor["math_done"], "earned_total": us.game.labor["earned_total"],
                              "tomato_log": list(us.game.labor["tomato_log"])},
                    "equity_curve": list(us.game.equity_curve)[-600:],
                    "trade_events": list(us.game.trade_events)[:30],
                    "news_opportunity": us.game.news_opportunity,
                    "daily": getattr(us.game, "daily", {"day": -1, "list": []}),
                },
            }
            w = CHAIN.wallets.get(uid)
            if w:
                wallets_payload[uid] = {k: w[k] for k in ("mnemonic", "eth", "btc", "balances", "staked_usdt", "nfts")}
        data = {
            "ver": 3,
            "users": users_payload,
            "wallets": wallets_payload,
            "chain": {
                "txs": [{"hash": t["hash"], "type": t["type"], "from": t["from"], "to": t["to"],
                         "amount": t["amount"], "coin": t["coin"], "fee": t["fee"], "note": t["note"],
                         "ts": t["ts"], "block": t["block"], "sim_str": t.get("sim_str", "")}
                        for t in list(CHAIN.txs.values())[-60:]],
                "height": len(CHAIN.blocks),
                "pools": {pair: {"x": p["x"], "y": p["y"]} for pair, p in CHAIN.pools.items()},
                "stake_pool": CHAIN.stake_pool, "risk_events": CHAIN.risk_events[-5:],
            },
            "social": {
                "bots": [{"name": b["name"], "style": b["style"], "equity": b["equity"],
                          "win_rate": b["win_rate"], "trades": b["trades"], "curve": b["curve"][-72:]}
                         for b in SOCIAL.bots],
                "kol": {k: {"wins": v["wins"], "losses": v["losses"]} for k, v in SOCIAL.kol_state.items()},
                "feed": SOCIAL.feed[-40:], "signals": SOCIAL.signals[-20:],
                "msg_id": SOCIAL.msg_id,
            },
            "engine": {
                "minute_index": ENGINE.minute_index, "epoch": ENGINE.epoch,
                "seed": ENGINE.seed, "regime": ENGINE.regime, "regime_hours": ENGINE.regime_hours,
                "eid": ENGINE.eid, "speed": ENGINE.speed, "paused": ENGINE.paused,
                "coins": {
                    s: {"price": c.price, "sigma2": c.sigma2, "last_r_h": c.last_r_h, "mi": c.mi,
                        "candles": {iv: list(c.candles[iv]["closed"])[-400:] for iv in ("1m", "5m", "15m", "1h", "4h")}}
                    for s, c in ENGINE.coins.items()
                },
            },
        }
        tmp = USERS_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, separators=(",", ":"))
        os.replace(tmp, USERS_PATH)


def _apply_ex(ex, d):
    ex.balance = d["balance"]
    ex.start_balance = d.get("start_balance", 10000.0)
    ex.fee_paid_total = d.get("fee_paid_total", 0)
    ex.funding_paid_total = d.get("funding_paid_total", 0)
    ex.maker_fills = d.get("maker_fills", 0)
    ex.funding_rate = d.get("funding_rate", 0.0001)
    ex.funding_min = d.get("funding_min", 480)
    ex.spot_hold = {k: v for k, v in d.get("spot_hold", {}).items()}
    for o in d.get("orders", []):
        ex.orders[o["id"]] = {"id": o["id"], "coin": o["coin"], "side": o["side"], "margin": o["margin"],
                              "lev": o["lev"], "price": o["price"], "tp_pct": None, "sl_pct": None, "ts": time.time()}
    for t in d.get("triggers", []):
        ex.triggers[t["id"]] = {**t}
    for c in d.get("close_orders", []):
        ex.close_orders[c["id"]] = {**c}
    for o in d.get("spot_orders", []):
        ex.spot_orders[o["id"]] = {**o}
    if ex.positions or ex.orders:
        ex._nid = max(list(ex.positions.keys()) + list(ex.orders.keys()) + list(ex.triggers.keys()) +
                      list(ex.close_orders.keys()) + list(ex.spot_orders.keys()) or [0]) + 10
    for p in ex.positions.values():
        ex._refresh_risk(p)


def _apply_game(game, gd):
    game.xp = gd["xp"]
    game.achievements = dict(gd["achievements"])
    game.stats = gd["stats"]
    game.behavior["chase_events"] = gd.get("behavior", {}).get("chase_events", 0)
    game.behavior["violations"] = gd.get("behavior", {}).get("violations", 0)
    game.behavior["liq_count"] = gd.get("behavior", {}).get("liq_count", 0)
    for m in gd.get("behavior", {}).get("trade_marks", []):
        game.behavior["trade_marks"].append(m)
    game.cold_until = gd.get("cold_until", -1)
    game.config = {**game.config, **gd.get("config", {})}
    lb = gd.get("labor", {})
    for k in ("day", "tomatos", "math_done", "earned_total"):
        if k in lb:
            game.labor[k] = lb[k]
    for row in lb.get("tomato_log", []):
        game.labor["tomato_log"].append(row)
    for row in gd.get("equity_curve", []):
        game.equity_curve.append(tuple(row))
    for row in gd.get("trade_events", []):
        game.trade_events.append(row)
    game.news_opportunity = gd.get("news_opportunity", {})
    game.daily = gd.get("daily", {"day": -1, "list": []})


def load_state():
    """加载多用户存档; 兼容旧 ver2 单人 save.json 迁移到 main 账户"""
    loaded_any = False
    if os.path.exists(USERS_PATH):
        try:
            with open(USERS_PATH) as f:
                d = json.load(f)
            e = d.get("engine", {})
            ENGINE.minute_index = e.get("minute_index", ENGINE.minute_index)
            ENGINE.epoch = e.get("epoch", ENGINE.epoch)
            ENGINE.seed = e.get("seed", ENGINE.seed)
            ENGINE.regime = e.get("regime", ENGINE.regime)
            ENGINE.regime_hours = e.get("regime_hours", 0)
            ENGINE.eid = e.get("eid", 1)
            ENGINE.speed = e.get("speed", ENGINE.speed)
            ENGINE.paused = e.get("paused", False)
            for s, cs in e.get("coins", {}).items():
                c = ENGINE.coins.get(s)
                if not c:
                    continue
                c.price = cs["price"]
                c.sigma2 = cs.get("sigma2", c.sigma2)
                c.last_r_h = cs.get("last_r_h", 0)
                c.mi = cs.get("mi", 0)
                for iv, rows in cs.get("candles", {}).items():
                    if iv in c.candles:
                        c.candles[iv]["closed"].clear()
                        for row in rows:
                            c.candles[iv]["closed"].append(row)
                c._gen_book()
            ch = d.get("chain", {})
            for t in ch.get("txs", []):
                CHAIN.txs[t["hash"]] = {**t}
            CHAIN.blocks = [{"height": i + 1, "ts": ENGINE.sim_time(), "txs": []} for i in range(ch.get("height", 0))]
            for pair, pp in ch.get("pools", {}).items():
                if pair in CHAIN.pools:
                    CHAIN.pools[pair]["x"] = pp["x"]
                    CHAIN.pools[pair]["y"] = pp["y"]
                else:
                    CHAIN.pools[pair] = {"x": pp["x"], "y": pp["y"],
                                         "coin": pair.replace("/USDT", "") + "USDT", "lp_fee": 0.003}
            CHAIN.stake_pool.update(ch.get("stake_pool", {}))
            so = d.get("social", {})
            for b in so.get("bots", []):
                for bb in SOCIAL.bots:
                    if bb["name"] == b["name"]:
                        bb.update(b)
            SOCIAL.msg_id = so.get("msg_id", SOCIAL.msg_id)
            for uid, w in d.get("wallets", {}).items():
                CHAIN.wallets[uid] = {"id": uid, "mnemonic": w["mnemonic"], "eth": w["eth"], "btc": w["btc"],
                                      "balances": w.get("balances", {}), "staked_usdt": w.get("staked_usdt", 0.0),
                                      "nfts": w.get("nfts", []), "created": time.time()}
                DEVP._addr_idx[w["eth"].lower()] = uid
            for uid, up in d.get("users", {}).items():
                us = _ensure_user(uid)
                _apply_ex(us.ex, up)
                _apply_game(us.game, up.get("game", {}))
            loaded_any = True
            print(f"[CoinSprint] 多用户存档已恢复: {len(d.get('users', {}))} 个账户")
        except Exception:
            import traceback
            traceback.print_exc()
            print("[CoinSprint] users.json 加载失败, 尝试旧存档")
    if not loaded_any and os.path.exists(SAVE_PATH):
        try:
            with open(SAVE_PATH) as f:
                d = json.load(f)
            us = USERS.setdefault(MAIN_UID, UserState(MAIN_UID))
            _apply_ex(us.ex, d)
            _apply_game(us.game, d.get("game", {}))
            ch = d.get("chain", {})
            if ch.get("wallet"):
                w = ch["wallet"]
                CHAIN.wallets[MAIN_UID] = {"id": MAIN_UID, "mnemonic": w["mnemonic"], "eth": w["eth"], "btc": w["btc"],
                                           "balances": w.get("balances", {}), "staked_usdt": w.get("staked_usdt", 0.0),
                                           "nfts": w.get("nfts", []), "created": time.time()}
                DEVP._addr_idx[w["eth"].lower()] = MAIN_UID
            print("[CoinSprint] 旧版单人存档已迁移到 main 账户")
            loaded_any = True
        except Exception as ex:
            print("[CoinSprint] 旧存档迁移失败, 使用新游戏:", ex)
    return loaded_any


def reset_game():
    """重置当前用户的账户进度; 共享市场/链/社交换新世界; 开发者注册表不受影响"""
    global ENGINE, CHAIN, SOCIAL, AILAB
    with LOCK:
        ENGINE = MarketEngine(MODELS, seed=int(time.time() * 1000) & 0x7FFFFFFF)
        ENGINE.hooks.append(on_sim_minute)  # 关键: 重建引擎后必须重新注册每分钟钩子
        CHAIN = SimChain(ENGINE)
        DEVP.rebind(CHAIN)  # 开发平台重挂新链, 桥接池/注册表保留
        SOCIAL = Social(ENGINE)
        AILAB = AILab()
        DEPOSIT_PENDING.clear()
        us = current_ustate()
        us.ex = Exchange()
        us.game = Game()
        us.feed.clear()
        save_state()


# ---------------- 会话解析 (访客零摩擦自动建档) ----------------
@app.before_request
def _resolve_user():
    uid = session.get("uid")
    global _MAIN_CLAIMED
    if not uid or uid not in USERS:
        if not _MAIN_CLAIMED:
            # 首位访问者接管 main 账户 (保留旧存档迁移进度), 之后的所有新访客均为独立游客
            _MAIN_CLAIMED = True
            uid = MAIN_UID
        else:
            uid = ACCOUNTS.create_guest()
            _ensure_user(uid)
        session["uid"] = uid
    g.ustate = USERS[uid]


@app.route("/api/auth/me")
def auth_me():
    us = current_ustate()
    acc = ACCOUNTS.users.get(us.uid, {})
    return api_ok(uid=us.uid, username=acc.get("username") or "游客",
                  guest=bool(acc.get("guest", True)))


@app.route("/api/auth/register", methods=["POST"])
def auth_register():
    d = request.get_json(force=True)
    with LOCK:
        old = current_ustate()
        try:
            uid = ACCOUNTS.register(d.get("username"), d.get("password"))
        except ValueError as e:
            return api_err(str(e))
        if d.get("inherit"):
            USERS.pop(uid, None)
            USERS.pop(old.uid, None)            # 移除旧访客键, 避免同一对象双键重复
            old.uid = uid                       # 搬移当前访客的全部进度到正式账户
            USERS[uid] = old
            for row in list(old.feed):
                pass
            g.ustate = old
        else:
            _ensure_user(uid)
        session["uid"] = uid
        save_state()
        ACCOUNTS.save()
        return api_ok(msg=f"账号已创建: {d.get('username')}" + (" (已继承当前进度)" if d.get("inherit") else ""))


@app.route("/api/auth/login", methods=["POST"])
def auth_login():
    d = request.get_json(force=True)
    with LOCK:
        try:
            uid = ACCOUNTS.verify(d.get("username"), d.get("password"))
        except ValueError as e:
            return api_err(str(e))
        session["uid"] = uid
        _ensure_user(uid)
        g.ustate = USERS[uid]
        return api_ok(msg=f"欢迎回来, {d.get('username')}")


@app.route("/api/auth/logout", methods=["POST"])
def auth_logout():
    with LOCK:
        session.pop("uid", None)
        session.pop("main-claimed", None)
        uid = ACCOUNTS.create_guest()
        _ensure_user(uid)
        session["uid"] = uid
        g.ustate = USERS[uid]
        return api_ok(msg="已退出, 已为你切换到新的访客身份")


# ---------------- 时钟 ----------------
def on_sim_minute(mi):
    evs = []
    candles, marks = {}, {}
    for s, c in ENGINE.coins.items():
        kl = c.klines("1m", 1)
        if kl:
            row = kl[-1]
            candles[s] = (max(c.price, row[4]), row[2], row[3])
        else:
            candles[s] = (c.price, c.price, c.price)
        marks[s] = c.price
    # 市场事件 (新闻/市态) 广播给所有用户
    market_evs = [e for e in list(ENGINE.events) if e.get("id", 0) > LAST_EVENT_ID]
    if market_evs:
        for us in USERS.values():
            for e in market_evs:
                push_events([e], us)
    evs = []
    sim_ts = ENGINE.sim_time()
    move = min((c.price / c.close0_24 - 1) * 100 for c in ENGINE.coins.values())
    # 每用户独立撮合 (强平/TPSL/限价/资金费) + 游戏化
    for us in list(USERS.values()):
        uevs = []
        try:
            us.ex.on_minute(candles, ENGINE.regime, uevs, sim_ts=sim_ts)
            eq = us.ex.equity(marks)
            us.game._now_mi = mi
            us.game.labor_daily_reset(ENGINE.sim_day())
            us.game.on_minute(sim_ts, eq, ENGINE.regime, None, move, len(us.ex.positions) > 0)
            process_game_hooks(uevs, us)
            push_events(uevs, us)
        except Exception:
            import traceback
            traceback.print_exc()
    # 新模块 (共享世界)
    CHAIN.on_minute(mi)
    SOCIAL.kol_speak(evs)
    SOCIAL.resolve_kol_positions()
    if evs:
        for us in USERS.values():
            for e in evs:
                push_events([e], us)
    if mi % 60 == 0:
        SOCIAL.bots_hour(marks, ENGINE.regime)
        CHAIN.arbitrage_tick(marks)
        btc_kl = ENGINE.coins["BTCUSDT"].klines("1h", 40)
        if btc_kl:
            AILAB.on_hour_close([r[4] for r in btc_kl])
    if mi % 480 == 0:
        risk = CHAIN.stake_settle()
        if risk and risk.get("risk"):
            evs.append({"type": "defi_risk", "text": f"质押协议遭遇风险事件，本息 -{risk['loss_pct']:.0f}%。DeFi 不是稳赚的存款。"})
    # 充币确认
    for dep in list(DEPOSIT_PENDING):
        tx = CHAIN.txs.get(dep["hash"])
        if tx and tx["confirms"] >= CONFIRMATIONS:
            DEPOSIT_PENDING.remove(dep)
            if dep["coin"] == "USDT":
                EX.balance += dep["amount"]
            else:
                EX._spot_receive(dep["coin"], dep["amount"], dep["amount"] * marks.get(dep["coin"] + "USDT", 0))
            evs.append({"type": "deposit_ok", "coin": dep["coin"], "amount": round(dep["amount"], 4)})
    # 每日任务奖励 (us.game.daily.list 由 Game.on_close/on_fill 驱动进度)
    try:
        for m in getattr(us.game, "daily", {}).get("list", []):
            if m.get("done") and not m.get("paid"):
                m["paid"] = True
                us.ex.balance += m.get("reward", 0)
                evs.append({"type": "daily_done", "text": f"每日任务完成: {m['desc']} +{m['reward']} USDT 已到账"})
    except Exception:
        pass
    us.game.flush_unlocks(evs)
    process_game_hooks(evs, us)
    push_events(evs, us)


def clock_loop():
    ENGINE.hooks.append(on_sim_minute)
    while True:
        time.sleep(0.5)
        with LOCK:
            try:
                ENGINE.advance(ENGINE.speed * 0.5)
                global SAVECounter
                SAVECounter += 1
                if SAVECounter >= 60:
                    SAVECounter = 0
                    save_state()
            except Exception:
                import traceback
                traceback.print_exc()


# ---------------- API ----------------
def api_ok(**kw):
    kw["ok"] = True
    return jsonify(kw)


def api_err(msg):
    return jsonify({"ok": False, "msg": msg})


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/state")
def api_state():
    coin = request.args.get("coin", "BTCUSDT")
    if coin not in COINS:
        coin = "BTCUSDT"
    with LOCK:
        last_ev = int(request.args.get("last_ev", 0))
        p = ENGINE.partial()
        marks = {s: ENGINE.coins[s].display_price(p) for s in COINS}
        eq = EX.equity(marks)
        poss, orders = EX.snapshot(marks)
        c = ENGINE.coins[coin]
        us_cur = current_ustate()
        us_cur.game.ensure_daily(ENGINE.sim_day())   # 每日任务尽早可见
        feed = [e for e in us_cur.feed if e.get("id", 0) > last_ev][-25:]
        stage = GAME.stage_info()
        state = {
            "ok": True,
            "server_time": int(time.time()),
            "sim_time": ENGINE.sim_time(),
            "sim_str": ENGINE.sim_time_str(),
            "sim_day": ENGINE.sim_day(),
            "speed": ENGINE.speed, "paused": ENGINE.paused,
            "regime": ENGINE.regime, "regime_name": ["牛市", "熊市", "震荡"][ENGINE.regime],
            "coins": ENGINE.state_summary(),
            "display": marks,
            "account": {
                "balance": round(EX.balance, 2), "equity": round(eq, 2),
                "margin_used": round(EX.margin_used(), 2),
                "available": round(EX.balance, 2),
                "pnl_total": round(eq - EX.start_balance, 2),
                "spot_value": round(EX.spot_value(marks), 2),
                "spot_hold": EX.snapshot_spot(marks)[0],
            },
            "positions": poss, "orders": orders,
            "triggers": [{"id": t["id"], "coin": t["coin"], "side": t["side"], "lev": t["lev"],
                          "margin": t["margin"], "trigger": t["trigger"]} for t in EX.triggers.values()],
            "history": list(EX.history)[:30],
            "game": GAME.snapshot(eq),
            "account_name": (ACCOUNTS.users.get(us_cur.uid, {}) or {}).get("username", "游客"),
            "is_guest": bool((ACCOUNTS.users.get(us_cur.uid, {}) or {}).get("guest", True)),
            "daily_missions": getattr(us_cur.game, "daily", {}).get("list", []),
            "real_prices": REAL_TICKERS,
            "stage": stage,
            "cold_left": max(0, GAME.cold_until - ENGINE.minute_index),
            "pain": {"wage_cny": GAME.config["wage_cny"], "rate": 7.2},
            "labor": {"tomatos": GAME.labor["tomatos"], "tomato_cap": TOMATO_DAILY,
                      "math_done": GAME.labor["math_done"], "math_cap": MATH_DAILY,
                      "earned": round(GAME.labor["earned_total"], 2),
                      "tomato_active": {"sid": GAME.labor["tomato_started"][0],
                                        "end_ts": GAME.labor["tomato_started"][1] + TOMATO_MINUTES * 60}
                      if GAME.labor["tomato_started"] else None},
            "config": GAME.config,
            "book": c.book, "tape": list(c.tape)[:40],
            "events": feed,
            "last_event_id": LAST_EVENT_ID,
            "funding_rate": round(EX.funding_rate * 100, 4),
            "funding_in_min": EX.funding_min,
            "has_wallet": UID() in CHAIN.wallets,
        }
        return jsonify(state)


@app.route("/api/klines")
def api_klines():
    coin = request.args.get("coin", "BTCUSDT")
    iv = request.args.get("interval", "1m")
    limit = min(720, int(request.args.get("limit", 320)))
    if coin not in COINS or iv not in ("1m", "5m", "15m", "1h", "4h"):
        return api_err("bad params")
    with LOCK:
        return api_ok(coin=coin, interval=iv, candles=ENGINE.coins[coin].klines(iv, limit))


@app.route("/api/model")
def api_model():
    with LOCK:
        return api_ok(meta=META, regime=ENGINE.regime)


@app.route("/api/news")
def api_news():
    with LOCK:
        evs = [e for e in ENGINE.events if e["type"] in ("news", "regime")]
        return api_ok(news=list(evs)[::-1][:40])


# ---------- 交易 ----------
def _check_cold():
    if GAME.in_cold(ENGINE.minute_index):
        GAME.violation()
        return f"冷静期中，剩余 {GAME.cold_until - ENGINE.minute_index} 分钟禁止开新仓（设置中可关闭，但会记录违规）"
    return None


@app.route("/api/order", methods=["POST"])
def api_order():
    d = request.get_json(force=True)
    coin = d.get("coin")
    if coin not in COINS:
        return api_err("未知币种")
    side = 1 if d.get("side") == "long" else -1
    otype = d.get("type", "market")
    margin = float(d.get("margin", 0))
    lev = int(d.get("leverage", 1))
    price = d.get("price")
    price = float(price) if price else None
    tp_pct = d.get("tp_pct"); sl_pct = d.get("sl_pct")
    tp_pct = float(tp_pct) if tp_pct else None
    sl_pct = float(sl_pct) if sl_pct else None
    post_only = bool(d.get("post_only"))
    trigger = d.get("trigger")
    with LOCK:
        if otype != "trigger":
            cold = _check_cold()
            if cold:
                return api_err(cold)
        mark = ENGINE.mark_price(coin)
        depth = ENGINE.coins[coin].meta["depth_usd"]
        if otype == "trigger":
            if not trigger or float(trigger) <= 0:
                return api_err("请输入触发价")
            ok, msg, evs = EX.place_trigger(coin, side, margin, lev, float(trigger), mark, depth, tp_pct, sl_pct)
        else:
            if post_only and otype == "limit":
                if (side == 1 and price and price >= mark) or (side == -1 and price and price <= mark):
                    return api_err("Post-Only: 该限价会立即成交，已被拒单（保证 maker 费率）")
            ok, msg, evs = EX.place(coin, side, otype, margin, lev, price, mark, depth, tp_pct, sl_pct)
        if ok:
            process_game_hooks(evs)
            push_events(evs)
            save_state()
            return api_ok(msg=msg)
        return api_err(msg)


@app.route("/api/close", methods=["POST"])
def api_close():
    d = request.get_json(force=True)
    pid = int(d.get("position_id", 0))
    fraction = float(d.get("fraction", 1.0))
    with LOCK:
        p = EX.positions.get(pid)
        if not p:
            return api_err("仓位不存在")
        coin = p["coin"]
        mark = ENGINE.mark_price(coin)
        evs = []
        ok, msg = EX.close_position(pid, fraction, mark, evs)
        if ok:
            process_game_hooks(evs)
            push_events(evs)
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/close_limit", methods=["POST"])
def api_close_limit():
    d = request.get_json(force=True)
    with LOCK:
        pid = int(d.get("position_id", 0))
        price = float(d.get("price", 0))
        fraction = float(d.get("fraction", 1.0))
        if price <= 0:
            return api_err("价格无效")
        ok, msg = EX.place_limit_close(pid, price, fraction)
        if ok:
            return api_ok()
        return api_err(msg)


@app.route("/api/spot", methods=["POST"])
def api_spot():
    d = request.get_json(force=True)
    coin = d.get("coin")
    if coin not in COINS:
        return api_err("未知币种")
    side = 1 if d.get("side") == "buy" else -1
    otype = d.get("type", "market")
    usdt = float(d.get("usdt", 0))
    price = d.get("price")
    price = float(price) if price else None
    with LOCK:
        mark = ENGINE.mark_price(coin)
        ok, msg = EX.place_spot(coin, side, otype, usdt, price, mark)
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/tpsl", methods=["POST"])
def api_tpsl():
    d = request.get_json(force=True)
    with LOCK:
        pid = int(d.get("position_id", 0))
        tp = d.get("tp"); sl = d.get("sl")
        tp = float(tp) if tp not in (None, "", 0) else None
        sl = float(sl) if sl not in (None, "", 0) else None
        p = EX.positions.get(pid)
        if not p:
            return api_err("仓位不存在")
        ok, msg = EX.update_tp_sl(pid, tp, sl)
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/cancel", methods=["POST"])
def api_cancel():
    d = request.get_json(force=True)
    with LOCK:
        oid = int(d.get("order_id", 0))
        ok, msg = EX.cancel(oid)
        if not ok:
            if oid in EX.triggers:
                t = EX.triggers.pop(oid)
                EX.balance += t["margin"]
                ok = True
            elif oid in EX.spot_orders:
                so = EX.spot_orders.pop(oid)
                if so["side"] == 1:
                    EX.balance += so["usdt"]
                ok = True
            elif oid in EX.close_orders:
                EX.close_orders.pop(oid)
                ok = True
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/speed", methods=["POST"])
def api_speed():
    d = request.get_json(force=True)
    sp = int(d.get("speed", 60))
    if sp not in (1, 10, 60, 300):
        return api_err("无效速度")
    with LOCK:
        ENGINE.speed = sp
        ENGINE.paused = False
        return api_ok()


@app.route("/api/pause", methods=["POST"])
def api_pause():
    d = request.get_json(force=True)
    with LOCK:
        ENGINE.paused = bool(d.get("paused", not ENGINE.paused))
        return api_ok()


@app.route("/api/reset", methods=["POST"])
def api_reset():
    reset_game()
    return api_ok()


@app.route("/api/config", methods=["POST"])
def api_config():
    d = request.get_json(force=True)
    with LOCK:
        if "wage_cny" in d:
            try:
                GAME.config["wage_cny"] = max(5.0, min(3000.0, float(d["wage_cny"])))
            except (TypeError, ValueError):
                return api_err("时薪无效")
        if "cooling" in d:
            GAME.config["cooling"] = bool(d["cooling"])
        save_state()
        return api_ok(config=GAME.config)


# ---------- 劳动锚定 ----------
@app.route("/api/labor/start", methods=["POST"])
def labor_start():
    with LOCK:
        GAME.labor_daily_reset(ENGINE.sim_day())
        if GAME.labor["tomato_started"]:
            return api_err("已有搬砖会话进行中")
        if GAME.labor["tomatos"] >= TOMATO_DAILY:
            return api_err(f"今日搬砖已达上限 {TOMATO_DAILY} 个 —— 记住，现实里也没有无限精力")
        sid = uuid.uuid4().hex[:12]
        GAME.labor["tomato_started"] = (sid, time.time())
        return api_ok(sid=sid, minutes=TOMATO_MINUTES, end_ts=time.time() + TOMATO_MINUTES * 60)


@app.route("/api/labor/claim", methods=["POST"])
def labor_claim():
    with LOCK:
        st = GAME.labor["tomato_started"]
        if not st:
            return api_err("没有进行中的搬砖会话")
        sid, started = st
        if sid != request.get_json(force=True).get("sid"):
            return api_err("会话不匹配")
        elapsed = time.time() - started
        if elapsed < TOMATO_MINUTES * 60 - 2:
            left = int(TOMATO_MINUTES * 60 - elapsed)
            return api_err(f"还差 {left // 60} 分 {left % 60} 秒 —— 专注没有捷径，摸鱼不会被支付")
        GAME.labor["tomato_started"] = None
        GAME.labor["tomatos"] += 1
        GAME.labor["earned_total"] += TOMATO_REWARD
        GAME.labor["tomato_log"].append({"t": ENGINE.sim_time_str(), "gain": TOMATO_REWARD})
        EX.balance += TOMATO_REWARD
        push_events([{"type": "labor_paid", "amount": TOMATO_REWARD, "kind": "tomato"}])
        save_state()
        return api_ok(gain=TOMATO_REWARD, tomatos=GAME.labor["tomatos"])


@app.route("/api/labor/math")
def labor_math():
    rng = random.Random(time.time() * 1000)
    qs = []
    for _ in range(5):
        kind = rng.randint(0, 2)
        if kind == 0:
            a, b = rng.randint(12, 99), rng.randint(3, 9)
            qs.append({"q": f"{a} × {b} = ?", "a": a * b})
        elif kind == 1:
            a, b = rng.randint(300, 999), rng.randint(50, 299)
            qs.append({"q": f"{a} − {b} = ?", "a": a - b})
        else:
            pct = rng.choice([10, 15, 20, 25, 40, 60, 75])
            base = rng.randint(2, 40) * 10
            qs.append({"q": f"{base} 的 {pct}% = ?", "a": round(base * pct / 100, 2)})
    sid = uuid.uuid4().hex[:12]
    MATH_QUIZ[sid] = {"answers": [q.pop("a") for q in qs], "ts": time.time()}
    if len(MATH_QUIZ) > 12:
        oldest = min(MATH_QUIZ, key=lambda k: MATH_QUIZ[k]["ts"])
        MATH_QUIZ.pop(oldest)
    return api_ok(sid=sid, questions=qs, reward=MATH_REWARD)


@app.route("/api/labor/math/submit", methods=["POST"])
def labor_math_submit():
    d = request.get_json(force=True)
    with LOCK:
        quiz = MATH_QUIZ.pop(d.get("sid"), None)
        if not quiz:
            return api_err("题目已过期，刷新重试")
        GAME.labor_daily_reset(ENGINE.sim_day())
        if GAME.labor["math_done"] >= MATH_DAILY:
            return api_err(f"今日速算已达上限 {MATH_DAILY} 次")
        correct = 0
        for given, real in zip(d.get("answers", []), quiz["answers"]):
            try:
                if abs(float(given) - real) < 0.01:
                    correct += 1
            except (TypeError, ValueError):
                pass
        if correct == 5:
            gain = MATH_REWARD
        elif correct == 4:
            gain = MATH_REWARD * 0.4
        else:
            return api_ok(correct=correct, gain=0, msg=f"只对 {correct} 题，无工资（现实里算错账是要赔钱的）")
        GAME.labor["math_done"] += 1
        GAME.labor["earned_total"] += gain
        EX.balance += gain
        push_events([{"type": "labor_paid", "amount": gain, "kind": "math"}])
        save_state()
        return api_ok(correct=correct, gain=gain)


# ---------- Web3 ----------
@app.route("/api/wallet")
def api_wallet():
    with LOCK:
        marks = {s: ENGINE.coins[s].display_price(ENGINE.partial()) for s in COINS}
        return api_ok(**CHAIN.snapshot(UID(), marks))


@app.route("/api/wallet/create", methods=["POST"])
def wallet_create():
    with LOCK:
        if UID() in CHAIN.wallets:
            return api_err("已有钱包 —— 一人一助记词，别贪心")
        w = CHAIN.create_wallet()
        CHAIN.wallets[UID()] = w
        tx = CHAIN.submit_tx("mint", "0xGENESIS", w["eth"], 0, note="钱包注册 (无 gas, 教学链)")
        save_state()
        return api_ok(wallet={"eth": w["eth"], "btc": w["btc"], "mnemonic": w["mnemonic"], "tx": tx["hash"]})


@app.route("/api/wallet/withdraw", methods=["POST"])
def wallet_withdraw():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(UID())
        if not w:
            return api_err("请先创建钱包")
        coin = d.get("coin", "USDT")
        amount = float(d.get("amount", 0))
        if amount <= 0:
            return api_err("金额无效")
        if coin == "USDT":
            if EX.balance < amount + GAS_FEE_USD:
                return api_err("交易所 USDT 不足 (含 gas)")
            EX.balance -= (amount + GAS_FEE_USD)
        else:
            sym = coin + "USDT"
            if sym not in COINS:
                return api_err("不支持的币种")
            h = EX.spot_hold.get(sym)
            if not h or h["qty"] < amount:
                return api_err("现货持仓不足 —— 需先在现货页买入")
            EX._spot_sell_market(sym, amount, ENGINE.mark_price(sym))  # 划转 (成本对冲, 不产生盈亏记录)
            EX.spot_history.popleft() if EX.spot_history and EX.spot_history[0].get("pnl", 0) == 0 else None
            if EX.balance >= GAS_FEE_USD:
                EX.balance -= GAS_FEE_USD
        w["balances"][coin] = w["balances"].get(coin, 0) + amount
        tx = CHAIN.submit_tx("transfer", HOT_WALLET, w["eth"], amount, coin=coin, note="交易所提币")
        push_events([{"type": "withdraw_submitted", "coin": coin, "amount": round(amount, 4), "hash": tx["hash"]}])
        save_state()
        return api_ok(hash=tx["hash"], confirmations=CONFIRMATIONS)


@app.route("/api/wallet/deposit", methods=["POST"])
def wallet_deposit():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(UID())
        if not w:
            return api_err("请先创建钱包")
        coin = d.get("coin", "USDT")
        amount = float(d.get("amount", 0))
        if amount <= 0:
            return api_err("金额无效")
        if w["balances"].get(coin, 0) < amount:
            return api_err("钱包余额不足")
        w["balances"][coin] -= amount
        tx = CHAIN.submit_tx("transfer", w["eth"], HOT_WALLET, amount, coin=coin, note="充币到交易所")
        DEPOSIT_PENDING.append({"hash": tx["hash"], "coin": coin, "amount": amount})
        push_events([{"type": "deposit_submitted", "coin": coin, "amount": round(amount, 4),
                      "hash": tx["hash"], "need": CONFIRMATIONS}])
        save_state()
        return api_ok(hash=tx["hash"], confirmations=CONFIRMATIONS)


@app.route("/api/defi/swap", methods=["POST"])
def defi_swap():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(UID())
        if not w:
            return api_err("请先创建钱包")
        pair = d.get("pair", "SOL/USDT")
        if pair not in CHAIN.pools:
            return api_err("池子不存在")
        direction = d.get("direction", "usdt_to_coin")
        amount = float(d.get("amount", 0))
        coin_sym = CHAIN.pools[pair]["coin"].replace("USDT", "")
        if amount <= 0:
            return api_err("金额无效")
        if direction == "usdt_to_coin":
            if w["balances"].get("USDT", 0) < amount:
                return api_err("钱包 USDT 不足")
            out, eff, fee = CHAIN.swap(pair, amount, direction)
            w["balances"]["USDT"] -= amount
            w["balances"][coin_sym] = w["balances"].get(coin_sym, 0) + out
        else:
            if w["balances"].get(coin_sym, 0) < amount:
                return api_err(f"钱包 {coin_sym} 不足")
            out, eff, fee = CHAIN.swap(pair, amount, direction)
            w["balances"][coin_sym] -= amount
            w["balances"]["USDT"] = w["balances"].get("USDT", 0) + out
        tx = CHAIN.submit_tx("swap", w["eth"], f"0xPOOL_{pair.replace('/', '')}", amount,
                             coin="USDT" if direction == "usdt_to_coin" else coin_sym, note=f"DEX swap {pair}")
        save_state()
        return api_ok(out=round(out, 6), eff_price=round(eff, 6), fee=round(fee, 4), hash=tx["hash"])


@app.route("/api/defi/stake", methods=["POST"])
def defi_stake():
    d = request.get_json(force=True)
    with LOCK:
        ok, msg = CHAIN.stake(UID(), float(d.get("amount", 0)))
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/defi/unstake", methods=["POST"])
def defi_unstake():
    d = request.get_json(force=True)
    with LOCK:
        amt = d.get("amount")
        ok, msg = CHAIN.unstake(UID(), float(amt) if amt else None)
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/wallet/mint_nft", methods=["POST"])
def wallet_mint_nft():
    with LOCK:
        w = CHAIN.wallets.get(UID())
        if not w:
            return api_err("请先创建钱包")
        if EX.balance < 20:
            return api_err("Mint 需要 20 USDT gas")
        n = len(w["nfts"])
        names = ["💀 爆仓纪念 · 第一滴血", "🪦 爆仓纪念 · 百倍刺客", "🔥 爆仓纪念 · 杠杆的墓碑"]
        w["nfts"].append({"name": names[min(n, 2)], "id": f"LIQ#{1000 + n}",
                          "t": ENGINE.sim_time_str(), "gas": 20})
        EX.balance -= 20
        tx = CHAIN.submit_tx("mint", w["eth"], "0xNFT_MARKET", 0, note="Mint 爆仓纪念 NFT")
        push_events([{"type": "nft_minted", "name": w["nfts"][-1]["name"], "hash": tx["hash"]}])
        save_state()
        return api_ok(hash=tx["hash"])


# ---------- 社交 / AI ----------
@app.route("/api/social")
def api_social():
    with LOCK:
        return api_ok(**SOCIAL.snapshot())


@app.route("/api/leaderboard")
def api_leaderboard():
    with LOCK:
        marks = {s: ENGINE.coins[s].display_price(ENGINE.partial()) for s in COINS}
        lb = SOCIAL.leaderboard(0.0, player_name="__none__")
        rows = [r for r in lb if r["name"] != "__none__"]      # AI 机器人
        me = current_ustate()
        for us in USERS.values():
            acc = ACCOUNTS.users.get(us.uid, {})
            name = acc.get("username") or ("游客-" + us.uid[-4:])
            eq = us.ex.equity(marks)
            st = us.game.stats
            rows.append({"name": name + (" (我)" if us.uid == me.uid else ""),
                         "equity": round(eq, 2), "roi": (eq / us.ex.start_balance - 1) * 100,
                         "win_rate": round(st["wins"] / st["trades"] * 100, 1) if st["trades"] else None,
                         "trades": st["trades"], "curve": [e for _, e in list(us.game.equity_curve)[-48:]],
                         "is_player": us.uid == me.uid, "style": "player", "_uids": (us.uid,)})
        rows.sort(key=lambda r: -r["equity"])
        for i, r in enumerate(rows):
            r["rank"] = i + 1
        top = rows[:20]
        mine = [r for r in rows if r["is_player"] and me.uid in r.get("_uids", ())]
        # 保证"我"的行始终可见 (即使跌出前20, 真实交易所同款体验)
        if rows and not any(r["is_player"] for r in top):
            me_rows = [r for r in rows if r.get("is_player")]
            if me_rows:
                top = top[:19] + [{**me_rows[0]}]
        for r in top:
            r.pop("_uids", None)
        return api_ok(rows=top)


@app.route("/api/follow", methods=["POST"])
def api_follow():
    d = request.get_json(force=True)
    with LOCK:
        sig = SOCIAL.follow_signal(int(d.get("sig_id", 0)))
        if not sig:
            return api_err("信号已结束")
        cold = _check_cold()
        if cold:
            return api_err(cold)
        margin = min(float(d.get("margin", sig["margin"])), EX.balance * 0.5)
        evs = []
        ok, msg, evs = EX.place(sig["coin"], sig["side"], "market", round(margin, 2),
                                sig["lev"], None, ENGINE.mark_price(sig["coin"]),
                                ENGINE.coins[sig["coin"]].meta["depth_usd"])
        if ok:
            process_game_hooks(evs)
            push_events(evs)
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/lab")
def api_lab():
    with LOCK:
        return api_ok(**AILAB.snapshot())


@app.route("/api/share_data")
def api_share():
    with LOCK:
        marks = {s: ENGINE.coins[s].display_price(ENGINE.partial()) for s in COINS}
        eq = EX.equity(marks)
        g = GAME.snapshot(eq)
        rows = SOCIAL.leaderboard(eq)
        return api_ok(roi=g["roi"], equity=round(eq, 2), win_rate=g["win_rate"], trades=g["trades"],
                      level=g["level"], title=g["title"], best_streak=g["best_streak"],
                      rank=next(r["rank"] for r in rows if r["is_player"]),
                      total=len(rows), regime=ENGINE.regime_name, sim_str=ENGINE.sim_time_str(),
                      unlocked=sum(1 for a in g["achievements"] if a["unlocked"]), total_ach=len(g["achievements"]))



# ============================================================
#                  开放平台 (正式版 v1)
#     跨游戏资产桥接 · 开发者 API · 空投工具 · Web3 沙盒
# ============================================================

def _cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-DEV-KEY, X-TIMESTAMP, X-SIGNATURE"
    resp.headers["Access-Control-Max-Age"] = "600"
    return resp


def _v1_err(code, msg, http=400):
    resp = jsonify({"code": code, "msg": msg})
    resp.status_code = http
    return _cors(resp)


@app.route("/api/v1/<path:sub>", methods=["GET", "POST", "OPTIONS"])
def open_api(sub):
    """对外开放 API: 外部游戏接入 (充值/提现/空投/转账/查询)"""
    if request.method == "OPTIONS":
        return _cors(app.make_default_options_response())
    body_str = request.get_data(cache=True, as_text=True) or ""
    try:
        if sub == "ping":
            return _cors(jsonify({"code": 0, "msg": "pong", "server_time": int(time.time() * 1000),
                                  "sim_time": ENGINE.sim_time_str()}))
        if sub == "time":
            return _cors(jsonify({"code": 0, "serverTime": int(time.time() * 1000)}))
        if sub == "meta":
            return _cors(jsonify({"code": 0, "data": DEVP.api_meta()}))

        api_key = request.headers.get("X-DEV-KEY", "")
        ts = request.headers.get("X-TIMESTAMP", "")
        sig = request.headers.get("X-SIGNATURE", "")
        sign_src = request.query_string.decode() if request.method == "GET" else body_str  # GET 签 query string
        try:
            app = DEVP.verify_auth(request.method, "/api/v1/" + sub, ts, sig, sign_src, api_key)
        except ApiError as e:
            return _v1_err(e.code, e.msg, e.http)

        try:
            d = json.loads(body_str) if body_str else {}
        except json.JSONDecodeError:
            return _v1_err(-1100, "请求体不是合法 JSON", 400)
        if request.method == "GET":
            d = request.args.to_dict()

        if sub == "app/info":
            pair = DEVP._pair(app["symbol"])
            pool = CHAIN.pools.get(pair, {})
            return _cors(jsonify({"code": 0, "data": {
                "app_id": app["app_id"], "name": app["name"], "symbol": app["symbol"],
                "full": app["full"], "status": app["status"],
                "minted": app["minted"], "burned": app["burned"], "airdropped": app["airdropped"],
                "holders": len(app["holders"]),
                "dex_price": round(pool.get("y", 0) / pool.get("x", 1), 8) if pool else 0,
                "pool_usdt": round(pool.get("y", 0), 2) if pool else 0}}))
        if sub == "app/deposit":
            res = DEVP.deposit(app, d.get("user_address"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "充值已上链 (待确认)", "data": res}))
        if sub == "app/withdraw":
            res = DEVP.withdraw(app, d.get("user_address"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "提现已销毁上链, 请在游戏侧为玩家入账", "data": res}))
        if sub == "app/airdrop":
            res = DEVP.airdrop(app, d.get("to"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "空投完成", "data": res}))
        if sub == "app/transfer":
            res = DEVP.transfer(app, d.get("from"), d.get("to"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "转账已上链", "data": res}))
        if sub == "app/balance":
            return _cors(jsonify({"code": 0, "data": DEVP.balance(app, d.get("user_address"))}))
        return _v1_err(-1101, f"未知端点 /api/v1/{sub}", 404)
    except ApiError as e:
        return _v1_err(e.code, e.msg, e.http)
    except Exception as e:
        return _v1_err(-1000, f"内部错误: {e}", 500)


# ---------------- 开发者控制台 (游戏内页面, 平台本人即开发者后台) ----------------

@app.route("/api/dev/overview")
def dev_overview():
    with LOCK:
        return jsonify({"ok": True, "data": DEVP.overview(),
                        "meta": DEVP.api_meta(),
                        "wallet_addr": CHAIN.wallets[UID()]["eth"] if UID() in CHAIN.wallets else None,
                        "recent_txs": [t for t in CHAIN.explorer_recent(40)
                                       if str(t.get("coin", "")).endswith(tuple(a["symbol"] for a in DEVP.apps.values())) or
                                       t.get("type") in ("bridge_mint", "bridge_burn", "airdrop")][:14]})


@app.route("/api/dev/register", methods=["POST"])
def dev_register():
    d = request.get_json(force=True)
    with LOCK:
        try:
            app = DEVP.register(d.get("name"), d.get("symbol"), d.get("full"), d.get("seed_price", 0.1))
        except ApiError as e:
            return api_err(e.msg)
        save_state()
        return api_ok(msg=f"应用已创建: {app['name']} ({app['symbol']})", data=DEVP.overview()[0])


@app.route("/api/dev/rotate", methods=["POST"])
def dev_rotate():
    d = request.get_json(force=True)
    with LOCK:
        try:
            DEVP.rotate_secret(d.get("app_id"))
        except ApiError as e:
            return api_err(e.msg)
        return api_ok(msg="密钥已轮换, 旧密钥立即失效")


@app.route("/api/dev/airdrop", methods=["POST"])
def dev_airdrop():
    d = request.get_json(force=True)
    with LOCK:
        app = DEVP.apps.get(d.get("app_id"))
        if not app:
            return api_err("应用不存在")
        try:
            res = DEVP.airdrop(app, d.get("to"), d.get("amount"))
        except ApiError as e:
            return api_err(e.msg)
        save_state()
        return api_ok(msg=f"空投成功 {res['airdropped']} 个地址", data=res)


# ---------------- 钱包增强: 消息签名 / 私钥导出 ----------------

@app.route("/api/wallet/sign", methods=["POST"])
def wallet_sign():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(UID())
        if not w:
            return api_err("请先创建钱包")
        msg = str(d.get("message", ""))[:500]
        if not msg:
            return api_err("消息不能为空")
        priv_hex = wallet_from_mnemonic(w["mnemonic"])["priv_hex"]
        sig = ecdsa_sign(priv_hex, msg)
        pub = privkey_to_pubkey(bytes.fromhex(priv_hex)).hex()
        return api_ok(message=msg, signature=sig, pubkey=pub,
                      address=w["eth"], verified=ecdsa_verify(pub, msg, sig))


@app.route("/api/wallet/export", methods=["GET"])
def wallet_export():
    with LOCK:
        w = CHAIN.wallets.get(UID())
        if not w:
            return api_err("请先创建钱包")
        priv_hex = wallet_from_mnemonic(w["mnemonic"])["priv_hex"]
        return api_ok(address=w["eth"], private_key=priv_hex,
                      mnemonic=w["mnemonic"],
                      warning="⚠️ 私钥即资产。任何拿到它的人都能转走全部资产 — 绝不透露给他人 (现实亦然)")



# ---------------- 币安兼容公开行情端点 (测试网机器人/工具可直接对接) ----------------

_IV_MAP = {"1m": "1m", "5m": "5m", "15m": "15m", "1h": "1h", "4h": "4h"}


def _kl(sym, interval, limit):
    c = ENGINE.coins.get(sym)
    if not c:
        return None
    rows = c.klines(_IV_MAP.get(interval, "1m"), max(1, min(int(limit), 1000)))
    out = []
    for r in rows:
        t, o, h, l2, c2, v = r
        out.append([int(t * 1000), repr(o), repr(h), repr(l2), repr(c2), repr(v),
                    int((t + 60) * 1000), repr(v), 0, "0", "0", "0"])
    return out


@app.route("/api/v3/ping")
def v3_ping():
    return jsonify({})


@app.route("/api/v3/time")
def v3_time():
    return jsonify({"serverTime": int(time.time() * 1000)})


@app.route("/api/v3/exchangeInfo")
def v3_exchange_info():
    return jsonify({"symbols": [
        {"symbol": s, "status": "TRADING", "baseAsset": COIN_META[s]["sym"], "quoteAsset": "USDT",
         "permissions": ["SPOT", "TRD"],
         "filters": [{"filterType": "PRICE_FILTER", "tickSize": repr(COIN_META[s]["tick"])},
                     {"filterType": "LOT_SIZE", "stepSize": repr(COIN_META[s]["lot"])},
                     {"filterType": "MIN_NOTIONAL", "minNotional": repr(COIN_META[s]["min_notional"])}],
         "maxLeverage": COIN_META[s]["max_lev"]}
        for s in COINS]})


@app.route("/api/v3/klines")
def v3_klines():
    sym = request.args.get("symbol", "BTCUSDT").upper()
    rows = _kl(sym, request.args.get("interval", "1m"), request.args.get("limit", 300))
    if rows is None:
        return jsonify({"code": -1121, "msg": "Invalid symbol."}), 400
    return jsonify(rows)


@app.route("/api/v3/ticker/24hr")
def v3_ticker():
    sym = request.args.get("symbol", "").upper()
    summ = ENGINE.state_summary()

    def row(s):
        c = summ.get(s, {})
        px = c.get("price", 0)
        return {"symbol": s, "priceChange": round(px * (c.get("chg24", 0)) / (100 + c.get("chg24", 0)), 8),
                "priceChangePercent": repr(c.get("chg24", 0)), "lastPrice": repr(px),
                "highPrice": repr(c.get("high24", px)), "lowPrice": repr(c.get("low24", px)),
                "volume": repr(c.get("vol24", 0)), "quoteVolume": repr(c.get("vol24", 0) * px)}

    if sym:
        if sym not in summ:
            return jsonify({"code": -1121, "msg": "Invalid symbol."}), 400
        return jsonify(row(sym))
    return jsonify([row(s) for s in COINS])


@app.route("/fapi/v1/premiumIndex")
def fapi_premium():
    sym = request.args.get("symbol", "").upper()
    marks = marks_map()
    fr = EX.funding_rate

    def row(s):
        mk = marks.get(s, 0)
        return {"symbol": s, "markPrice": repr(mk), "indexPrice": repr(mk),
                "lastFundingRate": repr(fr), "nextFundingTime":
                    (int(ENGINE.sim_time() // 18000) + 1) * 18000 * 1000}

    if sym:
        if sym not in marks:
            return jsonify({"code": -1121, "msg": "Invalid symbol."}), 400
        return jsonify(row(sym))
    return jsonify([row(s) for s in COINS])


# ---------------- 外部游戏一键沙盒演示 (平台内模拟另一个游戏的完整接入) ----------------

@app.route("/api/dev/demo_bridge", methods=["POST"])
def dev_demo_bridge():
    """用应用自己的密钥在服务端走一遍: 充值→DEX→(玩家操作略)→提现, 输出每一步日志"""
    d = request.get_json(force=True)
    with LOCK:
        app = DEVP.apps.get(d.get("app_id"))
        if not app:
            return api_err("应用不存在")
        if UID() not in CHAIN.wallets:
            return api_err("请先在链上页创建钱包")
        addr = CHAIN.wallets[UID()]["eth"]
        log = []

        def call_v1(method, path, body):
            ts = str(int(time.time()))
            raw = json.dumps(body, separators=(",", ":"))
            sig = hmac.new(app["api_secret"].encode(), f"{method}\n{path}\n{ts}\n{raw}".encode(),
                           hashlib.sha256).hexdigest()
            # 直接内部调度 (与外部 HTTP 调用完全同路径)
            app_cli = app_server.test_client() if False else None
            headers = {"X-DEV-KEY": app["api_key"], "X-TIMESTAMP": ts, "X-SIGNATURE": sig,
                       "Content-Type": "application/json"}
            resp = _dispatch_v1(method, "/api/v1" + path, raw, headers)
            return resp

        try:
            r = call_v1("POST", "/app/deposit", {"user_address": addr, "amount": 200})
            log.append(("POST /app/deposit 200 FARM", r))
            r2 = call_v1("GET", f"/app/balance?user_address={addr}", None)
            log.append(("GET  /app/balance", r2))
            r3 = call_v1("POST", "/app/withdraw", {"user_address": addr, "amount": 80})
            log.append(("POST /app/withdraw 80", r3))
        except Exception as e:
            return api_err(f"演示失败: {e}")
        return api_ok(msg="外部游戏沙盒演示完成", steps=[{"step": s, "resp": r} for s, r in log])


def _dispatch_v1(method, path, raw_body, headers):
    """内部直调开放 API (复用 open_api 的鉴权与分发逻辑)"""
    sub = path.split("/api/v1/", 1)[1]
    api_key = headers.get("X-DEV-KEY", "")
    ts = headers.get("X-TIMESTAMP", "")
    sig = headers.get("X-SIGNATURE", "")
    try:
        app_ = DEVP.verify_auth(method, path, ts, sig, raw_body, api_key)
    except ApiError as e:
        return {"code": e.code, "msg": e.msg}
    try:
        d = json.loads(raw_body) if raw_body else {}
    except json.JSONDecodeError:
        return {"code": -1100, "msg": "bad json"}
    if method == "GET":
        from urllib.parse import parse_qs
        d = {k: v[0] for k, v in parse_qs(raw_body).items()}
    if sub == "app/deposit":
        return {"code": 0, "data": DEVP.deposit(app_, d.get("user_address"), d.get("amount"))}
    if sub == "app/withdraw":
        return {"code": 0, "data": DEVP.withdraw(app_, d.get("user_address"), d.get("amount"))}
    if sub == "app/balance":
        return {"code": 0, "data": DEVP.balance(app_, d.get("user_address"))}
    return {"code": -1101, "msg": "unsupported in demo"}


if __name__ == "__main__":
    loaded = load_state()
    print(f"[CoinSprint] 引擎就绪 ({time.time()-_t0:.1f}s), 存档: {'已恢复' if loaded else '新游戏'}")
    threading.Thread(target=clock_loop, daemon=True).start()
    threading.Thread(target=_real_refresher, daemon=True).start()
    refresh_real_tickers()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)
