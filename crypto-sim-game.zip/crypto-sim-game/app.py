# -*- coding: utf-8 -*-
"""CoinSprint —— 虚拟币短线投机模拟 · 完全仿真交易所 + Web3 + 社交 + 行为成瘾仪表盘

运行:  python3 app.py   ->  http://localhost:5000
"""
import json
import os
import random
import threading
import time
import uuid

from flask import Flask, jsonify, render_template, request

from engine.ailab import AILab
from engine.chain import SimChain, HOT_WALLET, CONFIRMATIONS, GAS_FEE_USD
from engine.exchange import Exchange
from engine.game import Game
from engine.history_data import COINS, COIN_META, load_all_models
from engine.market import MarketEngine
from engine.openapi import DevPlatform, ApiError
from engine.crypto_core import ecdsa_sign, ecdsa_verify, privkey_to_pubkey, wallet_from_mnemonic
from engine.social import Social

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAVE_PATH = os.path.join(BASE_DIR, "instance", "save.json")

app = Flask(__name__)
LOCK = threading.RLock()

# ---------------- 全局对象 ----------------
print("[CoinSprint] 正在学习历史数据并初始化引擎 ...")
_t0 = time.time()
MODELS, META = load_all_models()
ENGINE = MarketEngine(MODELS)
EX = Exchange()
GAME = Game()
CHAIN = SimChain(ENGINE)
SOCIAL = Social(ENGINE)
AILAB = AILab()
DEVP = DevPlatform(CHAIN)   # 开放平台: 跨游戏桥接 / 开发者 API (独立持久化, reset 不受影响)
EVENT_FEED = []
LAST_EVENT_ID = 0
SAVECounter = 0
MATH_QUIZ = {}            # sid -> {"answers":[...], "ts":}
DEPOSIT_PENDING = []      # 待确认充币 {hash, coin, amount}
TOMATO_MINUTES = 25       # 真实时间搬砖
TOMATO_REWARD = 500.0
TOMATO_DAILY = 8
MATH_REWARD = 30.0
MATH_DAILY = 20
WID = "main"


def push_events(evs):
    global LAST_EVENT_ID
    for e in evs:
        EVENT_FEED.append(e)
        LAST_EVENT_ID = max(LAST_EVENT_ID, e.get("id", 0) if isinstance(e.get("id", 0), int) else 0)
    del EVENT_FEED[:-80]


def marks_map():
    p = ENGINE.partial()
    return {s: ENGINE.coins[s].display_price(p) for s in COINS}


def process_game_hooks(evs):
    """交易事件 -> 游戏化/行为追踪/升级事件"""
    sim_ts = ENGINE.sim_time()
    sim_day = ENGINE.sim_day()
    mi = ENGINE.minute_index
    lv_before = GAME.level()
    for e in evs:
        t = e.get("type")
        if t == "fill":
            GAME.on_fill(e, evs)
            if e.get("maker"):
                GAME.on_maker_fill()
        elif t == "close":
            GAME.on_close(e, evs, sim_ts, sim_day)
            chase, extra = GAME.mark_trade(mi, e.get("pnl", 0), e.get("margin", 0) or 0)
            if chase:
                evs.append({"type": "chase_warn", "text": "检测到追损行为：上笔亏损后放大保证金再战。这是赌博成瘾的核心模式，请警惕。"})
            if extra == "cooldown":
                evs.append({"type": "cooldown", "text": "连亏 3 笔，强制冷静期 3 模拟小时。期间禁止开新仓（可在设置关闭）。"})
        elif t == "liq":
            GAME.on_liq(e, evs)
        elif t == "news":
            GAME.on_news(e, sim_ts)
    if GAME.level() > lv_before:
        lv, title, _, _ = GAME.level_info()
        evs.append({"type": "levelup", "level": lv, "title": title})


# ---------------- 存档 ----------------
def save_state():
    os.makedirs(os.path.dirname(SAVE_PATH), exist_ok=True)
    with LOCK:
        marks = marks_map()
        poss, orders = EX.snapshot(marks)
        data = {
            "ver": 2,
            "balance": EX.balance, "start_balance": EX.start_balance,
            "positions": poss,
            "orders": orders,
            "triggers": [{"id": t["id"], "coin": t["coin"], "side": t["side"], "margin": t["margin"],
                          "lev": t["lev"], "trigger": t["trigger"], "above": t["above"],
                          "tp_pct": t["tp_pct"], "sl_pct": t["sl_pct"]} for t in EX.triggers.values()],
            "close_orders": [{"id": c["id"], "pid": c["pid"], "price": c["price"], "fraction": c["fraction"]}
                             for c in EX.close_orders.values()],
            "spot_hold": EX.spot_hold,
            "spot_orders": [{"id": o["id"], "coin": o["coin"], "side": o["side"], "usdt": o["usdt"],
                             "price": o["price"], "qty": o["qty"]} for o in EX.spot_orders.values()],
            "history": list(EX.history)[:120],
            "fee_paid_total": EX.fee_paid_total, "funding_paid_total": EX.funding_paid_total,
            "maker_fills": EX.maker_fills, "funding_rate": EX.funding_rate, "funding_min": EX.funding_min,
            "game": {
                "xp": GAME.xp, "achievements": GAME.achievements, "stats": GAME.stats,
                "behavior": {"chase_events": GAME.behavior["chase_events"],
                             "violations": GAME.behavior["violations"],
                             "liq_count": GAME.behavior["liq_count"],
                             "trade_marks": list(GAME.behavior["trade_marks"])[-120:]},
                "cold_until": GAME.cold_until,
                "config": GAME.config,
                "labor": {"day": GAME.labor["day"], "tomatos": GAME.labor["tomatos"],
                          "math_done": GAME.labor["math_done"], "earned_total": GAME.labor["earned_total"],
                          "tomato_log": list(GAME.labor["tomato_log"])},
                "equity_curve": list(GAME.equity_curve)[-600:],
                "trade_events": list(GAME.trade_events)[:30],
                "news_opportunity": GAME.news_opportunity,
            },
            "chain": {
                "wallet": {k: CHAIN.wallets[WID][k] for k in ("mnemonic", "eth", "btc", "balances", "staked_usdt", "nfts")} if WID in CHAIN.wallets else None,
                "txs": [{"hash": t["hash"], "type": t["type"], "from": t["from"], "to": t["to"],
                         "amount": t["amount"], "coin": t["coin"], "fee": t["fee"], "note": t["note"],
                         "ts": t["ts"], "block": t["block"], "sim_str": t.get("sim_str", "")}
                        for t in list(CHAIN.txs.values())[-60:]],
                "height": len(CHAIN.blocks),
                "pools": {pair: {"x": p["x"], "y": p["y"]} for pair, p in CHAIN.pools.items()},
                "stake_pool": CHAIN.stake_pool, "risk_events": CHAIN.risk_events[-5:],
            },
            "social": {
                "bots": [{"name": b["name"], "style": b["style"], "equity": b["equity"],
                          "win_rate": b["win_rate"], "trades": b["trades"], "curve": b["curve"][-72:]}
                         for b in SOCIAL.bots],
                "kol": {k: {"wins": v["wins"], "losses": v["losses"]} for k, v in SOCIAL.kol_state.items()},
                "feed": SOCIAL.feed[-40:], "signals": SOCIAL.signals[-20:],
                "msg_id": SOCIAL.msg_id,
            },
            "engine": {
                "minute_index": ENGINE.minute_index, "epoch": ENGINE.epoch,
                "seed": ENGINE.seed, "regime": ENGINE.regime, "regime_hours": ENGINE.regime_hours,
                "eid": ENGINE.eid, "speed": ENGINE.speed, "paused": ENGINE.paused,
                "coins": {
                    s: {"price": c.price, "sigma2": c.sigma2, "last_r_h": c.last_r_h, "mi": c.mi,
                        "candles": {iv: list(c.candles[iv]["closed"])[-400:] for iv in ("1m", "5m", "15m", "1h", "4h")}}
                    for s, c in ENGINE.coins.items()
                },
            },
        }
    tmp = SAVE_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, separators=(",", ":"))
    os.replace(tmp, SAVE_PATH)


def load_state():
    if not os.path.exists(SAVE_PATH):
        return False
    try:
        with open(SAVE_PATH) as f:
            d = json.load(f)
        EX.balance = d["balance"]
        EX.start_balance = d.get("start_balance", 10000.0)
        EX.fee_paid_total = d.get("fee_paid_total", 0)
        EX.funding_paid_total = d.get("funding_paid_total", 0)
        EX.maker_fills = d.get("maker_fills", 0)
        EX.funding_rate = d.get("funding_rate", 0.0001)
        EX.funding_min = d.get("funding_min", 480)
        EX.spot_hold = {k: v for k, v in d.get("spot_hold", {}).items()}
        for o in d.get("orders", []):
            EX.orders[o["id"]] = {"id": o["id"], "coin": o["coin"], "side": o["side"], "margin": o["margin"],
                                  "lev": o["lev"], "price": o["price"], "tp_pct": None, "sl_pct": None, "ts": time.time()}
        for t in d.get("triggers", []):
            EX.triggers[t["id"]] = {**t}
        for c in d.get("close_orders", []):
            EX.close_orders[c["id"]] = {**c}
        for o in d.get("spot_orders", []):
            EX.spot_orders[o["id"]] = {**o}
        g = d["game"]
        GAME.xp = g["xp"]
        GAME.achievements = dict(g["achievements"])
        GAME.stats = g["stats"]
        GAME.behavior["chase_events"] = g.get("behavior", {}).get("chase_events", 0)
        GAME.behavior["violations"] = g.get("behavior", {}).get("violations", 0)
        GAME.behavior["liq_count"] = g.get("behavior", {}).get("liq_count", 0)
        for m in g.get("behavior", {}).get("trade_marks", []):
            GAME.behavior["trade_marks"].append(tuple(m))
        GAME.cold_until = g.get("cold_until", -1)
        GAME.config.update(g.get("config", {}))
        lb = g.get("labor", {})
        GAME.labor.update({"day": lb.get("day", -1), "tomatos": lb.get("tomatos", 0),
                           "math_done": lb.get("math_done", 0), "earned_total": lb.get("earned_total", 0.0)})
        for row in lb.get("tomato_log", []):
            GAME.labor["tomato_log"].append(row)
        GAME.equity_curve.clear()
        GAME.equity_curve.extend([tuple(x) for x in g["equity_curve"]])
        GAME.trade_events.clear()
        GAME.trade_events.extend(g["trade_events"])
        GAME.news_opportunity = g.get("news_opportunity", {})
        # 链
        cd = d.get("chain", {})
        if cd.get("wallet"):
            w = cd["wallet"]
            CHAIN.wallets[WID] = {"id": WID, "mnemonic": w["mnemonic"], "eth": w["eth"], "btc": w["btc"],
                                  "balances": w["balances"], "staked_usdt": w.get("staked_usdt", 0),
                                  "nfts": w.get("nfts", []), "created": time.time()}
        for t in cd.get("txs", []):
            CHAIN.txs[t["hash"]] = {**t, "confirms": CONFIRMATIONS}
        CHAIN.blocks = [{"height": i + 1, "ts": 0, "sim_str": "-", "txs": [], "miner_reward": 0.5}
                        for i in range(cd.get("height", 0))]
        for pair, pp in cd.get("pools", {}).items():
            if pair in CHAIN.pools:
                CHAIN.pools[pair]["x"] = pp["x"]
                CHAIN.pools[pair]["y"] = pp["y"]
        CHAIN.stake_pool.update(cd.get("stake_pool", {}))
        CHAIN.risk_events = cd.get("risk_events", [])
        # 社交
        sd = d.get("social", {})
        for b in sd.get("bots", []):
            match = next((x for x in SOCIAL.bots if x["name"] == b["name"]), None)
            if match:
                match["equity"] = b["equity"]
                match["win_rate"] = b["win_rate"]
                match["trades"] = b["trades"]
                match["curve"] = b.get("curve", [])
        for k, v in sd.get("kol", {}).items():
            if k in SOCIAL.kol_state:
                SOCIAL.kol_state[k]["wins"] = v["wins"]
                SOCIAL.kol_state[k]["losses"] = v["losses"]
        SOCIAL.feed = list(sd.get("feed", []))
        SOCIAL.signals = list(sd.get("signals", []))
        SOCIAL.msg_id = sd.get("msg_id", max([s["id"] for s in SOCIAL.signals] or [0]) + 1)
        # 引擎
        e = d["engine"]
        ENGINE.minute_index = e["minute_index"]
        ENGINE.epoch = e["epoch"]
        ENGINE.seed = e["seed"]
        ENGINE.regime = e["regime"]
        ENGINE.regime_hours = e.get("regime_hours", 0)
        ENGINE.eid = e.get("eid", 1)
        ENGINE.speed = e.get("speed", 60)
        ENGINE.paused = e.get("paused", False)
        for s, cdd in e["coins"].items():
            if s not in ENGINE.coins:
                continue
            c = ENGINE.coins[s]
            c.price = cdd["price"]
            c.sigma2 = cdd["sigma2"]
            c.last_r_h = cdd.get("last_r_h", 0)
            c.mi = 60
            for iv, rows in cdd["candles"].items():
                c.candles[iv]["closed"].clear()
                for r in rows:
                    c.candles[iv]["closed"].append(r)
                c.candles[iv]["cur"] = None
            c._closes.clear(); c._his.clear(); c._los.clear(); c._vols.clear()
            for row in c.klines("1m", 1440):
                c._closes.append(row[4]); c._his.append(row[2]); c._los.append(row[3]); c._vols.append(row[5])
            if c._closes:
                c.close0_24 = c._closes[0]
                c.hi24 = max(c._his); c.lo24 = min(c._los); c.vol24 = sum(c._vols)
            c._gen_book()
        if EX.positions or EX.orders:
            EX._nid = max(list(EX.positions.keys()) + list(EX.orders.keys()) + list(EX.triggers.keys()) +
                          list(EX.close_orders.keys()) + list(EX.spot_orders.keys()) or [0]) + 10
        return True
    except Exception as ex:
        import traceback
        traceback.print_exc()
        print("[CoinSprint] 存档加载失败, 使用新游戏:", ex)
        return False


def reset_game():
    global ENGINE, EX, GAME, CHAIN, SOCIAL, AILAB, LAST_EVENT_ID, DEPOSIT_PENDING
    with LOCK:
        ENGINE = MarketEngine(MODELS, seed=int(time.time() * 1000) & 0x7FFFFFFF)
        ENGINE.hooks.append(on_sim_minute)  # 关键: 重建引擎后必须重新注册每分钟钩子, 否则强平/TP/SL/限价成交全部失效
        EX = Exchange()
        GAME = Game()
        CHAIN = SimChain(ENGINE)
        DEVP.rebind(CHAIN)  # 开发平台重挂新链, 桥接池/注册表保留
        SOCIAL = Social(ENGINE)
        AILAB = AILab()
        EVENT_FEED.clear()
        DEPOSIT_PENDING.clear()
        LAST_EVENT_ID = 0
        if os.path.exists(SAVE_PATH):
            os.remove(SAVE_PATH)


# ---------------- 时钟 ----------------
def on_sim_minute(mi):
    evs = []
    candles, marks = {}, {}
    for s, c in ENGINE.coins.items():
        kl = c.klines("1m", 1)
        if kl:
            row = kl[-1]
            candles[s] = (max(c.price, row[4]), row[2], row[3])
        else:
            candles[s] = (c.price, c.price, c.price)
        marks[s] = c.price
    EX.on_minute(candles, ENGINE.regime, evs, sim_ts=ENGINE.sim_time())
    eq = EX.equity(marks)
    move = min((c.price / c.close0_24 - 1) * 100 for c in ENGINE.coins.values())
    GAME._now_mi = mi
    GAME.labor_daily_reset(ENGINE.sim_day())
    GAME.on_minute(ENGINE.sim_time(), eq, ENGINE.regime, None, move, len(EX.positions) > 0)
    # 新模块
    CHAIN.on_minute(mi)
    SOCIAL.kol_speak(evs)
    SOCIAL.resolve_kol_positions()
    if mi % 60 == 0:
        SOCIAL.bots_hour(marks, ENGINE.regime)
        CHAIN.arbitrage_tick(marks)
        btc_kl = ENGINE.coins["BTCUSDT"].klines("1h", 40)
        if btc_kl:
            AILAB.on_hour_close([r[4] for r in btc_kl])
    if mi % 480 == 0:
        risk = CHAIN.stake_settle()
        if risk and risk.get("risk"):
            evs.append({"type": "defi_risk", "text": f"质押协议遭遇风险事件，本息 -{risk['loss_pct']:.0f}%。DeFi 不是稳赚的存款。"})
    # 充币确认
    for dep in list(DEPOSIT_PENDING):
        tx = CHAIN.txs.get(dep["hash"])
        if tx and tx["confirms"] >= CONFIRMATIONS:
            DEPOSIT_PENDING.remove(dep)
            if dep["coin"] == "USDT":
                EX.balance += dep["amount"]
            else:
                EX._spot_receive(dep["coin"], dep["amount"], dep["amount"] * marks.get(dep["coin"] + "USDT", 0))
            evs.append({"type": "deposit_ok", "coin": dep["coin"], "amount": round(dep["amount"], 4)})
    GAME.flush_unlocks(evs)
    process_game_hooks(evs)
    push_events(evs)


def clock_loop():
    ENGINE.hooks.append(on_sim_minute)
    while True:
        time.sleep(0.5)
        with LOCK:
            try:
                ENGINE.advance(ENGINE.speed * 0.5)
                global SAVECounter
                SAVECounter += 1
                if SAVECounter >= 60:
                    SAVECounter = 0
                    save_state()
            except Exception:
                import traceback
                traceback.print_exc()


# ---------------- API ----------------
def api_ok(**kw):
    kw["ok"] = True
    return jsonify(kw)


def api_err(msg):
    return jsonify({"ok": False, "msg": msg})


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/state")
def api_state():
    coin = request.args.get("coin", "BTCUSDT")
    if coin not in COINS:
        coin = "BTCUSDT"
    with LOCK:
        last_ev = int(request.args.get("last_ev", 0))
        p = ENGINE.partial()
        marks = {s: ENGINE.coins[s].display_price(p) for s in COINS}
        eq = EX.equity(marks)
        poss, orders = EX.snapshot(marks)
        c = ENGINE.coins[coin]
        feed = [e for e in EVENT_FEED if e.get("id", 0) > last_ev][-25:]
        stage = GAME.stage_info()
        state = {
            "ok": True,
            "server_time": int(time.time()),
            "sim_time": ENGINE.sim_time(),
            "sim_str": ENGINE.sim_time_str(),
            "sim_day": ENGINE.sim_day(),
            "speed": ENGINE.speed, "paused": ENGINE.paused,
            "regime": ENGINE.regime, "regime_name": ["牛市", "熊市", "震荡"][ENGINE.regime],
            "coins": ENGINE.state_summary(),
            "display": marks,
            "account": {
                "balance": round(EX.balance, 2), "equity": round(eq, 2),
                "margin_used": round(EX.margin_used(), 2),
                "available": round(EX.balance, 2),
                "pnl_total": round(eq - EX.start_balance, 2),
                "spot_value": round(EX.spot_value(marks), 2),
                "spot_hold": EX.snapshot_spot(marks)[0],
            },
            "positions": poss, "orders": orders,
            "triggers": [{"id": t["id"], "coin": t["coin"], "side": t["side"], "lev": t["lev"],
                          "margin": t["margin"], "trigger": t["trigger"]} for t in EX.triggers.values()],
            "history": list(EX.history)[:30],
            "game": GAME.snapshot(eq),
            "stage": stage,
            "cold_left": max(0, GAME.cold_until - ENGINE.minute_index),
            "pain": {"wage_cny": GAME.config["wage_cny"], "rate": 7.2},
            "labor": {"tomatos": GAME.labor["tomatos"], "tomato_cap": TOMATO_DAILY,
                      "math_done": GAME.labor["math_done"], "math_cap": MATH_DAILY,
                      "earned": round(GAME.labor["earned_total"], 2),
                      "tomato_active": {"sid": GAME.labor["tomato_started"][0],
                                        "end_ts": GAME.labor["tomato_started"][1] + TOMATO_MINUTES * 60}
                      if GAME.labor["tomato_started"] else None},
            "config": GAME.config,
            "book": c.book, "tape": list(c.tape)[:40],
            "events": feed,
            "last_event_id": LAST_EVENT_ID,
            "funding_rate": round(EX.funding_rate * 100, 4),
            "funding_in_min": EX.funding_min,
            "has_wallet": WID in CHAIN.wallets,
        }
        return jsonify(state)


@app.route("/api/klines")
def api_klines():
    coin = request.args.get("coin", "BTCUSDT")
    iv = request.args.get("interval", "1m")
    limit = min(720, int(request.args.get("limit", 320)))
    if coin not in COINS or iv not in ("1m", "5m", "15m", "1h", "4h"):
        return api_err("bad params")
    with LOCK:
        return api_ok(coin=coin, interval=iv, candles=ENGINE.coins[coin].klines(iv, limit))


@app.route("/api/model")
def api_model():
    with LOCK:
        return api_ok(meta=META, regime=ENGINE.regime)


@app.route("/api/news")
def api_news():
    with LOCK:
        evs = [e for e in ENGINE.events if e["type"] in ("news", "regime")]
        return api_ok(news=list(evs)[::-1][:40])


# ---------- 交易 ----------
def _check_cold():
    if GAME.in_cold(ENGINE.minute_index):
        GAME.violation()
        return f"冷静期中，剩余 {GAME.cold_until - ENGINE.minute_index} 分钟禁止开新仓（设置中可关闭，但会记录违规）"
    return None


@app.route("/api/order", methods=["POST"])
def api_order():
    d = request.get_json(force=True)
    coin = d.get("coin")
    if coin not in COINS:
        return api_err("未知币种")
    side = 1 if d.get("side") == "long" else -1
    otype = d.get("type", "market")
    margin = float(d.get("margin", 0))
    lev = int(d.get("leverage", 1))
    price = d.get("price")
    price = float(price) if price else None
    tp_pct = d.get("tp_pct"); sl_pct = d.get("sl_pct")
    tp_pct = float(tp_pct) if tp_pct else None
    sl_pct = float(sl_pct) if sl_pct else None
    post_only = bool(d.get("post_only"))
    trigger = d.get("trigger")
    with LOCK:
        if otype != "trigger":
            cold = _check_cold()
            if cold:
                return api_err(cold)
        mark = ENGINE.mark_price(coin)
        depth = ENGINE.coins[coin].meta["depth_usd"]
        if otype == "trigger":
            if not trigger or float(trigger) <= 0:
                return api_err("请输入触发价")
            ok, msg, evs = EX.place_trigger(coin, side, margin, lev, float(trigger), mark, depth, tp_pct, sl_pct)
        else:
            if post_only and otype == "limit":
                if (side == 1 and price and price >= mark) or (side == -1 and price and price <= mark):
                    return api_err("Post-Only: 该限价会立即成交，已被拒单（保证 maker 费率）")
            ok, msg, evs = EX.place(coin, side, otype, margin, lev, price, mark, depth, tp_pct, sl_pct)
        if ok:
            process_game_hooks(evs)
            push_events(evs)
            save_state()
            return api_ok(msg=msg)
        return api_err(msg)


@app.route("/api/close", methods=["POST"])
def api_close():
    d = request.get_json(force=True)
    pid = int(d.get("position_id", 0))
    fraction = float(d.get("fraction", 1.0))
    with LOCK:
        p = EX.positions.get(pid)
        if not p:
            return api_err("仓位不存在")
        coin = p["coin"]
        mark = ENGINE.mark_price(coin)
        evs = []
        ok, msg = EX.close_position(pid, fraction, mark, evs)
        if ok:
            process_game_hooks(evs)
            push_events(evs)
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/close_limit", methods=["POST"])
def api_close_limit():
    d = request.get_json(force=True)
    with LOCK:
        pid = int(d.get("position_id", 0))
        price = float(d.get("price", 0))
        fraction = float(d.get("fraction", 1.0))
        if price <= 0:
            return api_err("价格无效")
        ok, msg = EX.place_limit_close(pid, price, fraction)
        if ok:
            return api_ok()
        return api_err(msg)


@app.route("/api/spot", methods=["POST"])
def api_spot():
    d = request.get_json(force=True)
    coin = d.get("coin")
    if coin not in COINS:
        return api_err("未知币种")
    side = 1 if d.get("side") == "buy" else -1
    otype = d.get("type", "market")
    usdt = float(d.get("usdt", 0))
    price = d.get("price")
    price = float(price) if price else None
    with LOCK:
        mark = ENGINE.mark_price(coin)
        ok, msg = EX.place_spot(coin, side, otype, usdt, price, mark)
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/tpsl", methods=["POST"])
def api_tpsl():
    d = request.get_json(force=True)
    with LOCK:
        pid = int(d.get("position_id", 0))
        tp = d.get("tp"); sl = d.get("sl")
        tp = float(tp) if tp not in (None, "", 0) else None
        sl = float(sl) if sl not in (None, "", 0) else None
        p = EX.positions.get(pid)
        if not p:
            return api_err("仓位不存在")
        ok, msg = EX.update_tp_sl(pid, tp, sl)
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/cancel", methods=["POST"])
def api_cancel():
    d = request.get_json(force=True)
    with LOCK:
        oid = int(d.get("order_id", 0))
        ok, msg = EX.cancel(oid)
        if not ok:
            if oid in EX.triggers:
                t = EX.triggers.pop(oid)
                EX.balance += t["margin"]
                ok = True
            elif oid in EX.spot_orders:
                so = EX.spot_orders.pop(oid)
                if so["side"] == 1:
                    EX.balance += so["usdt"]
                ok = True
            elif oid in EX.close_orders:
                EX.close_orders.pop(oid)
                ok = True
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/speed", methods=["POST"])
def api_speed():
    d = request.get_json(force=True)
    sp = int(d.get("speed", 60))
    if sp not in (1, 10, 60, 300):
        return api_err("无效速度")
    with LOCK:
        ENGINE.speed = sp
        ENGINE.paused = False
        return api_ok()


@app.route("/api/pause", methods=["POST"])
def api_pause():
    d = request.get_json(force=True)
    with LOCK:
        ENGINE.paused = bool(d.get("paused", not ENGINE.paused))
        return api_ok()


@app.route("/api/reset", methods=["POST"])
def api_reset():
    reset_game()
    return api_ok()


@app.route("/api/config", methods=["POST"])
def api_config():
    d = request.get_json(force=True)
    with LOCK:
        if "wage_cny" in d:
            try:
                GAME.config["wage_cny"] = max(5.0, min(3000.0, float(d["wage_cny"])))
            except (TypeError, ValueError):
                return api_err("时薪无效")
        if "cooling" in d:
            GAME.config["cooling"] = bool(d["cooling"])
        save_state()
        return api_ok(config=GAME.config)


# ---------- 劳动锚定 ----------
@app.route("/api/labor/start", methods=["POST"])
def labor_start():
    with LOCK:
        GAME.labor_daily_reset(ENGINE.sim_day())
        if GAME.labor["tomato_started"]:
            return api_err("已有搬砖会话进行中")
        if GAME.labor["tomatos"] >= TOMATO_DAILY:
            return api_err(f"今日搬砖已达上限 {TOMATO_DAILY} 个 —— 记住，现实里也没有无限精力")
        sid = uuid.uuid4().hex[:12]
        GAME.labor["tomato_started"] = (sid, time.time())
        return api_ok(sid=sid, minutes=TOMATO_MINUTES, end_ts=time.time() + TOMATO_MINUTES * 60)


@app.route("/api/labor/claim", methods=["POST"])
def labor_claim():
    with LOCK:
        st = GAME.labor["tomato_started"]
        if not st:
            return api_err("没有进行中的搬砖会话")
        sid, started = st
        if sid != request.get_json(force=True).get("sid"):
            return api_err("会话不匹配")
        elapsed = time.time() - started
        if elapsed < TOMATO_MINUTES * 60 - 2:
            left = int(TOMATO_MINUTES * 60 - elapsed)
            return api_err(f"还差 {left // 60} 分 {left % 60} 秒 —— 专注没有捷径，摸鱼不会被支付")
        GAME.labor["tomato_started"] = None
        GAME.labor["tomatos"] += 1
        GAME.labor["earned_total"] += TOMATO_REWARD
        GAME.labor["tomato_log"].append({"t": ENGINE.sim_time_str(), "gain": TOMATO_REWARD})
        EX.balance += TOMATO_REWARD
        push_events([{"type": "labor_paid", "amount": TOMATO_REWARD, "kind": "tomato"}])
        save_state()
        return api_ok(gain=TOMATO_REWARD, tomatos=GAME.labor["tomatos"])


@app.route("/api/labor/math")
def labor_math():
    rng = random.Random(time.time() * 1000)
    qs = []
    for _ in range(5):
        kind = rng.randint(0, 2)
        if kind == 0:
            a, b = rng.randint(12, 99), rng.randint(3, 9)
            qs.append({"q": f"{a} × {b} = ?", "a": a * b})
        elif kind == 1:
            a, b = rng.randint(300, 999), rng.randint(50, 299)
            qs.append({"q": f"{a} − {b} = ?", "a": a - b})
        else:
            pct = rng.choice([10, 15, 20, 25, 40, 60, 75])
            base = rng.randint(2, 40) * 10
            qs.append({"q": f"{base} 的 {pct}% = ?", "a": round(base * pct / 100, 2)})
    sid = uuid.uuid4().hex[:12]
    MATH_QUIZ[sid] = {"answers": [q.pop("a") for q in qs], "ts": time.time()}
    if len(MATH_QUIZ) > 12:
        oldest = min(MATH_QUIZ, key=lambda k: MATH_QUIZ[k]["ts"])
        MATH_QUIZ.pop(oldest)
    return api_ok(sid=sid, questions=qs, reward=MATH_REWARD)


@app.route("/api/labor/math/submit", methods=["POST"])
def labor_math_submit():
    d = request.get_json(force=True)
    with LOCK:
        quiz = MATH_QUIZ.pop(d.get("sid"), None)
        if not quiz:
            return api_err("题目已过期，刷新重试")
        GAME.labor_daily_reset(ENGINE.sim_day())
        if GAME.labor["math_done"] >= MATH_DAILY:
            return api_err(f"今日速算已达上限 {MATH_DAILY} 次")
        correct = 0
        for given, real in zip(d.get("answers", []), quiz["answers"]):
            try:
                if abs(float(given) - real) < 0.01:
                    correct += 1
            except (TypeError, ValueError):
                pass
        if correct == 5:
            gain = MATH_REWARD
        elif correct == 4:
            gain = MATH_REWARD * 0.4
        else:
            return api_ok(correct=correct, gain=0, msg=f"只对 {correct} 题，无工资（现实里算错账是要赔钱的）")
        GAME.labor["math_done"] += 1
        GAME.labor["earned_total"] += gain
        EX.balance += gain
        push_events([{"type": "labor_paid", "amount": gain, "kind": "math"}])
        save_state()
        return api_ok(correct=correct, gain=gain)


# ---------- Web3 ----------
@app.route("/api/wallet")
def api_wallet():
    with LOCK:
        marks = {s: ENGINE.coins[s].display_price(ENGINE.partial()) for s in COINS}
        return api_ok(**CHAIN.snapshot(WID, marks))


@app.route("/api/wallet/create", methods=["POST"])
def wallet_create():
    with LOCK:
        if WID in CHAIN.wallets:
            return api_err("已有钱包 —— 一人一助记词，别贪心")
        w = CHAIN.create_wallet()
        CHAIN.wallets[WID] = w
        tx = CHAIN.submit_tx("mint", "0xGENESIS", w["eth"], 0, note="钱包注册 (无 gas, 教学链)")
        save_state()
        return api_ok(wallet={"eth": w["eth"], "btc": w["btc"], "mnemonic": w["mnemonic"], "tx": tx["hash"]})


@app.route("/api/wallet/withdraw", methods=["POST"])
def wallet_withdraw():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(WID)
        if not w:
            return api_err("请先创建钱包")
        coin = d.get("coin", "USDT")
        amount = float(d.get("amount", 0))
        if amount <= 0:
            return api_err("金额无效")
        if coin == "USDT":
            if EX.balance < amount + GAS_FEE_USD:
                return api_err("交易所 USDT 不足 (含 gas)")
            EX.balance -= (amount + GAS_FEE_USD)
        else:
            sym = coin + "USDT"
            if sym not in COINS:
                return api_err("不支持的币种")
            h = EX.spot_hold.get(sym)
            if not h or h["qty"] < amount:
                return api_err("现货持仓不足 —— 需先在现货页买入")
            EX._spot_sell_market(sym, amount, ENGINE.mark_price(sym))  # 划转 (成本对冲, 不产生盈亏记录)
            EX.spot_history.popleft() if EX.spot_history and EX.spot_history[0].get("pnl", 0) == 0 else None
            if EX.balance >= GAS_FEE_USD:
                EX.balance -= GAS_FEE_USD
        w["balances"][coin] = w["balances"].get(coin, 0) + amount
        tx = CHAIN.submit_tx("transfer", HOT_WALLET, w["eth"], amount, coin=coin, note="交易所提币")
        push_events([{"type": "withdraw_submitted", "coin": coin, "amount": round(amount, 4), "hash": tx["hash"]}])
        save_state()
        return api_ok(hash=tx["hash"], confirmations=CONFIRMATIONS)


@app.route("/api/wallet/deposit", methods=["POST"])
def wallet_deposit():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(WID)
        if not w:
            return api_err("请先创建钱包")
        coin = d.get("coin", "USDT")
        amount = float(d.get("amount", 0))
        if amount <= 0:
            return api_err("金额无效")
        if w["balances"].get(coin, 0) < amount:
            return api_err("钱包余额不足")
        w["balances"][coin] -= amount
        tx = CHAIN.submit_tx("transfer", w["eth"], HOT_WALLET, amount, coin=coin, note="充币到交易所")
        DEPOSIT_PENDING.append({"hash": tx["hash"], "coin": coin, "amount": amount})
        push_events([{"type": "deposit_submitted", "coin": coin, "amount": round(amount, 4),
                      "hash": tx["hash"], "need": CONFIRMATIONS}])
        save_state()
        return api_ok(hash=tx["hash"], confirmations=CONFIRMATIONS)


@app.route("/api/defi/swap", methods=["POST"])
def defi_swap():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(WID)
        if not w:
            return api_err("请先创建钱包")
        pair = d.get("pair", "SOL/USDT")
        if pair not in CHAIN.pools:
            return api_err("池子不存在")
        direction = d.get("direction", "usdt_to_coin")
        amount = float(d.get("amount", 0))
        coin_sym = CHAIN.pools[pair]["coin"].replace("USDT", "")
        if amount <= 0:
            return api_err("金额无效")
        if direction == "usdt_to_coin":
            if w["balances"].get("USDT", 0) < amount:
                return api_err("钱包 USDT 不足")
            out, eff, fee = CHAIN.swap(pair, amount, direction)
            w["balances"]["USDT"] -= amount
            w["balances"][coin_sym] = w["balances"].get(coin_sym, 0) + out
        else:
            if w["balances"].get(coin_sym, 0) < amount:
                return api_err(f"钱包 {coin_sym} 不足")
            out, eff, fee = CHAIN.swap(pair, amount, direction)
            w["balances"][coin_sym] -= amount
            w["balances"]["USDT"] = w["balances"].get("USDT", 0) + out
        tx = CHAIN.submit_tx("swap", w["eth"], f"0xPOOL_{pair.replace('/', '')}", amount,
                             coin="USDT" if direction == "usdt_to_coin" else coin_sym, note=f"DEX swap {pair}")
        save_state()
        return api_ok(out=round(out, 6), eff_price=round(eff, 6), fee=round(fee, 4), hash=tx["hash"])


@app.route("/api/defi/stake", methods=["POST"])
def defi_stake():
    d = request.get_json(force=True)
    with LOCK:
        ok, msg = CHAIN.stake(WID, float(d.get("amount", 0)))
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/defi/unstake", methods=["POST"])
def defi_unstake():
    d = request.get_json(force=True)
    with LOCK:
        amt = d.get("amount")
        ok, msg = CHAIN.unstake(WID, float(amt) if amt else None)
        if ok:
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/wallet/mint_nft", methods=["POST"])
def wallet_mint_nft():
    with LOCK:
        w = CHAIN.wallets.get(WID)
        if not w:
            return api_err("请先创建钱包")
        if EX.balance < 20:
            return api_err("Mint 需要 20 USDT gas")
        n = len(w["nfts"])
        names = ["💀 爆仓纪念 · 第一滴血", "🪦 爆仓纪念 · 百倍刺客", "🔥 爆仓纪念 · 杠杆的墓碑"]
        w["nfts"].append({"name": names[min(n, 2)], "id": f"LIQ#{1000 + n}",
                          "t": ENGINE.sim_time_str(), "gas": 20})
        EX.balance -= 20
        tx = CHAIN.submit_tx("mint", w["eth"], "0xNFT_MARKET", 0, note="Mint 爆仓纪念 NFT")
        push_events([{"type": "nft_minted", "name": w["nfts"][-1]["name"], "hash": tx["hash"]}])
        save_state()
        return api_ok(hash=tx["hash"])


# ---------- 社交 / AI ----------
@app.route("/api/social")
def api_social():
    with LOCK:
        return api_ok(**SOCIAL.snapshot())


@app.route("/api/leaderboard")
def api_leaderboard():
    with LOCK:
        marks = {s: ENGINE.coins[s].display_price(ENGINE.partial()) for s in COINS}
        eq = EX.equity(marks)
        return api_ok(rows=SOCIAL.leaderboard(eq))


@app.route("/api/follow", methods=["POST"])
def api_follow():
    d = request.get_json(force=True)
    with LOCK:
        sig = SOCIAL.follow_signal(int(d.get("sig_id", 0)))
        if not sig:
            return api_err("信号已结束")
        cold = _check_cold()
        if cold:
            return api_err(cold)
        margin = min(float(d.get("margin", sig["margin"])), EX.balance * 0.5)
        evs = []
        ok, msg, evs = EX.place(sig["coin"], sig["side"], "market", round(margin, 2),
                                sig["lev"], None, ENGINE.mark_price(sig["coin"]),
                                ENGINE.coins[sig["coin"]].meta["depth_usd"])
        if ok:
            process_game_hooks(evs)
            push_events(evs)
            save_state()
            return api_ok()
        return api_err(msg)


@app.route("/api/lab")
def api_lab():
    with LOCK:
        return api_ok(**AILAB.snapshot())


@app.route("/api/share_data")
def api_share():
    with LOCK:
        marks = {s: ENGINE.coins[s].display_price(ENGINE.partial()) for s in COINS}
        eq = EX.equity(marks)
        g = GAME.snapshot(eq)
        rows = SOCIAL.leaderboard(eq)
        return api_ok(roi=g["roi"], equity=round(eq, 2), win_rate=g["win_rate"], trades=g["trades"],
                      level=g["level"], title=g["title"], best_streak=g["best_streak"],
                      rank=next(r["rank"] for r in rows if r["is_player"]),
                      total=len(rows), regime=ENGINE.regime_name, sim_str=ENGINE.sim_time_str(),
                      unlocked=sum(1 for a in g["achievements"] if a["unlocked"]), total_ach=len(g["achievements"]))



# ============================================================
#                  开放平台 (正式版 v1)
#     跨游戏资产桥接 · 开发者 API · 空投工具 · Web3 沙盒
# ============================================================

def _cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-DEV-KEY, X-TIMESTAMP, X-SIGNATURE"
    resp.headers["Access-Control-Max-Age"] = "600"
    return resp


def _v1_err(code, msg, http=400):
    resp = jsonify({"code": code, "msg": msg})
    resp.status_code = http
    return _cors(resp)


@app.route("/api/v1/<path:sub>", methods=["GET", "POST", "OPTIONS"])
def open_api(sub):
    """对外开放 API: 外部游戏接入 (充值/提现/空投/转账/查询)"""
    if request.method == "OPTIONS":
        return _cors(app.make_default_options_response())
    body_str = request.get_data(cache=True, as_text=True) or ""
    try:
        if sub == "ping":
            return _cors(jsonify({"code": 0, "msg": "pong", "server_time": int(time.time() * 1000),
                                  "sim_time": ENGINE.sim_time_str()}))
        if sub == "time":
            return _cors(jsonify({"code": 0, "serverTime": int(time.time() * 1000)}))
        if sub == "meta":
            return _cors(jsonify({"code": 0, "data": DEVP.api_meta()}))

        api_key = request.headers.get("X-DEV-KEY", "")
        ts = request.headers.get("X-TIMESTAMP", "")
        sig = request.headers.get("X-SIGNATURE", "")
        sign_src = request.query_string.decode() if request.method == "GET" else body_str  # GET 签 query string
        try:
            app = DEVP.verify_auth(request.method, "/api/v1/" + sub, ts, sig, sign_src, api_key)
        except ApiError as e:
            return _v1_err(e.code, e.msg, e.http)

        try:
            d = json.loads(body_str) if body_str else {}
        except json.JSONDecodeError:
            return _v1_err(-1100, "请求体不是合法 JSON", 400)
        if request.method == "GET":
            d = request.args.to_dict()

        if sub == "app/info":
            pair = DEVP._pair(app["symbol"])
            pool = CHAIN.pools.get(pair, {})
            return _cors(jsonify({"code": 0, "data": {
                "app_id": app["app_id"], "name": app["name"], "symbol": app["symbol"],
                "full": app["full"], "status": app["status"],
                "minted": app["minted"], "burned": app["burned"], "airdropped": app["airdropped"],
                "holders": len(app["holders"]),
                "dex_price": round(pool.get("y", 0) / pool.get("x", 1), 8) if pool else 0,
                "pool_usdt": round(pool.get("y", 0), 2) if pool else 0}}))
        if sub == "app/deposit":
            res = DEVP.deposit(app, d.get("user_address"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "充值已上链 (待确认)", "data": res}))
        if sub == "app/withdraw":
            res = DEVP.withdraw(app, d.get("user_address"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "提现已销毁上链, 请在游戏侧为玩家入账", "data": res}))
        if sub == "app/airdrop":
            res = DEVP.airdrop(app, d.get("to"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "空投完成", "data": res}))
        if sub == "app/transfer":
            res = DEVP.transfer(app, d.get("from"), d.get("to"), d.get("amount"))
            return _cors(jsonify({"code": 0, "msg": "转账已上链", "data": res}))
        if sub == "app/balance":
            return _cors(jsonify({"code": 0, "data": DEVP.balance(app, d.get("user_address"))}))
        return _v1_err(-1101, f"未知端点 /api/v1/{sub}", 404)
    except ApiError as e:
        return _v1_err(e.code, e.msg, e.http)
    except Exception as e:
        return _v1_err(-1000, f"内部错误: {e}", 500)


# ---------------- 开发者控制台 (游戏内页面, 平台本人即开发者后台) ----------------

@app.route("/api/dev/overview")
def dev_overview():
    with LOCK:
        return jsonify({"ok": True, "data": DEVP.overview(),
                        "meta": DEVP.api_meta(),
                        "wallet_addr": CHAIN.wallets[WID]["eth"] if WID in CHAIN.wallets else None,
                        "recent_txs": [t for t in CHAIN.explorer_recent(40)
                                       if str(t.get("coin", "")).endswith(tuple(a["symbol"] for a in DEVP.apps.values())) or
                                       t.get("type") in ("bridge_mint", "bridge_burn", "airdrop")][:14]})


@app.route("/api/dev/register", methods=["POST"])
def dev_register():
    d = request.get_json(force=True)
    with LOCK:
        try:
            app = DEVP.register(d.get("name"), d.get("symbol"), d.get("full"), d.get("seed_price", 0.1))
        except ApiError as e:
            return api_err(e.msg)
        save_state()
        return api_ok(msg=f"应用已创建: {app['name']} ({app['symbol']})", data=DEVP.overview()[0])


@app.route("/api/dev/rotate", methods=["POST"])
def dev_rotate():
    d = request.get_json(force=True)
    with LOCK:
        try:
            DEVP.rotate_secret(d.get("app_id"))
        except ApiError as e:
            return api_err(e.msg)
        return api_ok(msg="密钥已轮换, 旧密钥立即失效")


@app.route("/api/dev/airdrop", methods=["POST"])
def dev_airdrop():
    d = request.get_json(force=True)
    with LOCK:
        app = DEVP.apps.get(d.get("app_id"))
        if not app:
            return api_err("应用不存在")
        try:
            res = DEVP.airdrop(app, d.get("to"), d.get("amount"))
        except ApiError as e:
            return api_err(e.msg)
        save_state()
        return api_ok(msg=f"空投成功 {res['airdropped']} 个地址", data=res)


# ---------------- 钱包增强: 消息签名 / 私钥导出 ----------------

@app.route("/api/wallet/sign", methods=["POST"])
def wallet_sign():
    d = request.get_json(force=True)
    with LOCK:
        w = CHAIN.wallets.get(WID)
        if not w:
            return api_err("请先创建钱包")
        msg = str(d.get("message", ""))[:500]
        if not msg:
            return api_err("消息不能为空")
        priv_hex = wallet_from_mnemonic(w["mnemonic"])["priv_hex"]
        sig = ecdsa_sign(priv_hex, msg)
        pub = privkey_to_pubkey(bytes.fromhex(priv_hex)).hex()
        return api_ok(message=msg, signature=sig, pubkey=pub,
                      address=w["eth"], verified=ecdsa_verify(pub, msg, sig))


@app.route("/api/wallet/export", methods=["GET"])
def wallet_export():
    with LOCK:
        w = CHAIN.wallets.get(WID)
        if not w:
            return api_err("请先创建钱包")
        priv_hex = wallet_from_mnemonic(w["mnemonic"])["priv_hex"]
        return api_ok(address=w["eth"], private_key=priv_hex,
                      mnemonic=w["mnemonic"],
                      warning="⚠️ 私钥即资产。任何拿到它的人都能转走全部资产 — 绝不透露给他人 (现实亦然)")


if __name__ == "__main__":
    loaded = load_state()
    print(f"[CoinSprint] 引擎就绪 ({time.time()-_t0:.1f}s), 存档: {'已恢复' if loaded else '新游戏'}")
    threading.Thread(target=clock_loop, daemon=True).start()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)
