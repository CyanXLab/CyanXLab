# CyanXPan Open API v1 — 外部游戏接入文档

任何外部游戏/应用都可以把它的游戏币接入本平台: 玩家在游戏内把游戏币**充值**进平台 Web3 钱包 →
DEX 换成 USDT → 交易所合约/现货交易 → 提币回钱包 → 换回游戏币 → 游戏侧**提现**入账。
同时提供空投 / 转账 / 查询能力, 可作为 Web3 应用的完整测试沙盒 (无需任何真实链)。

## 1. 接入三步

1. 打开平台「🛠️ 开发者」页 → 注册应用 (名称 + 代币符号 2-8 位)
2. 获得 `api_key` (dk_开头) 与 `api_secret` (ds_开头) —— 代币自动上线 DEX, 平台提供初始流动性
3. 服务端按下述协议调用 API

> 代币符号全局唯一; 注册表独立持久化, 平台游戏重置 (reset) 不影响已注册应用与密钥。

## 2. 鉴权 (对齐主流交易所惯例)

每个请求携带三个请求头:

| 头 | 说明 |
|----|------|
| X-DEV-KEY | 应用 API Key |
| X-TIMESTAMP | 毫秒或秒级 Unix 时间戳, 窗口 ±120s |
| X-SIGNATURE | `HMAC_SHA256(api_secret, 签名字符串)` 的 hex |

签名字符串 (换行分隔):

```
{METHOD}\n{PATH}\n{TIMESTAMP}\n{BODY}
```

- `PATH` 为含 `/api/v1` 前缀的完整路径
- POST 的 `BODY` 为**原始请求体字符串** (建议紧凑 JSON, 与签名一致)
- GET 的 `BODY` 为**完整 query string** (如 `user_address=0xabc`)

错误码风格对齐交易所: `-1021` 时间戳越窗 / `-1022` 签名不匹配 / `-1100` 参数非法 /
`-1101` 地址不存在 / `-2015` 无效密钥 / `-2019` 余额不足 / `-2112` 限流 (120 req/min)。

## 3. 端点

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/v1/ping` | 连通性 |
| GET | `/api/v1/time` | 服务器时间 |
| GET | `/api/v1/meta` | 协议自描述 |
| GET | `/api/v1/app/info` | 应用信息 + DEX 价格 |
| POST | `/api/v1/app/deposit` | 游戏币 → 平台钱包 (桥接铸造, 真实上链) |
| POST | `/api/v1/app/withdraw` | 平台钱包 → 游戏币 (烧毁, 游戏侧入账) |
| POST | `/api/v1/app/airdrop` | 批量空投 (≤500 地址/批) |
| POST | `/api/v1/app/transfer` | 链上转账 |
| GET | `/api/v1/app/balance` | 查询余额 + DEX 估值 + 平台币持仓 |

### 请求/响应示例

**充值** `POST /api/v1/app/deposit`

```json
{"user_address": "0x玩家平台地址", "amount": 1000}
```

```json
{"code": 0, "msg": "充值已上链 (待确认)",
 "data": {"tx_hash": "0x2be6...", "symbol": "FARM", "amount": 1000,
          "credited": true, "confirmations_needed": 2}}
```

**提现** `POST /api/v1/app/withdraw` —— 返回 `{"data": {"burned": true, ...}}`;
游戏服务端收到 200 后应在游戏内为玩家入账相同数量。

**查询** `GET /api/v1/app/balance?user_address=0x...`

```json
{"code": 0, "data": {"address": "0x..", "symbol": "FARM", "balance": 550.0,
                     "usd_value": 55.0, "dex_price": 0.1,
                     "platform_coins": {"USDT": 12.5, "FARM": 550.0}}}
```

## 4. Python 接入示例

```python
import hmac, hashlib, time, json, requests

KEY, SECRET, HOST = "dk_xxx", "ds_xxx", "http://<host>:5000"

def call(method, path, body=None):
    ts = str(int(time.time()))
    if method == "GET":
        qs = "&".join(f"{k}={v}" for k, v in (body or {}).items())
        sign_src = qs
        url, payload = f"{HOST}{path}?{qs}", None
    else:
        sign_src = json.dumps(body, separators=(",", ":"))
        url, payload = f"{HOST}{path}", sign_src
    sig = hmac.new(SECRET.encode(), f"{method}\n{path}\n{ts}\n{sign_src}".encode(),
                   hashlib.sha256).hexdigest()
    return requests.request(method, url, data=payload, headers={
        "X-DEV-KEY": KEY, "X-TIMESTAMP": ts, "X-SIGNATURE": sig,
        "Content-Type": "application/json"}).json()

# 1) 玩家游戏币充值进平台
print(call("POST", "/api/v1/app/deposit", {"user_address": "0x..", "amount": 1000}))
# 2) 查询 (余额 + DEX 估值)
print(call("GET", "/api/v1/app/balance", {"user_address": "0x.."}))
# 3) 玩家离场: 销毁桥接币, 游戏侧入账
print(call("POST", "/api/v1/app/withdraw", {"user_address": "0x..", "amount": 300}))
```

## 5. 典型闭环 (外部游戏 ⇄ 平台)

```
外部游戏                     平台 (CyanXPan)
   │  POST /app/deposit  ──▶  桥接铸造 FARM → 玩家钱包 (上链)
   │                              │ 玩家: DEX Swap FARM→USDT
   │                              │       USDT 充入交易所 → 合约/现货
   │                              │       提币 USDT 回钱包 → Swap 回 FARM
   │  POST /app/withdraw ◀──  桥接烧毁 FARM (游戏侧为玩家入账)
```

## 6. 安全与限制

- Secret 仅在创建时完整展示于开发者控制台, 可随时「轮换密钥」(旧密钥立即失效)
- 限流 120 req/min/密钥; 超限返回 HTTP 429 / code -2112
- 单笔金额上限 1e12; 空投每批 ≤500 地址
- 平台为教学模拟链: mint/burn 全部真实写入链上交易并出块确认, 但**不涉及任何真实资产**


## 7. 币安兼容公开行情端点 (机器人/工具直接对接)

与 Binance REST 字段格式一致 (无需鉴权), 测试网机器人把 BASE_URL 指过来即可跑:

| 端点 | 说明 |
|------|------|
| GET `/api/v3/ping` / `/api/v3/time` | 连通/时间 |
| GET `/api/v3/exchangeInfo` | 交易规则 (tickSize/lotSize/minNotional/maxLeverage, 对齐币安真实值) |
| GET `/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=300` | K 线 (币安数组格式) |
| GET `/api/v3/ticker/24hr?symbol=` | 24h 行情 |
| GET `/fapi/v1/premiumIndex?symbol=` | 标记价格/资金费率/下次结算时间 |

无效参数返回币安风格错误: `{"code": -1121, "msg": "Invalid symbol."}`

## 8. 平台账号体系

- 首次访问自动创建访客身份 (cookie 会话), 零摩擦开始
- `POST /api/auth/register {username, password, inherit}` 注册 (pbkdf2-hmac-sha256 ×160k), 可选继承访客进度
- `POST /api/auth/login` / `logout` / `GET /api/auth/me`
- 每个账号独立: 交易所账户/持仓/XP成就/每日任务/Web3钱包; 排行榜真实跨用户 + AI 机器人同榜

---

# v1.1 — JSON-RPC 2.0 节点 (以太坊兼容层)

平台内置一条开发链语义的迷你公链 (chainId **1337**, anvil/ganache 式 raw tx 即时出块),
`POST /rpc` 提供 JSON-RPC 2.0 接口, web3.js / ethers.js 把 HttpProvider 指向 `/rpc` 即可直连。
原生币为 USDT (1 USDT = 10^18 wei), 与钱包/赌场/交易所同一账本。

## 方法清单

| 方法 | 参数 | 返回 |
|------|------|------|
| eth_chainId | — | `"0x539"` (1337) |
| net_version | — | `"1337"` |
| web3_clientVersion | — | `"CoinSprintChain/v1.1.0/sim"` |
| eth_blockNumber | — | 最新块高 (hex) |
| eth_gasPrice | — | `0x3b9aca00` (1 gwei) |
| eth_getBalance | address, tag | wei (hex), 钱包 EOA 读 USDT 余额 |
| eth_getTransactionCount | address, tag | nonce (hex) |
| eth_getBlockByNumber | tag, full | 区块对象 (含 keccak 哈希/parentHash) |
| eth_getBlockByHash | hash, full | 同上 |
| eth_getTransactionByHash | hash | 交易对象 |
| eth_getTransactionReceipt | hash | 回执 (status/gasUsed/logs) |
| eth_sendRawTransaction | 签名 tx | tx hash — **EIP-155** legacy 交易 (RLP + secp256k1 公钥恢复) |
| eth_call | txObj, tag | 只读调用 (内置合约见下) |
| eth_estimateGas | txObj | 21000 转账 / 48000 合约 |
| eth_getLogs | {fromBlock,toBlock,address,topics} | 日志数组 |
| eth_mine | — | 立即出块 |

## 内置合约

| 合约 | 地址 (keccak 派生) | 能力 |
|------|--------------------|------|
| CST (ERC-20) | `GET /rpc` → contracts.CST | `name()` `symbol()` `decimals()` `totalSupply()` `balanceOf(address)` `transfer(address,uint256)` (raw tx, 触发 Transfer 事件) |
| Faucet | `GET /rpc` → contracts.Faucet | `faucet()` — 每 1h 每地址领 1000 CST |

签名交易示例 (服务端签名端点 `POST /api/wallet/sign_raw` 可代签):

```
RLP[nonce, gasPrice, gas, to, value, data, chainId=1337, 0, 0]
→ keccak256 → secp256k1 签名 (r,s,recid) → v = 1337*2+35+recid
tx_hash = keccak256(签名后 RLP); 地址 = keccak256(pubkey)[-20:]
```

## v1.1 赌场 API (可证明公平)

| 端点 | 说明 |
|------|------|
| GET /api/games/state | 钱包余额 + 公平种子承诺 + Crash 房间实时状态 |
| POST /api/games/dice | {amount, target 2-98, direction under/over} — 赔率 = 99/胜率 |
| POST /api/games/plinko | {amount, rows 8/12/16, risk low/medium/high} |
| POST /api/games/mines/start·pick·cashout | 5×5 雷区, 倍率 = 0.99·C(25,k)/C(25-m,k) |
| POST /api/games/crash/bet·cashout | 全服同轮, 崩溃点 bustabit 公式预承诺 |
| POST /api/games/fair/rotate | 揭示旧 server_seed (可复算历史) + 新承诺 |
| GET /api/games/fair/verify | 用已揭示种子复算任意一局 (hash 不符拒绝) |
| POST /api/games/bonus/rakeback·daily | 返水 0.05% / 每日红包 (净亏损 1%) |

公平算法: `bytes = HMAC_SHA256(server_seed, "client_seed:nonce")`, 每 4 字节 → float ∈ [0,1)。
