# -*- coding: utf-8 -*-
"""Anvil 真 EVM 集成测试: 启动 -> chainId/块高/余额 -> 转账 -> 合约部署字节码 -> 代理 -> 停止"""
import json
import sys
import urllib.request

BASE = "http://127.0.0.1:5000"
PASS, FAIL = 0, 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("PASS", name)
    else:
        FAIL += 1
        print("FAIL", name, extra)


def http(method, path, body=None):
    req = urllib.request.Request(BASE + path, method=method,
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


def rpc(method, params=None):
    req = urllib.request.Request(BASE + "/anvil-rpc",
                                 data=json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                  "params": params or []}).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def wait_receipt(tx_hash, timeout=10):
    """anvil 是 interval mining (--block-time 1), 轮询等 receipt"""
    import time as _t
    t0 = _t.time()
    while _t.time() - t0 < timeout:
        rc = rpc("eth_getTransactionReceipt", [tx_hash])
        if rc.get("result"):
            return rc["result"]
        _t.sleep(0.5)
    return None


# 1. 状态 (未启动)
r = http("GET", "/api/anvil/status")
check("anvil installed 检测", r["ok"] and r["installed"] is True, str(r)[:100])
check("anvil 初始未运行", r["running"] is False)

# 2. 启动
r = http("POST", "/api/anvil/start", {})
check("anvil 启动", r["ok"], str(r)[:120])

# 3. 基础 RPC
r = rpc("eth_chainId")
check("eth_chainId=31337", int(r["result"], 16) == 31337, str(r))
r = rpc("eth_blockNumber")
check("eth_blockNumber >= 0", int(r["result"], 16) >= 0)
r = rpc("eth_accounts")
accts = r["result"]
check("10 个预置账户", len(accts) == 10, str(len(accts)))
r = rpc("eth_getBalance", [accts[0], "latest"])
check("测试账户 10000 ETH", int(r["result"], 16) == 10**22, str(int(r["result"], 16)))

# 4. 真实转账 (anvil auto-mine)
r0 = int(rpc("eth_getBalance", [accts[1], "latest"])["result"], 16)
tx = {"from": accts[0], "to": accts[1], "value": hex(10**18), "gas": "0x5208"}
r = rpc("eth_sendTransaction", [tx])
check("eth_sendTransaction 出 tx hash", "result" in r and r["result"].startswith("0x"), str(r)[:100])
if "result" in r:
    h = r["result"]
    rc = wait_receipt(h)
    check("转账 receipt status=1", rc and rc["status"] == "0x1", str(rc)[:100])
    r1 = int(rpc("eth_getBalance", [accts[1], "latest"])["result"], 16)
    check("到账 +1 ETH", r1 == r0 + 10**18, f"{r0}->{r1}")

# 5. 真实 EVM 合约: 部署并 eth_call 验证 opcode 执行
#    runtime = 60 2a 60 00 52 60 20 60 00 f3 (10 字节: PUSH1 42, PUSH1 0, MSTORE, PUSH1 32, PUSH1 0, RETURN)
#    init    = PUSH10 <runtime> PUSH1 0 MSTORE PUSH1 10 PUSH1 22 RETURN -> 合约代码 = runtime
#    (PUSHn = 0x5f+n: PUSH10=0x69, PUSH5=0x64 —— 注意不是 0x6a/0x65!)
RUNTIME = "602a60005260206000f3"
INIT = "0x69" + RUNTIME + "600052600a6016f3"
r = rpc("eth_sendTransaction", [{"from": accts[0], "data": INIT, "gas": "0x186a0"}])
check("部署合约 tx", "result" in r, str(r)[:100])
if "result" in r:
    rc = wait_receipt(r["result"])
    addr = (rc or {}).get("contractAddress")
    check("合约地址生成", addr and addr != "0x" + "0" * 40, str(addr))
    r = rpc("eth_call", [{"to": addr, "data": "0x"}, "latest"])
    check("opcode 执行返回 42", r["result"] == "0x" + "2a".rjust(64, "0"), r["result"])

# 6. evm 快照/回滚 (测试链独有能力)
snap = rpc("evm_snapshot")["result"]
rpc("eth_sendTransaction", [{"from": accts[0], "to": accts[1], "value": hex(5 * 10**18), "gas": "0x5208"}])
rpc("evm_revert", [snap])
r1 = int(rpc("eth_getBalance", [accts[1], "latest"])["result"], 16)
check("evm_snapshot/revert 回滚", r1 == r0 + 10**18, str(r1))

# 7. status 反映块高
r = http("GET", "/api/anvil/status")
check("status 块高>0 且 running", r["running"] and (r.get("height") or 0) > 0, str(r)[:120])

# 8. 停止 + 再代理应 503
http("POST", "/api/anvil/stop", {})
check("anvil 停止", http("GET", "/api/anvil/status")["running"] is False)

print(f"\n[Anvil 集成] {PASS} 通过 / {FAIL} 失败")
sys.exit(1 if FAIL else 0)
