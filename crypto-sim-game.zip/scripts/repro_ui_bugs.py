# -*- coding: utf-8 -*-
"""用户反馈 UI 专项实测:
A. 重现截图1 (343px 合约页重叠) / 截图2-3 (1299px 现货页右面板截断)
B. 12 页面 x 3 视口横向溢出检测
C. 元素重叠检测 (bookPanel/tradePanel, spotSide 超视口)
D. 全页面按钮遍历点击 -> JS 错误 + 失败请求收集
"""
import json
import sys
import time

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5000"
OUT = "/home/z/my-project/scripts/shots/bugfix"
import os
os.makedirs(OUT, exist_ok=True)

PASS, FAIL, issues = 0, 0, []


def check(name, cond, extra=""):
    global PASS, FAIL
    tag = "PASS" if cond else "FAIL"
    if cond:
        PASS += 1
    else:
        FAIL += 1
        issues.append(f"{name} :: {extra}")
    print(f"{tag}", name, extra if not cond else "")


PAGES = ["/", "/markets", "/earn", "/wallet", "/explorer", "/games",
         "/games/crash", "/games/dice", "/games/mines", "/games/plinko",
         "/dev", "/account"]

VIEWPORTS = [("343x740", 343, 740), ("1299x800", 1299, 800), ("1920x1000", 1920, 1000)]


def measure(page):
    """横向溢出 + 关键元素越界检测"""
    return page.evaluate("""() => {
        const doc = document.documentElement;
        const out = {hOverflow: doc.scrollWidth - doc.clientWidth, offenders: [], overlaps: []};
        if (out.hOverflow > 2) {
            document.querySelectorAll('body *').forEach(el => {
                const r = el.getBoundingClientRect();
                if (r.width > 20 && (r.right > doc.clientWidth + 2 || r.left < -2)) {
                    const cs = getComputedStyle(el);
                    if (cs.position !== 'fixed' && cs.overflow !== 'hidden')
                        out.offenders.push(el.id || el.className.toString().slice(0, 40) || el.tagName);
                }
            });
            out.offenders = [...new Set(out.offenders)].slice(0, 8);
        }
        // 重叠检测: 交易面板关键元素对
        const pairs = [['#bookPanel', '#tradePanel'], ['#spotChartPanel', '#spotSide']];
        for (const [a, b] of pairs) {
            const ea = document.querySelector(a), eb = document.querySelector(b);
            if (ea && eb) {
                const ra = ea.getBoundingClientRect(), rb = eb.getBoundingClientRect();
                const ov = Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left);
                const ovY = Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top);
                if (ov > 4 && ovY > 30) out.overlaps.push(`${a}~${b} (${ov.toFixed(0)}x${ovY.toFixed(0)}px)`);
            }
        }
        return out;
    }""")


def run():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        all_js_errors = []

        for vp_name, w, h in VIEWPORTS:
            ctx = browser.new_context(viewport={"width": w, "height": h}, locale="zh-CN",
                                      is_mobile=(w < 500), has_touch=(w < 500))
            page = ctx.new_page()
            page.on("pageerror", lambda e: all_js_errors.append(f"[{vp_name}] {e}"))
            page.on("console", lambda m: all_js_errors.append(f"[{vp_name}] console: {m.text}") if m.type == "error" else None)

            # ---- A. 专项重现: 合约页(根路径) + 现货 tab ----
            page.goto(BASE + "/", wait_until="networkidle")
            page.wait_for_timeout(2500)
            m = measure(page)
            check(f"[{vp_name}] 合约页无横向溢出", m["hOverflow"] <= 2, f"+{m['hOverflow']}px {m['offenders']}")
            check(f"[{vp_name}] 合约页盘口/下单不重叠", len(m["overlaps"]) == 0, str(m["overlaps"]))
            if vp_name == "343x740":
                page.screenshot(path=f"{OUT}/repro_contract_343.png", full_page=False)
            if vp_name == "1299x800":
                page.screenshot(path=f"{OUT}/repro_contract_1299.png")

            # 现货 tab (同一页面内切换)
            try:
                page.click('#mainTabs button[data-page="spot"]', timeout=3000)
                page.wait_for_timeout(1500)
                m = measure(page)
                check(f"[{vp_name}] 现货页无横向溢出", m["hOverflow"] <= 2, f"+{m['hOverflow']}px {m['offenders']}")
                check(f"[{vp_name}] 现货图表/面板不重叠", len(m["overlaps"]) == 0, str(m["overlaps"]))
                # spotSide 是否超出视口右缘 (截断)
                cut = page.evaluate("""() => {
                    const el = document.querySelector('#spotSide');
                    if (!el) return 0;
                    return Math.max(0, el.getBoundingClientRect().right - document.documentElement.clientWidth);
                }""")
                check(f"[{vp_name}] 现货下单面板完整可见", cut <= 2, f"右缘超出 {cut:.0f}px")
                if vp_name == "1299x800":
                    page.screenshot(path=f"{OUT}/repro_spot_1299.png")
                if vp_name == "343x740":
                    page.screenshot(path=f"{OUT}/repro_spot_343.png")
            except Exception as e:
                check(f"[{vp_name}] 现货tab切换", False, str(e)[:100])

            # ---- B. 全页面遍历溢出检测 ----
            if vp_name == "1299x800":
                for path in PAGES:
                    try:
                        page.goto(BASE + path, wait_until="networkidle")
                        page.wait_for_timeout(1200)
                        m = measure(page)
                        check(f"[1299] {path} 无溢出", m["hOverflow"] <= 2,
                              f"+{m['hOverflow']}px {m['offenders'][:4]}")
                    except Exception as e:
                        check(f"[1299] {path} 加载", False, str(e)[:80])

            ctx.close()

        # ---- D. 全按钮点击遍历 (1920 桌面) ----
        ctx = browser.new_context(viewport={"width": 1920, "height": 1000}, locale="zh-CN")
        page = ctx.new_page()
        req_fail = []
        page.on("pageerror", lambda e: all_js_errors.append(f"[click] {e}"))
        page.on("response", lambda r: req_fail.append(f"{r.status} {r.url[-60:]}") if r.status >= 500 else None)

        for path in PAGES:
            try:
                page.goto(BASE + path, wait_until="networkidle")
                page.wait_for_timeout(1000)
                btns = page.locator("button:visible, [role=button]:visible, .clickable:visible").all()
                clicked = 0
                for i in range(min(len(btns), 40)):
                    try:
                        el = btns[i]
                        before = page.url
                        el.click(timeout=900, no_wait_after=True)
                        clicked += 1
                        page.wait_for_timeout(120)
                        # 若弹出 modal 则关闭, 避免遮挡后续点击
                        for sel in [".modal-close", ".modal .x", "[data-close]", ".modal-bg"]:
                            if page.locator(sel).first.is_visible():
                                try:
                                    page.locator(sel).first.click(timeout=400, no_wait_after=True)
                                except Exception:
                                    pass
                                break
                        page.keyboard.press("Escape")
                    except Exception:
                        pass
                check(f"[click] {path} 可点按钮 {clicked} 个", clicked > 0)
            except Exception as e:
                check(f"[click] {path} 加载", False, str(e)[:80])

        check("JS 零错误 (全程)", len(all_js_errors) == 0, " | ".join(all_js_errors[:5]))
        check("无 5xx 响应", len(req_fail) == 0, " | ".join(req_fail[:5]))

        browser.close()

    print(f"\n[UI 专项] {PASS} 通过 / {FAIL} 失败")
    if issues:
        print("---- 问题清单 ----")
        for x in issues:
            print(" *", x)
    return 1 if FAIL else 0


sys.exit(run())
