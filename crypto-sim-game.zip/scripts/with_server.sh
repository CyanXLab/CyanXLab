#!/bin/bash
# 在同一次调用内: 确保服务器在线 -> 执行命令 (沙箱会在调用结束后回收后台进程,
# 因此凡是需要服务器的脚本都必须经此包装运行)
cd /home/z/my-project/crypto-sim-game
if ! curl -s -m 2 http://127.0.0.1:5000/api/v3/ping >/dev/null 2>&1; then
  pkill -f "python app.py" 2>/dev/null
  sleep 1
  /home/z/.venv/bin/python app.py > /tmp/cs.log 2>&1 &
  for i in $(seq 1 30); do
    curl -s -m 2 http://127.0.0.1:5000/api/v3/ping >/dev/null 2>&1 && break
    sleep 1
  done
fi
"$@"
