# -*- coding: utf-8 -*-
"""复现: 1) 价格跳空穿越强平价后手动平仓→余额为负  2) 触发单免手续费(白嫖)  3) 资金费把保证金扣成负数"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.exchange import Exchange

print("=" * 60)
print("BUG 1: 跳空穿越强平价 → 手动平仓 → 余额为负")
ex = Exchange()
ex.balance = 10000.0
ok, msg, ev = ex.place("BTCUSDT", 1, "market", 100.0, 125, None, 80000.0, 5_000_000)
print(f"  开多 BTC 125x 保证金100 @80000 -> ok={ok} 余额={ex.balance:.2f}")
p = list(ex.positions.values())[0]
print(f"  强平价={p['liq']:.1f}  数量={p['qty']}")
# 同一分钟内价格崩到 70000 (跳空穿越强平价), 用户手动平仓
ok, msg = ex.close_position(p["id"], 1.0, 70000.0, [])
print(f"  手动平仓@70000 -> 余额={ex.balance:.2f}  {'❌ 负余额!' if ex.balance < 0 else 'OK'}")

print("=" * 60)
print("BUG 2: 计划委托(触发单)成交时手续费从未扣款 (白嫖手续费)")
ex2 = Exchange()
ex2.balance = 10000.0
ok, msg = ex2.place_trigger("BTCUSDT", 1, 100.0, 125, 81000.0, 80000.0, 5_000_000)
print(f"  挂触发单 保证金100 lev125 -> 余额={ex2.balance:.2f} (锁定100)")
fee_expected = 100 * 125 * 0.0005
ex2.on_minute({"BTCUSDT": (81000.0, 81000.0, 80950.0)}, 0, [])
print(f"  触发成交后 余额={ex2.balance:.2f}  应为 {10000-100-fee_expected:.2f}")
if ex2.positions:
    print(f"  仓位fee_paid={list(ex2.positions.values())[0]['fee_paid']:.2f} 但余额没扣 -> {'❌ 白嫖' if ex2.balance > 10000-100-fee_expected+0.01 else 'OK'}")
else:
    print(f"  仓位被同K线强平(l<强平价) -> {'❌ 白嫖(保证金全额退还了?)' if ex2.balance >= 9900 else '实际亏损=' + str(round(10000-ex2.balance,2))}")

print("=" * 60)
print("BUG 3: 资金费可把保证金扣成负数才强平 (记录亏损为正)")
ex3 = Exchange()
ex3.balance = 10000.0
ex3.place("DOGEUSDT", 1, "market", 5.0, 75, None, 0.1, 100000)
p = list(ex3.positions.values())[0]
p["margin"] = 0.6  # 模拟已被资金费磨到只剩 0.6
ex3.funding_rate = 0.0075
ex3._fund_bucket = -1  # 强制结算
evs = []
ex3.on_minute({"DOGEUSDT": (0.1, 0.1, 0.1)}, 0, evs)
print(f"  结算后仓位剩余={[p['margin'] for p in ex3.positions.values()]} events={[(e['type'], e.get('loss')) for e in evs if e['type']=='liq']}")
for e in ex3.history:
    print(f"  战绩记录 pnl={e['pnl']} (负保证金强平显示成正收益? {'❌' if e['pnl'] > 0 else 'OK'})")

print("=" * 60)
print("BUG 4: 现货限价买单成交用 maker 费, 但 place 时锁定检查用 0.1% — 语义混乱 (轻微)")
print("检查 place_spot 限价买入: balance < usdt_amt * 1.001 锁定 usdt_amt, 成交时按 0.05% — OK 无负数")
