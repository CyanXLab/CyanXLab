# -*- coding: utf-8 -*-
"""v1.1 新功能 E2E: 跨账号转账 + 用户级开放 API (/open/v1) 全链路."""
import hashlib, hmac, json, os, sys, time, requests

BASE = os.environ.get("CS_BASE", "http://127.0.0.1:5000")
S1 = requests.Session()   # 账号 A (首个访客 → 接管 main)
S2 = requests.Session()   # 账号 B (独立游客)
PASS = FAIL = 0
def check(name, cond, extra=""):
    global PASS, FAIL
    if cond: PASS += 1; print(f"  ✅ {name}")
    else: FAIL += 1; print(f"  ❌ {name} {extra}")

def sign(secret, method, path, ts, body):
    return hmac.new(secret.encode(), f"{method}\n{path}\n{ts}\n{body}".encode(), hashlib.sha256).hexdigest()

def ocall(key, secret, method, path, body=None):
    ts = str(int(time.time() * 1000))
    payload = "" if body is None else json.dumps(body, separators=(",", ":"))
    sig = sign(secret, method, path, ts, payload)
    h = {"X-API-KEY": key, "X-TIMESTAMP": ts, "X-SIGNATURE": sig}
    if payload: h["Content-Type"] = "application/json"
    return requests.request(method, BASE + path, data=payload.encode() if payload else None, headers=h, timeout=10).json()

print("=== 1. 公开端点 ===")
r = requests.get(BASE + "/open/v1/ping", timeout=10).json()
check("ping", r["code"] == 0 and r["data"]["pong"] is True)
r = requests.get(BASE + "/open/v1/meta", timeout=10).json()
check("meta 自描述 ≥18 端点", r["code"] == 0 and len(r["data"]["endpoints"]) >= 18)
r = requests.get(BASE + "/open/v1/exchangeInfo", timeout=10).json()
check("exchangeInfo 含 BTCUSDT 规则", any(s["symbol"] == "BTCUSDT" for s in r["data"]["symbols"]))
r = requests.get(BASE + "/open/v1/ticker?coin=BTCUSDT", timeout=10).json()
check("ticker 最新价", r["code"] == 0 and r["data"]["price"] > 0)
r = requests.get(BASE + "/open/v1/klines?coin=BTCUSDT&interval=1m&limit=5", timeout=10).json()
check("klines 返回 K 线", r["code"] == 0 and len(r["data"]["klines"]) == 5)
r = requests.get(BASE + "/open/v1/depth?coin=ETHUSDT", timeout=10).json()
check("depth 盘口", r["code"] == 0 and len(r["data"]["bids"]) > 0)
r = requests.get(BASE + "/open/v1/leaderboard", timeout=10).json()
check("leaderboard 全服榜", r["code"] == 0 and isinstance(r["data"]["leaderboard"], list))

print("=== 2. 鉴权与错误码 (币安风格) ===")
r = requests.get(BASE + "/open/v1/account", timeout=10).json()
check("无签名 → -2015", r["code"] == -2015, str(r))
r = requests.get(BASE + "/open/v1/account", headers={"X-API-KEY": "uk_bad", "X-TIMESTAMP": str(int(time.time()*1000)), "X-SIGNATURE": "0"*64}, timeout=10).json()
check("假 Key → -2015", r["code"] == -2015)
r = requests.get(BASE + "/open/v1/account", headers={"X-API-KEY": "uk_bad", "X-TIMESTAMP": "abc", "X-SIGNATURE": "0"*64}, timeout=10).json()
check("坏时间戳 → -1100/-2015", r["code"] in (-1100, -2015))
r = requests.get(BASE + "/open/v1/unknown_xx", timeout=10).json()
check("未知端点 → -1101 (公开池不拦未知)", r["code"] in (-1101, -2015))

print("=== 3. 双账号会话准备 ===")
r1 = S1.get(BASE + "/api/auth/me", timeout=10).json()
nameA = "apitest_a"
r = S1.post(BASE + "/api/auth/register", json={"username": nameA, "password": "secret123", "inherit": True}, timeout=10).json()
check("A 注册", r.get("ok"), str(r))
r2 = S2.get(BASE + "/api/auth/me", timeout=10).json()
nameB = "apitest_b"
r = S2.post(BASE + "/api/auth/register", json={"username": nameB, "password": "secret123", "inherit": True}, timeout=10).json()
check("B 注册", r.get("ok"), str(r))
S1.get(BASE + "/api/state", timeout=10)
S2.get(BASE + "/api/state", timeout=10)

print("=== 4. API Key 管理 ===")
r = S1.get(BASE + "/api/account/apikeys", timeout=10).json()
check("Key 列表", r.get("ok"))
r = S1.post(BASE + "/api/account/apikeys/create", json={"label": "e2e"}, timeout=10).json()
check("创建 Key", r.get("ok"), str(r))
KEY_A, SECRET_A = r["key"]["api_key"], r["key"]["api_secret"]
r = S1.post(BASE + "/api/account/apikeys/create", json={"label": "e2e"}, timeout=10).json()
check("第 2 把创建成功", r.get("ok"))
r = S1.post(BASE + "/api/account/apikeys/create", json={"label": "e2e"}, timeout=10).json()
check("第 3 把创建成功", r.get("ok"))
r = S1.post(BASE + "/api/account/apikeys/create", json={"label": "e2e"}, timeout=10).json()
check("第 4 把 → 拒绝 (每号限 3 把)", not r.get("ok"), str(r))
# 吊销最新创建的一把回收额度 (list 按 created 倒序, [0] 最新), 保证后续测试可继续创建
keys_now = S1.get(BASE + "/api/account/apikeys", timeout=10).json()["keys"]
S1.post(BASE + "/api/account/apikeys/revoke", json={"api_key": keys_now[0]["api_key"]}, timeout=10)

print("=== 5. 私有端点: 账户/下单/平仓 (A 用 API 替代 UI) ===")
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/account")
check("account 权益>0", r["code"] == 0 and r["data"]["equity"] > 0, str(r))
bal0 = r["data"]["balance"]
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/order", {"coin": "BTCUSDT", "side": "long", "type": "market", "margin": 50, "leverage": 10})
check("API 开仓", r["code"] == 0, str(r))
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/positions")
check("持仓可见", r["code"] == 0 and len(r["data"]["positions"]) == 1)
pid = r["data"]["positions"][0]["id"]
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/order/close", {"position_id": pid, "fraction": 1.0})
check("API 平仓", r["code"] == 0 and r["data"]["closed"], str(r))
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/account")
check("平仓后余额≈期初-手续费", abs(r["data"]["balance"] - (bal0 - 50 * 10 * 0.0005)) < 1.0,
      f"{r['data']['balance']} vs {bal0}")
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/income")
check("income 手续费累计", r["code"] == 0 and r["data"]["fee_paid_total"] > 0)
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/spot/order", {"coin": "ETHUSDT", "side": "buy", "type": "market", "usdt": 30})
check("API 现货买入", r["code"] == 0, str(r))
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/history")
check("history 战绩", r["code"] == 0)
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/orders")
check("orders 空单列表", r["code"] == 0)
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/order", {"coin": "BTCUSDT", "side": "long", "type": "limit", "margin": 20, "leverage": 5, "price": 1})
oc_ok = r["code"] == 0
check("API 限价单挂出 (低价)", oc_ok, str(r))
if oc_ok:
    r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/orders")
    lid = r["data"]["orders"][0]["id"] if r["data"]["orders"] else None
    r = ocall(KEY_A, SECRET_A, "DELETE", "/open/v1/order", {"order_id": lid, "kind": "limit"})
    check("API 撤单", r["code"] == 0, str(r))

print("=== 6. 签名失败场景 ===")
ts = str(int(time.time() * 1000))
r = requests.get(BASE + "/open/v1/account", headers={"X-API-KEY": KEY_A, "X-TIMESTAMP": ts,
    "X-SIGNATURE": sign(SECRET_A, "GET", "/open/v1/account", ts, "") + "0"}, timeout=10).json()
check("坏签名 → -1022", r["code"] == -1022, str(r))
r = requests.get(BASE + "/open/v1/account", headers={"X-API-KEY": KEY_A, "X-TIMESTAMP": str(int(time.time()*1000) - 999999),
    "X-SIGNATURE": sign(SECRET_A, "GET", "/open/v1/account", str(int(time.time()*1000) - 999999), "")}, timeout=10).json()
check("过期时间戳 → -1021", r["code"] == -1021, str(r))

print("=== 7. 跨账号转账 (会话 + API 双路径) ===")
r = S2.get(BASE + "/api/state", timeout=10).json()
balB0 = r["account"]["balance"]
# 7a. A 通过 API 转账给 B
amt = 123.45
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/transfer", {"to_username": nameB, "amount": amt, "note": "e2e"})
check("API 站内转账", r["code"] == 0, str(r))
r2 = S2.get(BASE + "/api/state", timeout=10).json()
check("B 到账 +123.45", abs(r2["account"]["balance"] - (balB0 + amt)) < 0.01,
      f"{r2['account']['balance']} vs {balB0 + amt}")
feed_b = S2.get(BASE + "/api/state", timeout=10).json().get("events", [])
check("B 收到事件流通知", any(e.get("type") == "transfer_in" for e in feed_b))
# 7b. 转给自己 → 拒绝
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/transfer", {"to_username": nameA, "amount": 1})
check("转给自己 → 拒绝", r["code"] != 0)
# 7c. 余额不足 → 拒绝
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/transfer", {"to_username": nameB, "amount": 1e9})
check("余额不足 → -2019", r["code"] == -2019, str(r))
# 7d. 目标不存在
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/transfer", {"to_username": "nobody_x", "amount": 1})
check("目标不存在 → 拒绝", r["code"] != 0)
# 7e. 会话路径: B → A
r = S2.post(BASE + "/api/account/transfer", json={"to_username": nameA, "amount": 20}, timeout=10).json()
check("会话转账 B→A", r.get("ok"), str(r))

print("=== 8. 赌场 API + 钱包 ===")
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/games")
check("games 统计查询", r["code"] == 0, str(r)[:80])
r = ocall(KEY_A, SECRET_A, "GET", "/open/v1/wallet")
check("wallet 查询", r["code"] == 0)
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/games/dice", {"amount": 1, "target": 50, "direction": "under"})
check("API Dice 下注(钱包不足也能正确报错)", r["code"] in (0, -2019), str(r)[:100])
r = ocall(KEY_A, SECRET_A, "POST", "/open/v1/wallet/send", {"to": "0x" + "1"*40, "amount": 1})
check("API 链上转账(无钱包→报错)", r["code"] in (0, -1102, -2019), str(r))

print(f"\n{'='*46}\n结果: {PASS} 通过 / {FAIL} 失败")
sys.exit(1 if FAIL else 0)
