# -*- coding: utf-8 -*-
"""全页面截图 (桌面+移动) 供 VLM 视觉审查."""
import os, time
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5000"
OUT = "/home/z/my-project/crypto-sim-game/shots"
os.makedirs(OUT, exist_ok=True)
PAGES = ["/", "/markets", "/earn", "/wallet", "/explorer", "/games",
         "/games/crash", "/games/dice", "/games/mines", "/games/plinko", "/dev", "/account"]
VIEWPORTS = [("desktop", 1440, 900), ("mobile", 390, 844)]

errors = []
with sync_playwright() as p:
    browser = p.chromium.launch()
    for tag, w, h in VIEWPORTS:
        ctx = browser.new_context(viewport={"width": w, "height": h},
                                  device_scale_factor=1, is_mobile=(tag == "mobile"))
        pg = ctx.new_page()
        pg.on("pageerror", lambda e: errors.append(f"[{tag}] JS错误: {e}"))
        pg.on("console", lambda m: errors.append(f"[{tag}] console.error: {m.text}") if m.type == "error" else None)
        for path in PAGES:
            name = path.replace("/", "_") or "_index"
            try:
                pg.goto(BASE + path, wait_until="networkidle", timeout=20000)
            except Exception:
                pg.wait_for_timeout(2500)
            pg.wait_for_timeout(1400)
            fn = f"{OUT}/{tag}{name}.png"
            pg.screenshot(path=fn, full_page=False)
            print("shot:", fn)
        ctx.close()
    browser.close()

print("\n=== JS/Console 错误 ===")
if errors:
    seen = set()
    for e in errors:
        k = e.split(": ", 1)[-1][:80]
        if k not in seen:
            seen.add(k)
            print(" ", e[:160])
else:
    print("  无")
