# -*- coding: utf-8 -*-
"""调试: 为什么 Playwright 截图全白."""
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    reqs, fails = [], []
    pg.on("requestfailed", lambda r: fails.append(f"{r.url[:90]} -> {r.failure}"))
    pg.on("response", lambda r: reqs.append((r.status, r.url[:90])))
    pg.on("pageerror", lambda e: print("PAGEERROR:", e))
    pg.on("console", lambda m: print("CONSOLE-", m.type, ":", m.text[:120]) if m.type in ("error", "warning") else None)
    r = pg.goto("http://127.0.0.1:5000/markets", wait_until="domcontentloaded", timeout=15000)
    print("主响应:", r.status, r.url)
    pg.wait_for_timeout(2500)
    html = pg.content()
    print("DOM 长度:", len(html))
    print("body 背景:", pg.evaluate("getComputedStyle(document.body).backgroundColor"))
    print("#siteMain 高度:", pg.evaluate("document.getElementById('siteMain')?.offsetHeight"))
    print("#siteNav 高度:", pg.evaluate("document.getElementById('siteNav')?.offsetHeight"))
    print("首个卡片高度:", pg.evaluate("document.querySelector('.pcard')?.offsetHeight"))
    print("\n失败请求:", fails[:8] or "无")
    bad = [x for x in reqs if x[0] >= 400]
    print("4xx/5xx:", bad[:8] or "无")
    pg.screenshot(path="/home/z/my-project/crypto-sim-game/shots/debug_markets.png")
    b.close()
