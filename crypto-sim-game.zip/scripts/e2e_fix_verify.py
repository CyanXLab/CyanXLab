# -*- coding: utf-8 -*-
"""修复验证 E2E:
A. 提币双花封死 (API 层): 买ETH->提币->余额只减gas->循环3轮总资产不增
B. 核心交易按钮 (Playwright): 合约开/平仓, 现货买/卖
C. 四游戏逐局 (Playwright): dice/mines/plinko 交互 + crash 按钮状态
D. 修复后移动端截图
"""
import json
import sys
import time

import requests
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5000"
S = requests.Session()
PASS, FAIL = 0, 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("PASS", name)
    else:
        FAIL += 1
        print("FAIL", name, extra)


def balance():
    return S.get(BASE + "/api/state").json().get("account", {}).get("balance")


def wallet_usdt():
    r = S.get(BASE + "/api/wallet").json()
    d = r.get("data") or r
    try:
        return d["wallet"]["balances"].get("USDT", 0.0)
    except Exception:
        return None


def total_assets():
    """总资产 = 交易所余额 + 现货持仓市值 + 钱包 USDT"""
    st = S.get(BASE + "/api/state").json()
    acct = st.get("account", {})
    ex = acct.get("balance", 0)
    spot_v = acct.get("spot_value", 0)
    w = wallet_usdt() or 0
    return ex + spot_v + w


def part_a():
    print("---- A. 提币双花封死 ----")
    # 确保有钱包
    r = S.get(BASE + "/api/wallet").json()
    d = r.get("data") or r
    if not d.get("wallet"):
        r2 = S.post(BASE + "/api/wallet/create", json={}).json()
        check("创建钱包", r2.get("ok"), str(r2)[:80])
    # 买 1 ETH (市价, 金额足够)
    st = S.get(BASE + "/api/state").json()
    eth_px = st["display"]["ETHUSDT"]
    r = S.post(BASE + "/api/spot", json={"coin": "ETHUSDT", "side": "buy",
                                         "type": "market", "usdt": round(eth_px * 1.2 + 50, 2)}).json()
    check("现货买入 ETH", r.get("ok"), str(r)[:100])
    t0 = total_assets()
    # 提币 1 ETH -> 钱包: 余额应只减 gas, 现货持仓减 1 ETH, 钱包 +1 ETH
    r = S.post(BASE + "/api/wallet/withdraw", json={"coin": "ETH", "amount": 1.0}).json()
    check("提币 1 ETH 成功", r.get("ok"), str(r)[:100])
    if r.get("ok"):
        st = S.get(BASE + "/api/state").json()
        rows = st["account"].get("spot_hold") or []
        eth_row = next((x for x in rows if x.get("coin") == "ETHUSDT"), {})
        check("现货持仓 -1 ETH (余手续费余量)", 0.15 <= eth_row.get("qty", 0) <= 0.25, str(eth_row)[:80])
        w = S.get(BASE + "/api/wallet").json()
        wd = (w.get("data") or w)["wallet"]["balances"]
        check("钱包 +1 ETH", wd.get("ETH", 0) >= 0.999, str(wd)[:60])
    # 双花循环测试: 充回 -> 提出x3, 总资产不应增长 (等待链上确认入账)
    def wait_spot_eth(min_qty, timeout_s=25):
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            rows = (S.get(BASE + "/api/state").json()["account"].get("spot_hold") or [])
            row = next((x for x in rows if x.get("coin") == "ETHUSDT"), {})
            if row.get("qty", 0) >= min_qty:
                return True
            time.sleep(1.2)
        return False

    ok_loop = True
    for i in range(3):
        rw = S.post(BASE + "/api/wallet/deposit", json={"coin": "ETH", "amount": 1.0}).json()
        got = wait_spot_eth(0.999)
        rw2 = S.post(BASE + "/api/wallet/withdraw", json={"coin": "ETH", "amount": 1.0}).json()
        if not (rw.get("ok") and got and rw2.get("ok")):
            ok_loop = False
            check(f"循环#{i} 充/提", False, f"dep={rw.get('ok')} credited={got} wd={rw2.get('msg', rw2.get('ok'))}")
            break
    if ok_loop:
        t1 = total_assets()
        # 交易所余额不应因提币而增加 (只减 gas 1U x 次数)
        check("循环3轮后总资产不增长 (双花封死)", t1 <= t0 + 0.5, f"before={t0:.2f} after={t1:.2f}")
    # 超额提币应被拒
    r = S.post(BASE + "/api/wallet/withdraw", json={"coin": "ETH", "amount": 999}).json()
    check("超额提币被拒", not r.get("ok"), str(r)[:80])


def part_b_browser(js_errors):
    print("---- B/C. 浏览器交易 + 游戏 ----")
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1440, "height": 900}, locale="zh-CN")
        page = ctx.new_page()
        page.on("pageerror", lambda e: js_errors.append(str(e)))
        page.goto(BASE + "/", wait_until="domcontentloaded")
        page.wait_for_timeout(1200)
        # 关闭引导弹窗 (若出现)
        if page.locator("#modalWrap").count():
            page.evaluate("window.closeModal()")
            page.wait_for_timeout(300)
        check("引导弹窗可关闭", page.locator("#modalWrap").count() == 0)

        # B1. 合约开多 -> 持仓 -> 市价平仓
        bal0 = page.evaluate("fetch('/api/state').then(r=>r.json()).then(j=>j.account.balance)")
        page.click('#mainTabs button[data-page="contract"]')
        page.wait_for_timeout(600)
        page.fill("#marginInput", "500")
        page.click("#btnLong")
        page.wait_for_timeout(1500)
        pos = page.evaluate("fetch('/api/state').then(r=>r.json()).then(j=>(j.positions||[]).length)")
        check("合约开多产生持仓", pos >= 1, str(pos))
        pid = page.evaluate("fetch('/api/state').then(r=>r.json()).then(j=>(j.positions||[])[0]?.id)")
        r = page.evaluate("""pid => fetch('/api/close', {method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({position_id: pid, fraction: 1.0})}).then(r=>r.json())""", pid)
        check("合约平仓 API", r.get("ok"), str(r)[:80])
        bal1 = page.evaluate("fetch('/api/state').then(r=>r.json()).then(j=>j.account.balance)")
        pos2 = page.evaluate("fetch('/api/state').then(r=>r.json()).then(j=>(j.positions||[]).length)")
        check("合约平仓完成", pos2 == 0 and bal1 is not None, f"pos={pos2} bal={bal1}")

        # B2. 现货买入 -> 持仓 -> 卖出
        page.click('#mainTabs button[data-page="spot"]')
        page.wait_for_timeout(600)
        page.fill("#spAmount", "300")
        page.click("#spBuy")
        page.wait_for_timeout(1500)
        spot_qty = page.evaluate("fetch('/api/state').then(r=>r.json()).then(j=>{const x=(j.account.spot_hold||[]).find(y=>y.coin==='BTCUSDT');return x?x.qty:0})")
        check("现货买入 BTC", spot_qty > 0, str(spot_qty))
        page.click("#spSell")
        page.wait_for_timeout(1200)
        spot_qty2 = page.evaluate("fetch('/api/state').then(r=>r.json()).then(j=>{const x=(j.account.spot_hold||[]).find(y=>y.coin==='BTCUSDT');return x?x.qty:0})")
        check("现货卖出清仓", spot_qty2 <= 0.00001, str(spot_qty2))

        # C1. Dice 交互 (滚低/滚高切换 + 下注)
        page.goto(BASE + "/games/dice", wait_until="networkidle")
        page.wait_for_timeout(900)
        page.click("#dirOver")
        over_sel = page.evaluate("!document.querySelector('#dirOver').classList.contains('ghost')")
        under_sel = page.evaluate("!document.querySelector('#dirUnder').classList.contains('ghost')")
        check("Dice 方向切换高亮", over_sel and not under_sel)
        bal_w0 = page.evaluate("fetch('/api/games/state').then(r=>r.json()).then(j=>j.balance)")  # noqa
        page.fill("#amount", "5")
        page.click("#betBtn")
        page.wait_for_timeout(1200)
        bal_w1 = page.evaluate("fetch('/api/games/state').then(r=>r.json()).then(j=>j.balance)")
        roll_txt = page.evaluate("document.querySelector('#rollOut').textContent")
        check("Dice 下注出结果", bal_w1 is not None and roll_txt != "--", f"roll={roll_txt} {bal_w0}->{bal_w1}")

        # C2. Mines 完整局: 开始 -> 翻2格 -> 兑现
        page.goto(BASE + "/games/mines", wait_until="networkidle")
        page.wait_for_timeout(900)
        page.fill("#amount", "5")
        page.click("#startBtn")
        page.wait_for_timeout(1100)
        page.locator(".mine-cell").nth(0).click()
        page.wait_for_timeout(900)
        st1 = page.evaluate("fetch('/api/games/state').then(r=>r.json()).then(j=>j.fair.mines_active)")
        if st1:
            page.locator(".mine-cell").nth(7).click()
            page.wait_for_timeout(900)
            st2 = page.evaluate("fetch('/api/games/state').then(r=>r.json()).then(j=>j.fair.mines_active)")
            if st2:  # 没踩雷 -> 兑现
                page.click("#cashBtn")
                page.wait_for_timeout(1000)
                st3 = page.evaluate("fetch('/api/games/state').then(r=>r.json()).then(j=>j.fair.mines_active)")
                check("Mines 开局->翻格->兑现", not st3)
            else:
                check("Mines 开局->翻格->兑现", True, "(第2格踩雷, 路径仍通)")
        else:
            check("Mines 开局->翻格->兑现", False, "开局即失败")

        # C3. Plinko 落球
        page.goto(BASE + "/games/plinko", wait_until="networkidle")
        page.wait_for_timeout(900)
        page.select_option("#risk", "low")
        page.fill("#amount", "5")
        page.click("#betBtn")
        page.wait_for_timeout(2500)
        last = page.evaluate("document.querySelector('#lastOut').textContent")
        check("Plinko 落球出结果", last.startswith("x"), last)

        # C4. Crash 按钮状态一致性 (等 2 轮 poll 稳定后再抓, 且失败重试一次 — phase 切换瞬间是合法竞态)
        page.goto(BASE + "/games/crash", wait_until="networkidle")
        page.wait_for_timeout(1800)
        cstate = None
        for _ in range(3):
            cstate = page.evaluate("""fetch('/api/games/state').then(r=>r.json()).then(j=>{
                const c = j.crash;
                return {phase: c.phase, my: !!c.my, betBtn: !document.querySelector('#betBtn').disabled,
                        cashBtn: !document.querySelector('#cashBtn').disabled};})""")
            ph = cstate["phase"]
            legal = ((ph == "betting" and cstate["betBtn"] == (not cstate["my"]) and not cstate["cashBtn"])
                     or (ph == "running" and not cstate["betBtn"])
                     or (ph == "cooldown" and not cstate["betBtn"] and not cstate["cashBtn"]))
            if legal:
                break
            page.wait_for_timeout(800)  # 等下一轮 poll 应用最新状态
        ph = cstate["phase"]
        legal = ((ph == "betting" and cstate["betBtn"] == (not cstate["my"]) and not cstate["cashBtn"])
                 or (ph == "running" and not cstate["betBtn"])
                 or (ph == "cooldown" and not cstate["betBtn"] and not cstate["cashBtn"]))
        check(f"Crash 按钮状态合法 (phase={ph})", legal, json.dumps(cstate))

        # D. 移动端修复后截图
        mob = b.new_context(viewport={"width": 343, "height": 740}, locale="zh-CN",
                            is_mobile=True, has_touch=True)
        mp = mob.new_page()
        mp.on("pageerror", lambda e: js_errors.append("[m]" + str(e)))
        mp.goto(BASE + "/", wait_until="domcontentloaded")
        mp.wait_for_timeout(2500)
        if mp.locator("#modalWrap").count():
            mp.evaluate("window.closeModal()")
        mp.wait_for_timeout(600)
        mp.screenshot(path="/home/z/my-project/scripts/shots/bugfix/fixed_contract_343.png")
        ov = mp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check("343px 移动端无横向溢出", ov <= 2, f"+{ov}px")
        b.close()


def main():
    r = S.get(BASE + "/api/v3/ping")
    check("服务器在线", r.status_code == 200)
    part_a()
    js_errors = []
    part_b_browser(js_errors)
    check("全程 JS 零错误", len(js_errors) == 0, " | ".join(js_errors[:4]))
    print(f"\n[修复验证] {PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)


main()
