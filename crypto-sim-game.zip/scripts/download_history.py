#!/usr/bin/env python3
"""从 Binance 公开 API 下载主流币种历史小时线数据, 供仿真引擎学习使用.
兜底: 若下载失败, 生成与真实统计特征校准的合成数据 (明确标记 is_synthetic)."""
import json, time, urllib.request, urllib.error, os, sys, random, math

OUT_DIR = "/home/z/my-project/crypto-sim-game/data"
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "BNBUSDT"]
INTERVAL = "1h"
START_MS = 1722470400000  # 2024-08-01 00:00 UTC
HOSTS = [
    "https://data-api.binance.vision",
    "https://api.binance.com",
]

def http_json(url, retries=3):
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            last = e
            time.sleep(1.2 * (i + 1))
    raise last

def fetch_klines(symbol):
    """分页拉取 START_MS -> now 的全部 1h K线."""
    rows, end_ms = [], int(time.time() * 1000)
    cur = START_MS
    host_idx = 0
    while cur < end_ms:
        url = f"{HOSTS[host_idx]}/api/v3/klines?symbol={symbol}&interval={INTERVAL}&startTime={cur}&limit=1000"
        try:
            batch = http_json(url)
        except Exception:
            host_idx = (host_idx + 1) % len(HOSTS)
            batch = http_json(url)
        if not batch:
            break
        for k in batch:
            # [openTime, open, high, low, close, volume, closeTime, ...]
            rows.append([int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5])])
        cur = batch[-1][0] + 3600_000
        if len(batch) < 1000:
            break
        time.sleep(0.25)
    return rows

def synth(symbol):
    """兜底: 基于真实宏观特征的市态切换 GARCH 合成小时线 (仅下载失败时使用)."""
    cfg = {
        "BTCUSDT":  (58000, 0.55), "ETHUSDT": (2600, 0.70), "SOLUSDT": (150, 0.95),
        "DOGEUSDT": (0.11, 1.10), "BNBUSDT": (520, 0.50),
    }[symbol]
    p0, ann_vol = cfg
    rng = random.Random(hash(symbol) & 0xFFFF)
    n = 17400  # ~2 years of hours
    # 市态: 0=牛 1=熊 2=震荡, 转移概率(每小时), 年化漂移
    trans = [[0.9985, 0.0008, 0.0007], [0.0006, 0.9986, 0.0008], [0.0009, 0.0007, 0.9984]]
    drift_h = [0.00035, -0.00030, 0.00002]
    vol_scale = [0.85, 1.35, 0.75]
    regime = 2
    var = (ann_vol / math.sqrt(365 * 24)) ** 2
    price, rows, ts = p0, [], START_MS
    beta = rng.gauss(0, 1)
    for i in range(n):
        if rng.random() < 0.004:  # 市态跳转
            regime = [j for j in range(3) if j != regime][0] if rng.random() < 0.5 else regime
        r = drift_h[regime] + math.sqrt(var) * vol_scale[regime] * rng.gauss(0, 1)
        if rng.random() < 0.0009:  # 跳变事件
            r += rng.choice([-1, 1]) * abs(rng.gauss(0, 1)) * math.sqrt(var) * 9
        ret = math.exp(r)
        o = price; c = price * ret
        h = max(o, c) * (1 + abs(rng.gauss(0, 1)) * math.sqrt(var) * 0.5)
        l = min(o, c) * (1 - abs(rng.gauss(0, 1)) * math.sqrt(var) * 0.5)
        v = abs(rng.gauss(1, 0.4)) * (1.5 + 40 / (p0 / c if c > 0 else 1)) * (1000 if "USDT" in symbol else 1)
        rows.append([ts, round(o, 6), round(h, 6), round(l, 6), round(c, 6), round(v, 2)])
        price = c; ts += 3600_000
    return rows

def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    summary = {}
    for sym in COINS:
        try:
            rows = fetch_klines(sym)
            src = "binance_real"
            if len(rows) < 3000:
                raise RuntimeError(f"rows too few: {len(rows)}")
        except Exception as e:
            print(f"[WARN] {sym} 下载失败({e}), 使用校准合成数据兜底")
            rows = synth(sym)
            src = "synthetic_fallback"
        # 精简存储: 保留最近 16000 根
        rows = rows[-16000:]
        payload = {"symbol": sym, "interval": INTERVAL, "source": src, "candles": rows}
        with open(os.path.join(OUT_DIR, f"{sym}_1h.json"), "w") as f:
            json.dump(payload, f, separators=(",", ":"))
        summary[sym] = {"source": src, "candles": len(rows),
                        "first": rows[0][0], "last_close": rows[-1][4]}
        print(f"[OK] {sym}: {len(rows)} candles, source={src}, last_close={rows[-1][4]}")
    with open(os.path.join(OUT_DIR, "_meta.json"), "w") as f:
        json.dump(summary, f, indent=1)

if __name__ == "__main__":
    main()
