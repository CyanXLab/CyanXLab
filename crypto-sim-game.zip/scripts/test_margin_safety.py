# -*- coding: utf-8 -*-
"""保证金安全性模糊测试: 随机市场 + 随机交易 + 极端跳空, 断言余额/权益永不透支."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.exchange import Exchange
from engine.history_data import COINS

random.seed(20260829)
VIOLATIONS = []
liq_count = 0
close_count = 0
bankrupt_clamps = 0

for trial in range(300):
    ex = Exchange()
    ex.balance = random.choice([30.0, 55.0, 120.0, 800.0, 5000.0])   # 小资金高危账户
    start = ex.balance
    px = {c: random.choice([0.05, 0.1, 1.0, 100.0, 30000.0, 80000.0]) for c in COINS}
    for step in range(120):
        # ---- 随机跳空 (±12% 极端行情) ----
        candles = {}
        for c in COINS:
            px[c] *= random.uniform(0.88, 1.12)
            candles[c] = (px[c], px[c] * 1.01, px[c] * 0.99)
        ex.on_minute(candles, random.choice([0, 1, 2]), [], sim_ts=step * 60 + 1e6)
        # ---- 随机开仓 ----
        if random.random() < 0.5:
            c = random.choice(COINS)
            m = COIN_MARGIN = random.choice([5, 8, 20, 100])
            lev = random.choice([1, 5, 25, 75, 125, 150])
            try:
                ok, msg, ev = ex.place(c, random.choice([1, -1]), random.choice(["market", "limit"]),
                                       m, lev, px[c] * random.uniform(0.97, 1.03), px[c], 5_000_000,
                                       tp_pct=random.choice([None, 5, 50]), sl_pct=random.choice([None, 3, 20]))
            except Exception as e:
                VIOLATIONS.append(f"trial{trial} step{step} place异常: {e}")
        # ---- 随机平仓 / 触发单 / 现货 ----
        if ex.positions and random.random() < 0.4:
            pid = random.choice(list(ex.positions.keys()))
            try:
                ex.close_position(pid, random.choice([0.5, 1.0]), px[ex.positions[pid]["coin"]] * random.uniform(0.85, 1.15), [])
                close_count += 1
            except Exception as e:
                VIOLATIONS.append(f"trial{trial} step{step} close异常: {e}")
        if random.random() < 0.2:
            c = random.choice(COINS)
            try:
                ex.place_trigger(c, random.choice([1, -1]), 10, random.choice([5, 50, 125]),
                                 px[c] * random.uniform(0.9, 1.1), px[c], 5_000_000)
            except Exception as e:
                VIOLATIONS.append(f"trial{trial} step{step} trigger异常: {e}")
        if random.random() < 0.15:
            c = random.choice(COINS)
            try:
                ex.place_spot(c, random.choice([1, -1]), "market", random.choice([5, 50, 500]), None, px[c])
            except Exception as e:
                VIOLATIONS.append(f"trial{trial} step{step} spot异常: {e}")
        # ---- 断言: 余额永不透支 ----
        if ex.balance < -1e-6:
            VIOLATIONS.append(f"trial{trial} step{step} 余额透支 {ex.balance:.4f}")
            break
        for p in ex.positions.values():
            if p["margin"] < -0.5:
                VIOLATIONS.append(f"trial{trial} step{step} 仓位保证金深度为负 {p['margin']:.2f}")
    liq_count += sum(1 for h in ex.history if h["reason"] == "liq")
    bankrupt_clamps += sum(1 for h in ex.history if h["reason"] == "manual_bankrupt")

print(f"300 账户 × 120 分钟 模糊测试完成")
print(f"强平次数: {liq_count}  破产封底平仓: {bankrupt_clamps}  手动平仓: {close_count}")
if VIOLATIONS:
    print(f"❌ 违规 {len(VIOLATIONS)} 条:")
    for v in VIOLATIONS[:20]:
        print("  ", v)
    sys.exit(1)
print("✅ 全部通过: 任何路径下余额/保证金均未透支 (保险基金语义生效)")
