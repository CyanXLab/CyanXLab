# -*- coding: utf-8 -*-
"""虚拟交易所 —— 仿真币安 U 本位合约的简化版交易规则.

规则要点:
  - 逐仓 (Isolated) 杠杆合约, 1x ~ 125x
  - 吃单 (taker) 0.05% / 挂单 (maker) 0.02%
  - 强平维持保证金率 MMR 0.5%
  - 资金费率每 8 个模拟小时结算一次 (牛市多头付费 / 熊市反之)
  - 市价单按深度滑点, 限价单被动成交收 maker 费
  - 同一根 K 线内 先判强平 后判止盈 (保守原则, 教育风险)
"""
import math
import time
from collections import deque

from .history_data import COIN_META

FEE_TAKER = 0.0005
FEE_MAKER = 0.0002
FEE_SPOT_TAKER = 0.001
FEE_SPOT_MAKER = 0.0005
MMR = 0.005                       # 兼容旧存档的默认值; 实际按 COIN_META[coin]["mmr"] 逐币执行
FUNDING_INTERVAL_MIN = 480        # 币安主流合约: 每 8 小时 (UTC 00:00 / 08:00 / 16:00)
FUNDING_BASE = 0.0001             # 基准利率 0.01% / 8h
FUNDING_CAP = 0.0075              # 资金费率上限 ±0.75%


class Exchange:
    def __init__(self):
        self.balance = 10000.0
        self.start_balance = 10000.0
        self.positions = {}          # id -> dict
        self.orders = {}             # id -> dict (限价挂单)
        self.triggers = {}           # id -> dict (计划委托/触发单)
        self.close_orders = {}       # id -> dict (限价平仓 reduce-only)
        self.spot_orders = {}        # id -> dict (现货限价)
        self.spot_hold = {}          # coin -> {"qty":, "cost":}
        self.history = deque(maxlen=300)
        self.spot_history = deque(maxlen=200)
        self._nid = 1
        self.funding_min = FUNDING_INTERVAL_MIN - int(time.time() // 60) % FUNDING_INTERVAL_MIN
        self.funding_rate = FUNDING_BASE
        self._fund_bucket = int(time.time() // 18000)   # 8h = 28800s, 与真实 UTC 边界对齐
        self.fee_paid_total = 0.0
        self.funding_paid_total = 0.0
        self.maker_fills = 0
        self.insurance_fund_used = 0.0   # 穿仓时保险基金代付的超额亏损 (对齐币安保险基金机制)

    # ---------- 工具 ----------
    def _id(self):
        self._nid += 1
        return self._nid

    def equity(self, marks):
        eq = self.balance
        for p in self.positions.values():
            mp = marks.get(p["coin"], p["entry"])
            pnl = p["side"] * p["qty"] * (mp - p["entry"])
            eq += p["margin"] + pnl
        return eq

    def spot_value(self, marks):
        v = 0.0
        for coin, h in self.spot_hold.items():
            v += h["qty"] * marks.get(coin + "USDT", h.get("cost_px", 0))
        return v

    def margin_used(self):
        return sum(max(p["margin"], 0.0) for p in self.positions.values())

    # ---------- 下单 ----------
    def place(self, coin, side, otype, margin_usdt, leverage, price, mark, depth_usd, tp_pct=None, sl_pct=None):
        """side: 1 多 / -1 空; 返回 (ok, msg, events); 交易规则对齐币安阶梯"""
        events = []
        meta = COIN_META[coin]
        margin_usdt = round(float(margin_usdt), 2)
        leverage = int(leverage)
        if margin_usdt < 5:
            return False, "最低保证金 5 USDT", events
        if not (1 <= leverage <= meta["max_lev"]):
            return False, f"{meta['sym']} 杠杆范围 1-{meta['max_lev']}x (币安阶梯)", events
        if margin_usdt * leverage < meta["min_notional"]:
            return False, f"订单名义价值不可低于 {meta['min_notional']} USDT (币安最小名义)", events
        if otype == "market":
            slip = min(0.0012, margin_usdt * leverage / max(depth_usd, 1) * 0.5)
            fill = mark * (1 + side * slip)
            fee = margin_usdt * leverage * FEE_TAKER
            if margin_usdt + fee > self.balance + 1e-9:
                return False, "可用余额不足", events
            self.balance -= (margin_usdt + fee)
            self.fee_paid_total += fee
            self._open_or_merge(coin, side, margin_usdt, leverage, fill, fee, tp_pct, sl_pct)
            events.append({"type": "fill", "coin": coin, "side": side, "lev": leverage,
                           "margin": margin_usdt, "price": fill, "fee": round(fee, 3)})
            return True, "ok", events
        else:  # limit
            if price is None or price <= 0:
                return False, "限价无效", events
            # 合理性: 多头挂单不能高于现价太多(>2%), 空头同理
            if side == 1 and price > mark * 1.02:
                return False, "买入价高于现价 2%, 请用市价", events
            if side == -1 and price < mark * 0.98:
                return False, "卖出价低于现价 2%, 请用市价", events
            fee_est = margin_usdt * leverage * FEE_MAKER
            if margin_usdt + fee_est > self.balance + 1e-9:
                return False, "可用余额不足", events
            self.balance -= (margin_usdt + fee_est)
            oid = self._id()
            self.orders[oid] = {
                "id": oid, "coin": coin, "side": side, "margin": margin_usdt,
                "lev": leverage, "price": price,
                "tp_pct": tp_pct, "sl_pct": sl_pct, "ts": time.time(),
            }
            return True, "ok", events

    def _open_or_merge(self, coin, side, margin, lev, entry, fee, tp_pct, sl_pct):
        lot = COIN_META[coin]["lot"]
        # 同币同向合并均价
        for p in self.positions.values():
            if p["coin"] == coin and p["side"] == side and p["lev"] == lev:
                total_margin = p["margin"] + margin
                p["entry"] = (p["entry"] * p["margin"] + entry * margin) / total_margin
                p["qty"] = max(lot, math.floor(total_margin * lev / p["entry"] / lot) * lot)  # 按 lot 取整
                p["margin"] = total_margin
                p["fee_paid"] += fee
                self._refresh_risk(p)
                return
        qty = max(lot, math.floor(margin * lev / entry / lot) * lot)  # 币安 LOT_SIZE 步长取整
        pid = self._id()
        pos = {
            "id": pid, "coin": coin, "side": side, "qty": qty, "entry": entry,
            "lev": lev, "margin": margin, "fee_paid": fee, "opened": time.time(),
            "tp": None, "sl": None, "mmr": COIN_META[coin]["mmr"],
        }
        self._refresh_risk(pos)
        if tp_pct:
            pos["tp"] = entry * (1 + side * tp_pct / 100)
        if sl_pct:
            pos["sl"] = entry * (1 - side * sl_pct / 100)
        self.positions[pid] = pos

    def _refresh_risk(self, p):
        mmr = p.get("mmr", MMR)  # 逐币 MMR (BTC 0.4% / ETH 0.5% / 山寨 1%, 对齐币安阶梯)
        if p["side"] == 1:
            p["liq"] = p["entry"] * (1 - 1 / p["lev"] + mmr)
        else:
            p["liq"] = p["entry"] * (1 + 1 / p["lev"] - mmr)

    def update_tp_sl(self, pid, tp=None, sl=None):
        p = self.positions.get(pid)
        if not p:
            return False, "仓位不存在"
        p["tp"] = tp if tp and tp > 0 else None
        p["sl"] = sl if sl and sl > 0 else None
        return True, "ok"

    def cancel(self, oid):
        o = self.orders.pop(oid, None)
        if not o:
            return False, "挂单不存在"
        self.balance += o["margin"] + o["margin"] * o["lev"] * FEE_MAKER
        return True, "ok"

    # ---------- 计划委托 (触发单) ----------
    def place_trigger(self, coin, side, margin_usdt, leverage, trigger, mark, depth_usd, tp_pct=None, sl_pct=None):
        margin_usdt = round(float(margin_usdt), 2)
        if margin_usdt < 5:
            return False, "最低保证金 5 USDT"
        if not (1 <= leverage <= COIN_META[coin]["max_lev"]):
            return False, f"{COIN_META[coin]['sym']} 杠杆范围 1-{COIN_META[coin]['max_lev']}x (币安阶梯)"
        fee_est = margin_usdt * leverage * FEE_TAKER
        # 币安语义: 下单即冻结订单成本 = 保证金 + 预估吃单费 (防止成交时余额不足透支)
        if self.balance < margin_usdt + fee_est:
            return False, "可用余额不足 (含预估手续费)"
        self.balance -= (margin_usdt + fee_est)
        oid = self._id()
        self.triggers[oid] = {"id": oid, "coin": coin, "side": side, "margin": margin_usdt,
                              "lev": leverage, "trigger": float(trigger), "above": trigger >= mark,
                              "fee_locked": fee_est,
                              "tp_pct": tp_pct, "sl_pct": sl_pct}
        return True, "ok"

    def cancel_trigger(self, oid):
        t = self.triggers.pop(oid, None)
        if not t:
            return False, "触发单不存在"
        self.balance += t["margin"] + t.get("fee_locked", t["margin"] * t["lev"] * FEE_TAKER)
        return True, "ok"

    # ---------- 限价平仓 (reduce-only) ----------
    def place_limit_close(self, pid, price, fraction):
        p = self.positions.get(pid)
        if not p:
            return False, "仓位不存在"
        if fraction >= 0.999:
            fraction = 1.0
        oid = self._id()
        self.close_orders[oid] = {"id": oid, "pid": pid, "price": float(price),
                                  "fraction": max(0.05, min(1.0, fraction))}
        return True, "ok"

    # ---------- 现货 ----------
    def place_spot(self, coin, side, otype, usdt_amt, price, mark):
        """现货买/卖 (统一账户, 直接动用 USDT 余额); side: 1买 -1卖"""
        usdt_amt = round(float(usdt_amt), 2)
        if usdt_amt < 5:
            return False, "最低 5 USDT"
        if otype == "market":
            if side == 1:
                fee = usdt_amt * FEE_SPOT_TAKER
                if self.balance < usdt_amt + fee:
                    return False, "USDT 不足"
                qty = (usdt_amt - fee) / mark
                self.balance -= (usdt_amt + fee)
                self.fee_paid_total += fee
                self._spot_receive(coin, qty, usdt_amt)
                self.spot_history.appendleft({"coin": coin, "side": 1, "price": mark, "qty": round(qty, 6),
                                              "usd": round(usdt_amt, 2), "fee": round(fee, 3), "ts": time.time()})
                return True, "ok"
            else:
                h = self.spot_hold.get(coin)
                qty_all = h["qty"] if h else 0
                if qty_all <= 0:
                    return False, "无持仓可卖"
                return self._spot_sell_market(coin, qty_all, mark)
        else:
            if price is None or price <= 0:
                return False, "限价无效"
            if side == 1:
                if self.balance < usdt_amt * 1.001:
                    return False, "USDT 不足"
                self.balance -= usdt_amt  # 锁定
                oid = self._id()
                self.spot_orders[oid] = {"id": oid, "coin": coin, "side": 1, "usdt": usdt_amt,
                                         "price": float(price), "qty": None}
                return True, "ok"
            else:
                h = self.spot_hold.get(coin)
                if not h or h["qty"] <= 0:
                    return False, "无持仓可卖"
                oid = self._id()
                self.spot_orders[oid] = {"id": oid, "coin": coin, "side": -1, "usdt": None,
                                         "price": float(price), "qty": h["qty"]}
                h["qty_locked"] = h.get("qty_locked", 0) + h["qty"]  # 锁定全部
                return True, "ok"

    def _spot_receive(self, coin, qty, cost):
        h = self.spot_hold.setdefault(coin, {"qty": 0.0, "cost": 0.0, "qty_locked": 0.0, "cost_px": 0})
        h["cost"] += cost
        h["qty"] += qty
        h["cost_px"] = h["cost"] / max(h["qty"], 1e-12)

    def _spot_sell_market(self, coin, qty, mark):
        h = self.spot_hold.get(coin)
        if not h or h["qty"] < qty - 1e-9:
            return False, "持仓不足"
        proceeds = qty * mark * (1 - FEE_SPOT_TAKER)
        fee = qty * mark * FEE_SPOT_TAKER
        self.balance += proceeds
        self.fee_paid_total += fee
        avg_cost_ratio = h["cost"] / max(h["qty"], 1e-12) * qty
        h["qty"] -= qty
        h["cost"] -= avg_cost_ratio
        h["qty_locked"] = max(0.0, h.get("qty_locked", 0) - qty)
        if h["qty"] <= 1e-9:
            self.spot_hold.pop(coin, None)
        pnl = proceeds - avg_cost_ratio
        self.spot_history.appendleft({"coin": coin, "side": -1, "price": mark, "qty": round(qty, 6),
                                      "usd": round(proceeds, 2), "fee": round(fee, 3), "ts": time.time(),
                                      "pnl": round(pnl, 2)})
        return True, "ok"

    # ---------- 每分钟撮合 ----------
    def on_minute(self, candles, regime, events, sim_ts=None):
        """candles: {coin: (mark, high, low)}; events: 引擎事件列表 (append); sim_ts: 模拟时间戳"""
        # 0. 计划委托触发
        for oid in list(self.triggers.keys()):
            t = self.triggers[oid]
            mk, h, l = candles.get(t["coin"], (None, None, None))
            if mk is None:
                continue
            fired = (mk >= t["trigger"]) if t["above"] else (mk <= t["trigger"])
            if not fired:
                continue
            self.triggers.pop(oid, None)
            fill = mk * (1 + t["side"] * min(0.0012, t["margin"] * t["lev"] / 6e6 * 0.5))
            fee = t["margin"] * t["lev"] * FEE_TAKER
            # 手续费已在挂单时冻结 (fee_locked), 成交时只入账不再扣款 — 杜绝透支
            self.fee_paid_total += fee
            self._open_or_merge(t["coin"], t["side"], t["margin"], t["lev"], fill, fee, t["tp_pct"], t["sl_pct"])
            events.append({"type": "trigger_fill", "coin": t["coin"], "side": t["side"], "lev": t["lev"],
                           "margin": t["margin"], "price": fill, "trigger": t["trigger"]})
        # 0.5 限价平仓 (reduce-only)
        for oid in list(self.close_orders.keys()):
            co = self.close_orders[oid]
            p = self.positions.get(co["pid"])
            if not p:
                self.close_orders.pop(oid, None)
                continue
            mk, h, l = candles.get(p["coin"], (None, None, None))
            if mk is None:
                continue
            hit = (l <= co["price"]) if p["side"] == 1 else (h >= co["price"])
            if not hit:
                continue
            self.close_orders.pop(oid, None)
            events.append({"type": "maker_close", "coin": p["coin"]})
            self._close(p, co["price"], co["fraction"], events, reason="maker_close")
        # 0.7 现货限价成交
        for oid in list(self.spot_orders.keys()):
            so = self.spot_orders[oid]
            mk, h, l = candles.get(so["coin"], (None, None, None))
            if mk is None:
                continue
            if so["side"] == 1:
                if l <= so["price"]:
                    self.spot_orders.pop(oid, None)
                    self.balance += so["usdt"]  # 解锁后重新按 maker 费结算
                    qty = so["usdt"] * (1 - FEE_SPOT_MAKER) / so["price"]
                    fee = so["usdt"] * FEE_SPOT_MAKER
                    self.balance -= (so["usdt"])
                    self._spot_receive(so["coin"], qty, so["usdt"])
                    self.fee_paid_total += fee
                    self.maker_fills += 1
                    self.spot_history.appendleft({"coin": so["coin"], "side": 1, "price": so["price"],
                                                  "qty": round(qty, 6), "usd": round(so["usdt"], 2),
                                                  "fee": round(fee, 3), "ts": time.time()})
                    events.append({"type": "spot_fill", "coin": so["coin"], "side": 1, "price": so["price"]})
            else:
                if h >= so["price"]:
                    self.spot_orders.pop(oid, None)
                    sell_h = self.spot_hold.get(so["coin"])
                    if sell_h and sell_h["qty"] > 0:
                        self._spot_sell_market(so["coin"], sell_h["qty"], so["price"])
                        self.maker_fills += 1
                        events.append({"type": "spot_fill", "coin": so["coin"], "side": -1, "price": so["price"]})
        # 1. 限价单成交
        for oid in list(self.orders.keys()):
            o = self.orders[oid]
            mk, h, l = candles.get(o["coin"], (None, None, None))
            if mk is None:
                continue
            hit = (l <= o["price"]) if o["side"] == 1 else (h >= o["price"])
            if not hit:
                continue
            self.orders.pop(oid, None)
            fee = o["margin"] * o["lev"] * FEE_MAKER
            self.maker_fills += 1
            self._open_or_merge(o["coin"], o["side"], o["margin"], o["lev"], o["price"], fee, o["tp_pct"], o["sl_pct"])
            events.append({"type": "fill", "coin": o["coin"], "side": o["side"], "lev": o["lev"],
                           "margin": o["margin"], "price": o["price"], "fee": round(fee, 3), "maker": True})
        # 2. 止盈止损 / 强平 (先强平, 保守原则)
        for pid in list(self.positions.keys()):
            p = self.positions[pid]
            mk, h, l = candles.get(p["coin"], (None, None, None))
            if mk is None:
                continue
            if p["side"] == 1 and l <= p["liq"]:
                self._liquidate(p, p["liq"], events)
                continue
            if p["side"] == -1 and h >= p["liq"]:
                self._liquidate(p, p["liq"], events)
                continue
            if p["tp"] and ((p["side"] == 1 and h >= p["tp"]) or (p["side"] == -1 and l <= p["tp"])):
                self._close(p, p["tp"], 1.0, events, reason="tp")
                continue
            if p["sl"] and ((p["side"] == 1 and l <= p["sl"]) or (p["side"] == -1 and h >= p["sl"])):
                self._close(p, p["sl"], 1.0, events, reason="sl")
                continue
        # 3. 资金费率 — 与币安一致: UTC 00:00 / 08:00 / 16:00 整点结算, 费率上限 ±0.75%
        ts = sim_ts if sim_ts is not None else time.time()
        bucket = int(ts // 18000)          # 8h 桶, 与真实 UTC 边界对齐
        if bucket != self._fund_bucket:
            self._fund_bucket = bucket
            if regime == 0:
                self.funding_rate = min(FUNDING_BASE + 0.00025, FUNDING_CAP)
            elif regime == 1:
                self.funding_rate = max(FUNDING_BASE - 0.00025, -FUNDING_CAP)
            else:
                self.funding_rate = FUNDING_BASE
            for p in list(self.positions.values()):
                mk = candles.get(p["coin"], (p["entry"],)) [0]
                notional = p["qty"] * mk
                pay = notional * self.funding_rate * p["side"]
                # 多头在正费率时支付
                amount = notional * abs(self.funding_rate)
                pay_amt = amount if ((self.funding_rate > 0) == (p["side"] == 1)) else -amount
                p["margin"] -= pay_amt
                self.funding_paid_total += pay_amt
                events.append({"type": "funding", "coin": p["coin"], "amount": round(pay_amt, 3),
                               "rate": round(self.funding_rate * 100, 4)})
                if p["margin"] <= 0.5:
                    self._liquidate(p, mk, events)
        # 4. 仓位保证金被资金费扣穿检查
        for pid in list(self.positions.keys()):
            p = self.positions[pid]
            if p["margin"] <= 0.01:
                mk = candles.get(p["coin"], (p["entry"],))[0]
                self._liquidate(p, mk, events)

    def _liquidate(self, p, price, events):
        """强平: 逐仓全损 — 保证金即最大亏损; 资金费把保证金磨到负的部分由保险基金兑底,
        记录为正盈余会误导玩家, 必须钳到 0 (币安语义: 破产价之外损失归保险基金)"""
        self.positions.pop(p["id"], None)
        loss = max(p["margin"], 0.0)                 # 防负保证金被记成收益
        if p["margin"] < 0:
            self.insurance_fund_used += -p["margin"]
        events.append({"type": "liq", "coin": p["coin"], "side": p["side"], "lev": p["lev"],
                       "margin": round(loss, 2), "entry": p["entry"], "price": price,
                       "loss": round(loss, 2), "id": p["id"]})
        self._record(p, price, -loss, "liq")

    def _close(self, p, price, fraction, events, reason="manual"):
        """平仓 (含手动/止盈/止损/限价平仓).
        币安逐仓语义: 价格跳空穿越破产价时, 净亏损 (含手续费) 封底于保证金部分 —
        账户余额绝不因平仓变负, 破产价之外的超额亏损由保险基金吸收."""
        qty = p["qty"] * fraction
        pnl = p["side"] * qty * (price - p["entry"])
        fee = qty * price * FEE_TAKER
        margin_part = p["margin"] * fraction
        net = pnl - fee                              # 净盈亏 (扣手续费)
        if net < -margin_part:                       # 穿仓封底: 保险基金兑底超额部分
            self.insurance_fund_used += (-margin_part - net)
            net = -margin_part
        self.balance += margin_part + net
        self.fee_paid_total += fee
        pnl_final = net
        p["qty"] -= qty
        p["margin"] -= margin_part
        p["fee_paid"] += fee
        closed_fully = p["qty"] / (p["margin"] * p["lev"] / p["entry"] + 1e-12) < 0.005 or fraction >= 0.999
        ev = {"type": "close", "coin": p["coin"], "side": p["side"], "lev": p["lev"],
              "pnl": round(pnl_final, 4), "roi": round(pnl_final / max(margin_part, 1e-9) * 100, 2),
              "price": price, "reason": reason, "id": p["id"], "fraction": fraction}
        if net <= -margin_part + 1e-9:
            ev["bankrupt"] = True                    # 已到破产价: 展示为强平级损失
            if reason == "manual":
                reason = ev["reason"] = "manual_bankrupt"
        if closed_fully or p["qty"] <= 1e-12:
            self.positions.pop(p["id"], None)
            closed_fully = True
        ev["closed"] = closed_fully
        events.append(ev)
        if closed_fully:
            self._record(p, price, pnl_final, reason)

    def close_position(self, pid, fraction, price, events):
        p = self.positions.get(pid)
        if not p:
            return False, "仓位不存在"
        fraction = max(0.05, min(1.0, float(fraction)))
        self._close(p, price, fraction, events, reason="manual")
        return True, "ok"

    def _record(self, p, price, pnl, reason):
        self.history.appendleft({
            "coin": p["coin"], "side": p["side"], "lev": p["lev"],
            "entry": p["entry"], "close": price, "margin": round(p["margin"], 2),
            "pnl": round(pnl, 4), "roi": round(pnl / max(p["margin"], 1e-9) * 100, 2),
            "reason": reason, "ts": time.time(),
        })

    # ---------- 状态 ----------
    def snapshot(self, marks):
        poss = []
        for p in self.positions.values():
            mk = marks.get(p["coin"], p["entry"])
            pnl = p["side"] * p["qty"] * (mk - p["entry"])
            poss.append({
                "id": p["id"], "coin": p["coin"], "side": p["side"], "lev": p["lev"],
                "qty": p["qty"], "entry": p["entry"], "mark": mk, "liq": p["liq"],
                "margin": round(p["margin"], 2), "u_pnl": round(pnl - 0, 4),
                "u_roi": round(pnl / max(p["margin"], 1e-9) * 100, 2),
                "tp": p["tp"], "sl": p["sl"], "notional": round(p["qty"] * mk, 2),
            })
        orders = []
        for o in self.orders.values():
            orders.append({"id": o["id"], "coin": o["coin"], "side": o["side"], "lev": o["lev"],
                           "margin": o["margin"], "price": o["price"]})
        return poss, orders

    # ---------- 现货快照 ----------
    def snapshot_spot(self, marks):
        hold = []
        for coin, h in self.spot_hold.items():
            px = marks.get(coin + "USDT", h.get("cost_px", 0))
            value = h["qty"] * px
            hold.append({"coin": coin, "qty": round(h["qty"], 6), "price": px,
                         "cost": round(h["cost"], 2), "value": round(value, 2),
                         "pnl": round(value - h["cost"], 2),
                         "pnl_pct": round((value / h["cost"] - 1) * 100, 2) if h["cost"] else 0})
        orders = [{"id": o["id"], "coin": o["coin"], "side": o["side"], "price": o["price"],
                   "usdt": o["usdt"], "qty": o["qty"]} for o in self.spot_orders.values()]
        return hold, orders
