# -*- coding: utf-8 -*-
"""JSON-RPC 2.0 兼容层 —— 以太坊节点 API (v1.1)

端点: POST /rpc  (支持单请求与 batch)
方法:
  eth_chainId / net_version / web3_clientVersion / eth_gasPrice / eth_blockNumber
  eth_getBalance / eth_getTransactionCount / eth_getBlockByNumber / eth_getBlockByHash
  eth_getTransactionByHash / eth_getTransactionReceipt / eth_sendRawTransaction
  eth_call / eth_estimateGas / eth_getLogs / eth_syncing / eth_accounts / eth_mine
错误码: -32700 parse / -32600 invalid / -32601 method / -32602 params / 401+ 业务
"""
import json

from .chain import (CHAIN_ID, WEI, GAS_PRICE_WEI, GAS_TRANSFER, GAS_CONTRACT_CALL,
                    CST_ADDRESS, FAUCET_ADDRESS)


def _hex_qty(n) -> str:
    return "0x" + hex(int(n))[2:]


def _hex_data(s, default="0x"):
    return s if isinstance(s, str) and s.startswith("0x") else default


def _addr(p) -> str:
    return (p or "").lower()


def _block_obj(chain, blk, full):
    b = {
        "number": _hex_qty(blk["height"]),
        "hash": blk["hash"],
        "parentHash": blk.get("parent", "0x" + "0" * 64),
        "timestamp": _hex_qty(int(blk["ts"])),
        "nonce": "0x" + "0" * 16,
        "miner": "0x" + "0" * 40,
        "difficulty": "0x1",
        "totalDifficulty": _hex_qty(blk["height"]),
        "gasLimit": _hex_qty(30_000_000),
        "gasUsed": _hex_qty(blk.get("gas_used", 0)),
        "size": _hex_qty(512 + 128 * len(blk["txs"])),
        "transactionsRoot": "0x" + "0" * 64,
        "stateRoot": "0x" + "0" * 64,
        "sha3Uncles": "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347",
        "logsBloom": "0x" + "0" * 512,
        "uncles": [],
    }
    if full:
        b["transactions"] = [chain.txs[h] and _tx_obj(chain, chain.txs[h]) for h in blk["txs"]
                             if h in chain.txs]
    else:
        b["transactions"] = list(blk["txs"])
    return b


def _tx_obj(chain, t):
    return {
        "hash": t["hash"],
        "from": t.get("from", "0x" + "0" * 40),
        "to": t.get("to") or None,
        "nonce": _hex_qty(chain.nonce_of(t.get("from", ""))),
        "value": _hex_qty(int(round((t.get("amount") or 0) * WEI))),
        "gas": _hex_qty(GAS_TRANSFER),
        "gasPrice": _hex_qty(GAS_PRICE_WEI),
        "input": "0x",
        "blockNumber": _hex_qty(t["block"]) if t.get("block") else None,
        "blockHash": (chain.blocks[t["block"] - 1]["hash"] if t.get("block") and t["block"] <= len(chain.blocks)
                      else None),
        "transactionIndex": _hex_qty(0),
        "type": "0x0",
        "v": "0x0", "r": "0x0", "s": "0x0",
    }


def _receipt_obj(chain, rc):
    logs = [l for l in chain.logs if l["transactionHash"] == rc["transactionHash"]]
    out = dict(rc)
    out["status"] = _hex_qty(rc.get("status", 1))
    out["gasUsed"] = _hex_qty(rc.get("gasUsed", GAS_TRANSFER))
    out["effectiveGasPrice"] = _hex_qty(rc.get("effectiveGasPrice", GAS_PRICE_WEI))
    out["blockNumber"] = _hex_qty(rc.get("blockNumber", len(chain.blocks)))
    out["logsBloom"] = "0x" + "0" * 512
    out["type"] = "0x0"
    out["cumulativeGasUsed"] = out["gasUsed"]
    out["logs"] = [{
        "address": l["address"], "topics": l["topics"], "data": l["data"],
        "blockNumber": _hex_qty(l["blockNumber"]), "transactionHash": l["transactionHash"],
        "transactionIndex": "0x0", "blockHash": l["blockHash"], "logIndex": _hex_qty(i),
        "removed": False,
    } for i, l in enumerate(logs)]
    return out


def _tag_num(tag):
    """'0x' hex / int -> 块高数值 (latest 等 tag 由调用方处理)"""
    if isinstance(tag, str) and tag.startswith("0x"):
        return int(tag, 16)
    if isinstance(tag, int):
        return tag
    raise ValueError("bad block tag")


class RpcError(Exception):
    def __init__(self, code, message):
        self.code = code
        self.message = message


def dispatch(chain, engine, method, params):
    """单方法调度; 返回 result 或抛 RpcError"""
    p = params if isinstance(params, list) else []
    if method == "eth_chainId":
        return _hex_qty(CHAIN_ID)
    if method == "net_version":
        return str(CHAIN_ID)
    if method == "web3_clientVersion":
        return "CoinSprintChain/v1.1.0/sim"
    if method == "eth_syncing":
        return False
    if method == "eth_accounts":
        return [w["eth"].lower() for w in chain.wallets.values()]
    if method == "eth_gasPrice":
        return _hex_qty(GAS_PRICE_WEI)
    if method == "eth_blockNumber":
        return _hex_qty(len(chain.blocks))
    if method == "eth_mine":
        chain._mine_block([])
        return _hex_qty(len(chain.blocks))
    if method == "eth_getBalance":
        if len(p) < 1:
            raise RpcError(-32602, "missing address")
        return _hex_qty(chain.native_balance_wei(_addr(p[0])))
    if method == "eth_getTransactionCount":
        if len(p) < 1:
            raise RpcError(-32602, "missing address")
        return _hex_qty(chain.nonce_of(_addr(p[0])))
    if method == "eth_getBlockByNumber":
        tag = p[0] if p else "latest"
        if tag in ("latest", "pending", "safe", "finalized"):
            blk = chain.blocks[-1] if chain.blocks else None
        elif tag == "earliest":
            blk = chain.blocks[0] if chain.blocks else None
        else:
            n = _tag_num(tag)
            blk = chain.blocks[n - 1] if 1 <= n <= len(chain.blocks) else None
        if not blk:
            return None
        return _block_obj(chain, blk, bool(p[1]) if len(p) > 1 else False)
    if method == "eth_getBlockByHash":
        h = _addr(p[0]) if p else ""
        blk = next((b for b in chain.blocks if b["hash"].lower() == h), None)
        if not blk:
            return None
        return _block_obj(chain, blk, bool(p[1]) if len(p) > 1 else False)
    if method == "eth_getTransactionByHash":
        t = chain.txs.get((p[0] if p else "").lower())
        return _tx_obj(chain, t) if t else None
    if method == "eth_getTransactionReceipt":
        h = (p[0] if p else "").lower()
        rc = chain.receipts.get(h)
        return _receipt_obj(chain, rc) if rc else None
    if method == "eth_sendRawTransaction":
        if not p or not isinstance(p[0], str):
            raise RpcError(-32602, "missing raw tx hex")
        ok, res = chain.execute_raw_tx(p[0])
        if not ok:
            raise RpcError(401, res)          # 业务拒绝 (同 go-ethereum 返回错误, JSON-RPC 层报错)
        return res
    if method == "eth_call":
        obj = p[0] if p else {}
        to = _addr(obj.get("to"))
        data = _hex_data(obj.get("data") or obj.get("input"))
        if to == CST_ADDRESS.lower():
            return chain.eth_call_cst(data)
        if to == FAUCET_ADDRESS.lower():
            return "0x"
        return "0x"
    if method == "eth_estimateGas":
        obj = p[0] if p else {}
        data = _hex_data(obj.get("data") or obj.get("input"))
        return _hex_qty(GAS_CONTRACT_CALL if data and data != "0x" else GAS_TRANSFER)
    if method == "eth_getLogs":
        obj = p[0] if p else {}
        latest = len(chain.blocks)

        def _blk(tag):
            if tag in (None, "latest", "pending", "safe", "finalized"):
                return latest
            if tag == "earliest":
                return 1
            return _tag_num(tag)
        fb = _blk(obj.get("fromBlock")) or 1
        tb = _blk(obj.get("toBlock")) or latest
        addr = obj.get("address")
        topics = obj.get("topics") or []
        if isinstance(addr, str):
            addr = [addr]
        out = []
        for i, l in enumerate(chain.logs):
            if not (fb <= l["blockNumber"] <= tb):
                continue
            if addr and l["address"] not in [a.lower() for a in addr]:
                continue
            match = True
            for j, t in enumerate(topics):
                if t is None:
                    continue
                tv = t if isinstance(t, list) else [t]
                if l["topics"][j] not in [x.lower() for x in tv]:
                    match = False
                    break
            if match:
                out.append({"address": l["address"], "topics": l["topics"], "data": l["data"],
                            "blockNumber": _hex_qty(l["blockNumber"]),
                            "transactionHash": l["transactionHash"], "transactionIndex": "0x0",
                            "blockHash": l["blockHash"], "logIndex": _hex_qty(i), "removed": False})
        return out
    raise RpcError(-32601, f"method not found: {method}")


def handle(chain, engine, body):
    """处理 JSON-RPC 2.0 请求体 (dict 或 batch list); 返回响应 dict/list"""
    def one(req):
        if not isinstance(req, dict) or req.get("jsonrpc") != "2.0" or "method" not in req:
            return {"jsonrpc": "2.0", "id": req.get("id") if isinstance(req, dict) else None,
                    "error": {"code": -32600, "message": "invalid request"}}
        try:
            result = dispatch(chain, engine, req["method"], req.get("params", []))
            return {"jsonrpc": "2.0", "id": req.get("id"), "result": result}
        except RpcError as e:
            return {"jsonrpc": "2.0", "id": req.get("id"),
                    "error": {"code": e.code, "message": e.message}}
        except Exception as e:
            return {"jsonrpc": "2.0", "id": req.get("id"),
                    "error": {"code": -32603, "message": f"internal error: {e}"}}

    if isinstance(body, list):
        return [one(r) for r in body]
    return one(body)
