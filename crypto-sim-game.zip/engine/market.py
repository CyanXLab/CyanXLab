# -*- coding: utf-8 -*-
"""行情仿真引擎 —— 用历史数据学到的参数生成'从未存在但像真的一样'的行情.

核心思路 (分层混合模型):
  [小时级核心]  GARCH(1,1) 波动率动态 + 三态马尔可夫市态 + Student-t 胖尾 + 稀疏跳变
                -> 每小时采样一个'目标小时收益 r_h' (多币种通过共享市场因子 z_mkt 相关)
  [分钟级分配]  布朗桥把 r_h 精确分配到 60 根分钟收益 (Σr_min = r_h), 保留波动聚集形态
  [亚分钟级]    4 个子刻度 + 微噪声 -> 生成真实的 K 线影线 / 盘口抖动 / 成交流
"""
import math
import random
import time
from collections import deque

from .history_data import COIN_META, COINS, REGIME_NAMES

INTERVALS = {"1m": 1, "5m": 5, "15m": 15, "1h": 60, "4h": 240}
MAX_CANDLES = {"1m": 2200, "5m": 1600, "15m": 1400, "1h": 1200, "4h": 900}

NEWS_TEMPLATES = {
    "bull": [
        "现货 ETF 单日净流入 {x} 亿美元，市场情绪高涨",
        "美联储释放降息信号，风险资产集体走强",
        "{sym} 现货 ETF 获批预期升温，机构持续加仓",
        "链上巨鲸地址累计增持 {x} 万枚 {sym}",
        "主流交易所 {sym} 做多保证金比例创月内新高",
    ],
    "bear": [
        "链上监控：巨鲸地址向交易所转出 {x} 万枚 {sym}",
        "监管机构对加密交易所开出巨额罚单，恐慌蔓延",
        "某大型机构清仓 {sym} 头寸，链上大额转账激增",
        "宏观数据超预期强劲，降息预期降温，市场急跌",
        "交易所遭黑客攻击，损失约 {x} 亿美元资产",
    ],
}


def t_draw(rng, nu):
    """标准化 Student-t 抽样 (方差=1), 生成胖尾收益"""
    if nu >= 30:
        return rng.gauss(0, 1)
    x = rng.gammavariate(nu / 2.0, 2.0)  # χ²_ν, 均值=ν
    z = rng.gauss(0, 1) / math.sqrt(x / nu)  # t_ν
    return z / math.sqrt(nu / (nu - 2.0))  # 标准化到方差=1


def _bridge_increments(rng, n, sigma):
    """布朗桥增量: Σδ=0, 平方和≈n·σ², 用于把小时收益精确分配到分钟"""
    gs = [rng.gauss(0, 1) for _ in range(n)]
    total = sum(gs)
    deltas = [g - total / n for g in gs]
    ss = sum(d * d for d in deltas) or 1e-9
    scale = math.sqrt(n) / math.sqrt(ss)
    return [d * scale * sigma for d in deltas]


class CoinSim:
    def __init__(self, symbol, model, epoch, seed):
        self.symbol = symbol
        self.meta = COIN_META[symbol]
        self.m = model
        self.rng = random.Random(seed)
        self.epoch = epoch
        self.price = model["price0"]
        self.sigma2 = model["sigma_h"] ** 2
        self.last_r_h = 0.0
        self._hod = 0
        # 小时 -> 分钟 状态
        self.minute_returns = []
        self.mi = 0
        self.sigma_min = model["sigma_h"] / math.sqrt(60)
        self.sub_prices = [self.price] * 5
        # K线
        self.candles = {iv: {"closed": deque(maxlen=MAX_CANDLES[iv]), "cur": None} for iv in INTERVALS}
        # 24h 滚动窗口 (手动淘汰, O(1) 均摊维护统计量)
        self._closes = deque()
        self._his = deque()
        self._los = deque()
        self._vols = deque()
        for _ in range(1440):
            self._closes.append(self.price)
            self._his.append(self.price)
            self._los.append(self.price)
            self._vols.append(0.0)
        self.hi24 = self.price
        self.lo24 = self.price
        self.close0_24 = self.price
        self.vol24 = 0.0
        # 盘口 / 成交流
        self.book = {"bids": [], "asks": []}
        self.tape = deque(maxlen=90)
        self.last_move = 0.0
        self._gen_book()

    # ---------- 小时级 ----------
    def _hour_step(self, regime, z_mkt, jump_mag, hod):
        m = self.m
        g = m["garch"]
        last_r2 = self.last_r_h ** 2 if self.last_r_h else m["sigma_h"] ** 2
        s2 = g["omega"] + g["alpha"] * last_r2 + g["beta"] * self.sigma2
        lo, hi = (m["sigma_h"] * 0.35) ** 2, (m["sigma_h"] * 3.2) ** 2
        self.sigma2 = min(max(s2, lo), hi)
        sigma_h = math.sqrt(self.sigma2)
        season = m["season"][hod % 24]
        drift = m["regime_drift"][regime]
        vol_mul = m["regime_vol"][regime]
        b = min(0.92, max(0.0, m["beta_btc"]))
        z_eff = b * z_mkt + math.sqrt(max(0.05, 1 - b * b)) * t_draw(self.rng, m["nu"])
        r_h = drift + sigma_h * vol_mul * season * z_eff
        if jump_mag != 0.0:
            r_h += jump_mag * sigma_h
        self.last_r_h = r_h
        self.sigma_min = sigma_h * season / math.sqrt(60)
        bridge = _bridge_increments(self.rng, 60, self.sigma_min * 0.62)
        drift_min = r_h / 60.0
        self.minute_returns = [drift_min + bd for bd in bridge]
        self.mi = 0

    def set_hod(self, hod):
        self._hod = hod

    # ---------- 分钟级 ----------
    def minute_tick(self, minute_index):
        if self.mi >= 60:
            return
        r_min = self.minute_returns[self.mi]
        self.mi += 1
        # 4 个子刻度: 均值 r_min/4 + 布朗桥抖动 (保证 Σ = r_min 且有真实影线)
        subs_b = _bridge_increments(self.rng, 4, self.sigma_min * 0.55)
        subs = [r_min / 4.0 + b for b in subs_b]
        open_p = self.price
        p = open_p
        prices = [p]
        for s in subs:
            p *= math.exp(s)
            prices.append(p)
        t = self.meta["tick"]
        hi_p = max(prices) + abs(self.rng.gauss(0, 1)) * t * 0.6
        lo_p = min(prices) - abs(self.rng.gauss(0, 1)) * t * 0.6
        close_p = prices[-1]
        vol_usd = (self.meta["depth_usd"] / 15.0) * (0.4 + self.rng.random() * 1.2) * (1 + abs(r_min) * 220)
        self._push_candle(minute_index, open_p, hi_p, lo_p, close_p, vol_usd)
        self.price = close_p
        self.last_move = r_min
        self.sub_prices = [open_p] + prices[1:]
        self._update_24h(hi_p, lo_p, close_p, vol_usd)
        self._gen_tape(minute_index)
        self._gen_book()

    def _push_candle(self, minute_index, o, h, l, c, v):
        for iv, mins in INTERVALS.items():
            bucket = minute_index // mins
            cd = self.candles[iv]
            cur = cd["cur"]
            if cur is None or cur["bucket"] != bucket:
                if cur is not None:
                    cd["closed"].append([cur["ts"], cur["o"], cur["h"], cur["l"], cur["c"], round(cur["v"], 1)])
                cd["cur"] = {"bucket": bucket, "ts": self.epoch + bucket * mins * 60,
                             "o": o, "h": h, "l": l, "c": c, "v": v}
            else:
                cur["h"] = max(cur["h"], h)
                cur["l"] = min(cur["l"], l)
                cur["c"] = c
                cur["v"] += v

    def _update_24h(self, h, l, c, v):
        self._closes.append(c); self._his.append(h); self._los.append(l); self._vols.append(v)
        ev_h = ev_l = ev_v = None
        if len(self._closes) > 1440:
            self._closes.popleft()
            ev_h = self._his.popleft(); ev_l = self._los.popleft(); ev_v = self._vols.popleft()
        self.close0_24 = self._closes[0]
        self.vol24 += v - (ev_v or 0)
        if ev_h is not None and ev_h >= self.hi24:
            self.hi24 = max(self._his)
        else:
            self.hi24 = max(self.hi24, h)
        if ev_l is not None and ev_l <= self.lo24:
            self.lo24 = min(self._los)
        else:
            self.lo24 = min(self.lo24, l)

    def _gen_book(self):
        meta = self.meta
        mid = self.price
        sp = max(mid * meta["spread"] * (1 + abs(self.last_move) * 35), meta["tick"] * 2)
        step = sp * 1.8
        bias = 1 + max(-0.4, min(0.4, self.last_move * 35))
        base_usd = meta["depth_usd"] / 60.0
        bids, asks = [], []
        for i in range(14):
            w = 0.5 + self.rng.random() * 1.2
            step_i = step * (0.75 + 0.11 * i)
            pb = mid - sp / 2 - i * step_i
            pa = mid + sp / 2 + i * step_i
            bids.append([round(pb, 10), round(base_usd * w * bias / mid, 6)])
            asks.append([round(pa, 10), round(base_usd * w * (2 - bias) / mid, 6)])
        self.book = {"bids": bids, "asks": asks}

    def _gen_tape(self, minute_index):
        n = 2 + int(self.rng.random() * 5)
        for _ in range(n):
            long_side = self.rng.random() < (0.64 if self.last_move > 0 else 0.36)
            sp = max(self.price * self.meta["spread"] * 2, self.meta["tick"])
            px = self.price + (self.rng.random() - 0.5) * sp
            usd = (self.meta["depth_usd"] / 120.0) * (0.05 + self.rng.random() ** 2 * 2.4)
            self.tape.appendleft({"t": minute_index, "p": round(px, 10),
                                  "q": round(usd / px, 6), "usd": round(usd, 1),
                                  "side": "buy" if long_side else "sell"})

    def display_price(self, partial_min):
        if self.mi >= 60 or not self.minute_returns:
            return self.price
        k = min(4, int(partial_min * 4))
        f = max(0.0, min(1.0, partial_min * 4 - k))
        a, b = self.sub_prices[k], self.sub_prices[k + 1]
        return a + (b - a) * f

    def klines(self, interval, limit=320):
        cd = self.candles[interval]
        out = list(cd["closed"])[-limit:]
        if cd["cur"] is not None:
            c = cd["cur"]
            out.append([c["ts"], c["o"], c["h"], c["l"], c["c"], round(c["v"], 1)])
        return out[-limit:]


class MarketEngine:
    """全局引擎: 时钟 / 全局市态 / 多币联动 / 新闻事件"""

    def __init__(self, models, epoch=None, seed=None):
        self.models = models
        self.seed = seed if seed is not None else int(time.time() * 1000) & 0x7FFFFFFF
        self.rng = random.Random(self.seed ^ 0x5EED)
        self.epoch = epoch if epoch is not None else int(time.time())
        self.minute_index = 0
        self.carry = 0.0
        self.regime = int(self.models["BTCUSDT"]["model"].get("labels_tail", 2))
        self.regime_hours = 0
        self.events = deque(maxlen=80)
        self.eid = 1
        self.speed = 60
        self.paused = False
        self._warm = True
        self.hooks = []   # 每模拟分钟回调 [fn(minute_index)]
        self.coins = {}
        for i, sym in enumerate(COINS):
            self.coins[sym] = CoinSim(sym, models[sym]["model"], self.epoch, self.seed + i * 977 + 1)
        self._hour_boundary(0)   # 初始化第一个小时的收益路径
        self.warmup(4320)
        self._warm = False

    # ---------- 时钟 ----------
    def advance(self, dt_minutes):
        if self.paused:
            return
        self.carry += dt_minutes
        guard = 0
        while self.carry >= 1.0 and guard < 2400:
            self.carry -= 1.0
            self.minute_index += 1
            self._minute(self.minute_index)
            guard += 1

    def _minute(self, mi):
        hod = int((self.epoch + mi * 60) // 3600) % 24
        if mi % 60 == 0:
            self._hour_boundary(mi)
        for c in self.coins.values():
            c.set_hod(hod)
            c.minute_tick(mi)
        for h in self.hooks:
            h(mi)

    def _hour_boundary(self, mi):
        P = self.models["BTCUSDT"]["model"]["markov"]
        row = P[self.regime]
        x = self.rng.random()
        acc, nxt = 0.0, self.regime
        for j in range(3):
            acc += row[j]
            if x <= acc:
                nxt = j
                break
        if nxt != self.regime:
            self.regime = nxt
            self.regime_hours = 0
            self._emit({"type": "regime", "regime": nxt, "name": REGIME_NAMES[nxt]})
        else:
            self.regime_hours += 1
        nus = [self.coins[s].m["nu"] for s in COINS]
        z_mkt = t_draw(self.rng, sum(nus) / len(nus))
        jumps = {}
        for sym in COINS:
            m = self.coins[sym].m
            if self.rng.random() < m["jump_lambda"] * 1.4 and m["jump_pool"]:
                j = self.rng.choice(m["jump_pool"])
                jumps[sym] = max(-14.0, min(14.0, j))  # 游戏内单小时极端跳变上限 14σ
        hod = int((self.epoch + mi * 60) // 3600) % 24
        for sym, c in self.coins.items():
            c._hour_step(self.regime, z_mkt, jumps.get(sym, 0.0), hod)
        if jumps:
            sym, mag = max(jumps.items(), key=lambda kv: abs(kv[1]))
            if abs(mag) >= 3.0:
                mood = "bull" if mag > 0 else "bear"
                tpl = self.rng.choice(NEWS_TEMPLATES[mood])
                text = tpl.format(sym=COIN_META[sym]["sym"], x=f"{self.rng.uniform(0.8, 9.6):.1f}")
                self._emit({"type": "news", "mood": mood, "text": text, "coin": sym, "mag": round(mag, 1)})

    def _emit(self, ev):
        if self._warm and ev["type"] in ("news", "regime"):
            return
        ev["id"] = self.eid
        ev["t"] = self.sim_time_str()
        self.eid += 1
        self.events.append(ev)

    def warmup(self, minutes):
        for _ in range(minutes):
            self.minute_index += 1
            self._minute(self.minute_index)

    # ---------- 查询 ----------
    def sim_time(self):
        return self.epoch + self.minute_index * 60

    def sim_time_str(self):
        return time.strftime("%m-%d %H:%M", time.localtime(self.sim_time()))

    def sim_day(self):
        return self.minute_index // 1440

    def mark_price(self, sym):
        return self.coins[sym].display_price(self.partial())

    def partial(self):
        return max(0.0, min(0.999, self.carry))

    def state_summary(self):
        out = {}
        for sym, c in self.coins.items():
            chg = (c.price / c.close0_24 - 1) * 100 if c.close0_24 else 0.0
            m = COIN_META[sym]
            out[sym] = {"price": c.price, "chg24": round(chg, 2),
                        "high24": c.hi24, "low24": c.lo24, "vol24": round(c.vol24, 0),
                        "tick": m["tick"], "lot": m["lot"], "max_lev": m["max_lev"],
                        "mmr": m["mmr"], "min_notional": m["min_notional"]}
        return out
