# -*- coding: utf-8 -*-
"""账号系统 —— 多用户注册/登录/访客 (pbkdf2_hmac 口令散列, 正式版 v1.5)

- 访客零摩擦: 首次访问自动创建访客身份 (cookie 会话), 进度完整保留
- 注册后跨设备/跨浏览器登录; 可选"继承当前访客进度"
- 密码: salt + pbkdf2_hmac('sha256', 160_000 轮) — 与主流互联网服务同级
"""
import hashlib
import hmac as _hmac
import json
import os
import secrets
import time


def _hash_pw(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 160_000).hex()


class Accounts:
    def __init__(self, path):
        self.path = path
        self.users = {}      # uid -> {"username","salt","pw_hash","created","guest"}
        self.by_name = {}    # username(lower) -> uid
        self.load()

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(self.users, f, ensure_ascii=False)

    def load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path) as f:
                    self.users = json.load(f)
                for uid, u in self.users.items():
                    if not u.get("guest"):
                        self.by_name[u["username"].lower()] = uid
            except Exception as e:
                print("[Accounts] 加载失败:", e)

    def new_uid(self, guest=True):
        return ("guest-" if guest else "u-") + secrets.token_hex(5)

    def create_guest(self) -> str:
        uid = self.new_uid()
        self.users[uid] = {"username": "游客" + uid[-4:], "guest": True, "created": time.time()}
        self.save()
        return uid

    def register(self, username: str, password: str, inherit_state_uid=None) -> str:
        username = (username or "").strip()
        if not (2 <= len(username) <= 16):
            raise ValueError("用户名需 2-16 个字符")
        if len(password or "") < 6:
            raise ValueError("密码至少 6 位")
        if username.lower() in self.by_name:
            raise ValueError("用户名已被占用")
        uid = self.new_uid(guest=False)
        salt = secrets.token_bytes(16)
        self.users[uid] = {
            "username": username, "salt": salt.hex(), "pw_hash": _hash_pw(password, salt),
            "created": time.time(), "guest": False,
        }
        self.by_name[username.lower()] = uid
        # 可选: 继承当前访客的游戏进度 (由调用方搬移 UserState)
        self.users[uid]["inherited_from"] = inherit_state_uid
        self.save()
        return uid

    def verify(self, username: str, password: str) -> str:
        uid = self.by_name.get((username or "").strip().lower())
        if not uid:
            raise ValueError("用户不存在")
        u = self.users[uid]
        salt = bytes.fromhex(u["salt"])
        if not _hmac.compare_digest(_hash_pw(password or "", salt), u["pw_hash"]):
            raise ValueError("密码错误")
        return uid
