# -*- coding: utf-8 -*-
"""Web3 赌场 —— 可证明公平小游戏平台 (v1.1)

结构:
  CrashRoom  : 全服共享的 Crash 游戏 (所有玩家同一轮, 与真实 Stake/Bustabit 一致)
               回合: 下注期(40模拟分钟) -> 飞行(倍率随模拟时间指数增长) -> 崩溃 -> 冷却(20分钟)
               崩溃点由房间级公平种子预先承诺 (开局公示哈希, 崩溃后揭示可复算)
  UserCasino : 每用户账本 —— 公平种子对 / 各游戏统计 / 返水 (rakeback) / 每日红包 / 下注历史
               资金走 web3 钱包 USDT (统一账号: 交易所 -> 钱包 -> 游戏 全链路同步)

留存机制 (对齐 Stake/BC.Game): 即时返水 0.05%×流水, 每模拟日红包 (净亏损返 1%), VIP 经验
"""
import math
import random
import secrets
import time
from collections import deque

from . import fair

CRASH_BET_MIN = 0.1
CRASH_BET_WINDOW = 40        # 模拟分钟: 下注期
CRASH_COOLDOWN = 20
CRASH_GROWTH = 9.0           # m(t) = 2^(t/9) -> 9 模拟分钟翻一倍 (60x 速度 = 9 秒)
RAKEBACK_RATE = 0.0005       # 0.05% 流水返水
DAILY_BONUS_RATE = 0.01      # 每日红包: 净亏损的 1%
DAILY_BONUS_CAP = 100.0
MIN_BET = 0.1
MAX_BET = 5000.0

BOT_NAMES = ["0xHunter", "MoonRider", "SatoshiFan", "DiamondHand", "Whale_Watch", "Sniper99",
             "TurboKid", "FOMO_Lord", "NeonWolf", "RocketPig", "CosmoTrader", "Rekt2024",
             "AlphaChad", "ZeroFeeZoe", "LedgerLuke", "GammaRay"]


def _clamp_bet(x):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return 0.0
    return x if MIN_BET <= x <= MAX_BET else 0.0


class CrashBet:
    __slots__ = ("who", "name", "amount", "auto", "cashed_at", "bot")

    def __init__(self, who, name, amount, auto, bot=False):
        self.who = who
        self.name = name
        self.amount = amount
        self.auto = float(auto) if auto else None
        self.cashed_at = None
        self.bot = bot

    def d(self):
        return {"who": self.who, "name": self.name, "amount": round(self.amount, 4),
                "auto": self.auto, "cashed_at": self.cashed_at, "bot": self.bot}


class CrashRoom:
    """共享 Crash 房间: 引擎每模拟分钟 tick 一次"""

    def __init__(self, engine_ref):
        self.engine = engine_ref
        self.room_seed = fair.SeedPair(secrets.token_hex(32), "room-" + secrets.token_hex(8))
        self.round_id = 0
        self.phase = "running"       # betting / running / cooldown
        self.phase_start = 0         # 模拟分钟
        self.crash_point = 2.0
        self.bets = {}               # uid/botkey -> CrashBet
        self.history = deque(maxlen=30)   # [{"round":, "point":, "server_seed":, "client_seed":}]
        self.mi = 0
        self.settle_fn = None        # 回调 settle_fn(who, amount, mult_or_None) —— app.py 注入
        self._new_round(0)

    # ---- 回合管理 ----
    def _new_round(self, mi):
        self.round_id += 1
        self.phase = "betting"
        self.phase_start = mi
        self.crash_point = fair.crash_point(self.room_seed.server_seed, self.room_seed.client_seed, self.round_id)
        self.bets = {}
        # 机器人造势 (真实赌场的活人气)
        for name in random.sample(BOT_NAMES, random.randint(6, 12)):
            amt = round(random.choice([0.5, 1, 2, 5, 10, 20, 50, 100]) * random.uniform(0.5, 2.0), 2)
            target = round(random.uniform(1.15, 6.0), 2)
            self.bets["bot:" + name] = CrashBet("bot:" + name, name, amt, target, bot=True)

    def mult_at(self, mi) -> float:
        t = max(0.0, mi - self.phase_start)
        return min(2 ** (t / CRASH_GROWTH), fair.CRASH_CAP)

    def on_minute(self, mi):
        self.mi = mi
        if self.phase == "betting" and mi - self.phase_start >= CRASH_BET_WINDOW:
            self.phase = "running"
            self.phase_start = mi
        elif self.phase == "running" and self.mult_at(mi) >= self.crash_point:
            self._resolve(mi)
        elif self.phase == "cooldown" and mi - self.phase_start >= CRASH_COOLDOWN:
            self._new_round(mi)

    def _resolve(self, mi):
        self.phase = "cooldown"
        self.phase_start = mi
        self.history.appendleft({
            "round": self.round_id, "point": self.crash_point,
            "server_seed": self.room_seed.server_seed, "client_seed": self.room_seed.client_seed,
            "nonce": self.round_id,
        })
        # 用户结算: 自动兑现 < 崩溃点 -> 按目标价兑现; 否则归零 (手动兑现过的已标 cashed_at)
        if self.settle_fn:
            for who, b in self.bets.items():
                if b.bot or b.cashed_at:
                    continue
                mult = None
                if b.auto and b.auto < self.crash_point:
                    mult = b.auto
                    b.cashed_at = b.auto
                try:
                    self.settle_fn(who, b.amount, mult)
                except Exception:
                    pass
        self.bets = {}

    def can_bet(self, mi) -> bool:
        return self.phase == "betting"

    def current_mult(self):
        return self.mult_at(self.mi) if self.phase == "running" else (1.0 if self.phase == "betting" else self.crash_point)

    def state(self, uid=None):
        reveal = None
        if self.phase == "cooldown" and self.history:
            reveal = self.history[0]
        bets = [b.d() for b in self.bets.values()]
        my = next((b.d() for b in self.bets.values() if b.who == uid), None)
        return {
            "round": self.round_id, "phase": self.phase,
            "mult": round(self.current_mult(), 4),
            "crash_point": self.crash_point if self.phase == "cooldown" else None,
            "hash": self.room_seed.commit_hash(),
            "left": max(0, (CRASH_BET_WINDOW if self.phase == "betting" else CRASH_COOLDOWN) -
                        (self.mi - self.phase_start)),
            "bets": bets[:24], "my": my, "history": list(self.history)[:12],
            "reveal": reveal,
            "growth": CRASH_GROWTH,
        }


class UserCasino:
    """每用户: 账本/统计/公平种子/留存"""
    def __init__(self):
        self.fair = fair.SeedPair(secrets.token_hex(32), secrets.token_hex(8))
        self.stats = {}                  # game -> {"wagered","profit","bets","best"}
        self.rakeback = 0.0
        self.bonus_day = -1              # 上次领取红包的模拟日
        self.history = deque(maxlen=60)  # 全部游戏流水
        self.mines = None                # 进行中的 mines 局
        self.last_bonus_day = -1

    # ---- 统计 ----
    def _s(self, game):
        return self.stats.setdefault(game, {"wagered": 0.0, "profit": 0.0, "bets": 0, "best": 0.0})

    def record(self, game, wager, profit, mult=None, detail=None):
        s = self._s(game)
        s["wagered"] = round(s["wagered"] + wager, 6)
        s["profit"] = round(s["profit"] + profit, 6)
        s["bets"] += 1
        if mult and mult > s["best"]:
            s["best"] = mult
        self.rakeback = round(self.rakeback + wager * RAKEBACK_RATE, 6)
        row = {"game": game, "wager": round(wager, 4), "profit": round(profit, 4),
               "mult": mult, "ts": time.time(), **(detail or {})}
        self.history.appendleft(row)
        return row

    def claim_rakeback(self) -> float:
        amt = self.rakeback
        self.rakeback = 0.0
        return amt

    def daily_bonus(self, sim_day: int, net_loss: float):
        """每模拟日一次: 有净亏损 -> 返 1% (上限 100); 否则小额安慰奖"""
        if self.last_bonus_day == sim_day:
            return 0.0, "今日已领取 (每模拟日一次)"
        self.last_bonus_day = sim_day
        if net_loss > 0:
            amt = min(round(net_loss * DAILY_BONUS_RATE, 2), DAILY_BONUS_CAP)
        else:
            amt = 0.5
        return amt, "ok"

    def snapshot(self):
        return {
            "hash": self.fair.commit_hash(),
            "client_seed": self.fair.client_seed,
            "nonce": self.fair.nonce,
            "stats": self.stats,
            "rakeback": round(self.rakeback, 4),
            "last_bonus_day": self.last_bonus_day,
            "history": list(self.history)[:24],
            "mines_active": bool(self.mines),
        }

    def to_save(self):
        return {"fair": self.fair.snapshot(), "stats": self.stats, "rakeback": self.rakeback,
                "last_bonus_day": self.last_bonus_day, "history": list(self.history)[:40]}

    @classmethod
    def from_save(cls, d):
        c = cls()
        if d.get("fair"):
            c.fair = fair.SeedPair.from_snapshot(d["fair"])
        c.stats = d.get("stats", {})
        c.rakeback = d.get("rakeback", 0.0)
        c.last_bonus_day = d.get("last_bonus_day", -1)
        for row in d.get("history", []):
            c.history.append(row)
        return c
