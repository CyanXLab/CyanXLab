# -*- coding: utf-8 -*-
"""历史数据加载与统计分析 —— 仿真引擎的'学习'模块.

对真实历史小时线做如下学习, 输出模型参数 (供 /api/model 揭秘展示):
  1. GARCH(1,1) 波动率聚集参数 (网格搜索拟合)
  2. 牛/熊/震荡 三态马尔可夫转移矩阵 (滚动168h收益标注市态)
  3. 分市态漂移与波动率
  4. 日内24小时季节性波动曲线
  5. 标准化收益的四阶峰度 -> Student-t 自由度 ν (胖尾)
  6. 跳变事件池 (|r|>4σ) 与强度 λ
  7. 相对 BTC 的相关性 β
"""
import json
import os
import numpy as np

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "BNBUSDT"]

# 交易规则参数与币安 U 本位实时规则一致 (fapi exchangeInfo + 杠杆阶梯, 2026-08 核对):
#   tick/lot = 真实 PRICE_FILTER / LOT_SIZE; max_lev = 杠杆阶梯最高档 (BTC/ETH 150x, 主流山寨 75x)
#   mmr = 一档维持保证金率 (BTC 0.4% / ETH 0.5% / 主流山寨 1%); min_notional = 最小名义价值
COIN_META = {
    "BTCUSDT":  {"name": "Bitcoin", "sym": "BTC",  "icon": "₿", "tick": 0.1,     "lot": 0.001,  "spread": 0.00008,  "depth_usd": 8e6, "color": "#f7931a", "max_lev": 150, "mmr": 0.004, "min_notional": 50},
    "ETHUSDT":  {"name": "Ethereum", "sym": "ETH", "icon": "Ξ", "tick": 0.01,    "lot": 0.001,  "spread": 0.00010,  "depth_usd": 4e6, "color": "#627eea", "max_lev": 150, "mmr": 0.005, "min_notional": 20},
    "SOLUSDT":  {"name": "Solana",  "sym": "SOL",  "icon": "◎", "tick": 0.01,    "lot": 0.01,   "spread": 0.00015,  "depth_usd": 1.6e6, "color": "#14f195", "max_lev": 75,  "mmr": 0.010, "min_notional": 5},
    "DOGEUSDT": {"name": "Dogecoin", "sym": "DOGE", "icon": "Ð", "tick": 0.00001, "lot": 1,      "spread": 0.00020,  "depth_usd": 1e6, "color": "#c2a633", "max_lev": 75,  "mmr": 0.010, "min_notional": 5},
    "BNBUSDT":  {"name": "BNB",     "sym": "BNB",  "icon": "B", "tick": 0.01,    "lot": 0.01,   "spread": 0.00010,  "depth_usd": 1.2e6, "color": "#f0b90b", "max_lev": 75,  "mmr": 0.010, "min_notional": 5},
}

HOURS_PER_YEAR = 24 * 365
REGIME_NAMES = ["牛市", "熊市", "震荡"]


def load_history(symbol):
    path = os.path.join(DATA_DIR, f"{symbol}_1h.json")
    with open(path) as f:
        d = json.load(f)
    return d["candles"], d.get("source", "unknown")


def fit_garch(r):
    """网格搜索拟合 GARCH(1,1): σ²ₜ = ω + α·r²ₜ₋₁ + β·σ²ₜ₋₁"""
    r = np.asarray(r, dtype=float)
    r2 = r ** 2
    var0 = float(np.var(r)) or 1e-10
    sample = r2[-8000:]
    best = None
    for alpha in (0.02, 0.04, 0.06, 0.09, 0.13, 0.18):
        for beta in (0.70, 0.76, 0.82, 0.88, 0.92, 0.95, 0.97):
            if alpha + beta >= 0.995:
                continue
            omega = (1 - alpha - beta) * var0
            s2 = var0
            err = 0.0
            for x in sample:
                s2 = omega + alpha * x + beta * s2
                e = x - s2
                err += e * e
            err /= len(sample)
            if best is None or err < best[0]:
                best = (err, omega, alpha, beta)
    _, omega, alpha, beta = best
    return {"omega": float(omega), "alpha": float(alpha), "beta": float(beta)}


def student_nu(r):
    """由超额峰度反解 t 分布自由度 ν: kurt = 3 + 6/(ν-4)"""
    r = np.asarray(r, dtype=float)
    x = (r - r.mean()) / (r.std() or 1e-10)
    k = float(np.mean(x ** 4))
    if k <= 3.2:
        return 30.0
    return float(min(30.0, max(3.3, 4.0 + 6.0 / (k - 3.0))))


def label_regimes(r, win=168, th=0.12):
    """滚动 win 小时累计收益标注市态: > +12% 牛市 / < -12% 熊市 / 其余震荡"""
    r = np.asarray(r, dtype=float)
    cum = np.concatenate([[0.0], np.cumsum(r)])
    labels = np.zeros(len(r), dtype=int)
    for i in range(len(r)):
        lo = max(0, i - win)
        ret = cum[i + 1] - cum[lo]
        labels[i] = 0 if ret > th else (1 if ret < -th else 2)
    return labels


def markov_matrix(labels, accel=3, floor=0.988):
    """经验转移矩阵 + 时间压缩加速 (市态平均持续 ≈ 3~4 模拟日, 保证游戏节奏)"""
    M = np.ones((3, 3)) * 0.5
    for a, b in zip(labels[:-1], labels[1:]):
        M[a][b] += 1
    M = M / M.sum(axis=1, keepdims=True)
    raw = M.copy()
    acc = M.copy()
    for i in range(3):
        p_stay = max(M[i][i] ** accel, floor)
        off_sum = 1.0 - p_stay
        raw_off_sum = 1.0 - M[i][i]
        for j in range(3):
            if j != i:
                acc[i][j] = (M[i][j] / raw_off_sum) * off_sum if raw_off_sum > 1e-9 else off_sum / 2
        acc[i][i] = p_stay
    return raw, acc


def seasonality(candles):
    """小时-of-日 波动率曲线 (归一化, 均值=1)"""
    buckets = [[] for _ in range(24)]
    for i in range(1, len(candles)):
        h = int((candles[i][0] // 3600000) % 24)
        r = abs(np.log(candles[i][4] / candles[i - 1][4]))
        buckets[h].append(r)
    means = np.array([np.mean(b) if b else 0 for b in buckets])
    g = means.mean() or 1e-10
    prof = means / g
    prof[prof < 0.4] = 0.4
    return prof / prof.mean()


def analyze_coin(candles, btc_returns=None):
    closes = np.array([c[4] for c in candles], dtype=float)
    r = np.diff(np.log(closes))
    r = r[np.abs(r) < 0.5]  # 剔除异常断点
    sigma_h = float(np.std(r))
    garch = fit_garch(r)
    nu = student_nu(r)
    labels = label_regimes(r)
    raw_m, acc_m = markov_matrix(labels)
    # 分市态漂移 / 波动
    drift, vol_r = [], []
    for k in range(3):
        seg = r[labels == k]
        drift.append(float(np.mean(seg)) if len(seg) > 20 else 0.0)
        vol_r.append(float(np.std(seg) / sigma_h) if len(seg) > 20 and sigma_h > 0 else 1.0)
    # 跳变池
    thr = 4.0 * sigma_h
    jumps = r[np.abs(r) > thr] / sigma_h
    lam = float(len(jumps) / len(r))
    # 峰度
    x = (r - r.mean()) / (sigma_h or 1e-10)
    kurt = float(np.mean(x ** 4))
    # 对 BTC 的 β
    beta = 1.0
    if btc_returns is not None and symbol_guard(candles):
        n = min(len(r), len(btc_returns))
        a, b = r[-n:], btc_returns[-n:]
        vb = float(np.var(b))
        if vb > 0:
            beta = float(np.clip(np.cov(a, b)[0][1] / vb, 0.2, 2.5))
    # ---- 游戏平衡去偏 (保留历史结构, 去除样本偏斜) ----
    # 1) 跳变池对称化: 保留跳变幅度分布, 强制正负各半 (历史窗口崩盘聚集会造成净负偏)
    jump_pool = list(np.abs(jumps)) + list(-np.abs(jumps))
    # 2) 区制漂移去偏: 平稳分布 π 加权漂移归一到 +0.002%/h (~+18%/年, 轻微牛市倾斜)
    P = np.array(acc_m, dtype=float)
    pi = np.array([1.0, 1.0, 1.0]) / 3.0
    for _ in range(300):
        pi = pi @ P
        pi = pi / pi.sum()
    target = 2e-5
    delta = float(np.dot(pi, np.array(drift))) - target
    drift = [d - delta for d in drift]
    return {
        "price0": float(closes[-1]),
        "sigma_h": sigma_h,
        "ann_vol": float(sigma_h * np.sqrt(HOURS_PER_YEAR)),
        "garch": garch,
        "nu": nu,
        "kurt": kurt,
        "labels_tail": labels[-1],
        "regime_drift": drift,
        "regime_vol": vol_r,
        "markov_raw": raw_m.tolist(),
        "markov": acc_m.tolist(),
        "season": seasonality(candles).tolist(),
        "jump_pool": jump_pool,
        "jump_lambda": lam,
        "beta_btc": beta,
        "n_samples": int(len(r)),
    }


def symbol_guard(_):
    return True


def load_all_models():
    """加载全部币种数据并学习, 返回 {symbol: candles, model} 与元信息"""
    out, meta = {}, {}
    btc_candles = None
    for sym in COINS:
        candles, src = load_history(sym)
        if sym == "BTCUSDT":
            btc_candles = candles
        out[sym] = {"candles": candles, "source": src}
    btc_r = np.diff(np.log(np.array([c[4] for c in btc_candles], dtype=float)))
    for sym in COINS:
        d = out[sym]
        d["model"] = analyze_coin(d["candles"], btc_r)
        m = d["model"]
        meta[sym] = {
            "source": d["source"],
            "n_candles": len(d["candles"]),
            "first_ts": d["candles"][0][0],
            "last_ts": d["candles"][-1][0],
            "ann_vol": m["ann_vol"],
            "kurt": m["kurt"],
            "nu": m["nu"],
            "beta_btc": m["beta_btc"],
            "garch": m["garch"],
            "jump_lambda": m["jump_lambda"],
            "n_samples": m["n_samples"],
            "price0": m["price0"],
            "markov": m["markov"],
            "regime_drift": m["regime_drift"],
            "regime_vol": m["regime_vol"],
            "season": m["season"],
            "jump_pool_n": len(m["jump_pool"]),
        }
    return out, meta
