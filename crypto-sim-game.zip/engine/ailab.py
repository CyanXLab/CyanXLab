# -*- coding: utf-8 -*-
"""AI 实验室 —— 纯 numpy 手写深度神经网络, 在线学习预测下一小时涨跌方向.

模型: 3 层 MLP (12 -> 24 -> 16 -> 1, ELU + Sigmoid), 手写反向传播 + Adam 优化器
数据: 每根收线的小时 K 线产出一条样本 (特征 -> 下小时方向), 在线增量训练
展示: loss 曲线 / 滚动准确率 / 当前预测概率 —— 让玩家亲眼看到 ML 预测长期仅 ~52-56%,
      破除"AI 能预测市场"的幻觉 (教育意义 > 信号价值)。

可选增强: 若安装了 torch (pip install torch --index-url https://download.pytorch.org/whl/cpu),
可把 USE_TORCH 打开切换为 LSTM —— 默认关闭以保持零重依赖。
"""
import random
from collections import deque

import numpy as np

USE_TORCH = False   # pip install torch 后可切换 (实验性)


def _elu(x):
    return np.where(x > 0, x, np.expm1(np.clip(x, -30, 30)))


def _dsigmoid_from_prob(p):
    return p * (1 - p)


class TinyMLP:
    def __init__(self, dims=(12, 24, 16, 1), seed=7):
        rng = np.random.default_rng(seed)
        self.W = []
        self.b = []
        for i in range(len(dims) - 1):
            fan_in, fan_out = dims[i], dims[i + 1]
            limit = np.sqrt(6.0 / (fan_in + fan_out))
            self.W.append(rng.uniform(-limit, limit, (fan_in, fan_out)))
            self.b.append(np.zeros(fan_out))
        # Adam 状态
        self.mW = [np.zeros_like(w) for w in self.W]
        self.vW = [np.zeros_like(w) for w in self.W]
        self.mb = [np.zeros_like(b) for b in self.b]
        self.vb = [np.zeros_like(b) for b in self.b]
        self.t = 0
        self.lr = 0.003

    def forward(self, X):
        """X: (N, in); 返回 (prob, cache)"""
        hiddens = []
        a = X
        for i in range(len(self.W) - 1):
            z = a @ self.W[i] + self.b[i]
            a = _elu(z)
            hiddens.append((a.copy(), z.copy() if False else None))
        z_last = a @ self.W[-1] + self.b[-1]
        p = 1.0 / (1.0 + np.exp(-np.clip(z_last, -30, 30)))
        return p, (X, hiddens)

    def train_batch(self, X, y, lr=None):
        """一个 mini-batch 的反向传播 + Adam; 返回 BCE loss"""
        p, (X0, hiddens) = self.forward(X)
        eps = 1e-7
        loss = float(-np.mean(y * np.log(p + eps) + (1 - y) * np.log(1 - p + eps)))
        N = len(X)
        # 输出层梯度 (sigmoid + BCE)
        dz = (p - y.reshape(-1, 1)) / N
        gradsW = [None] * len(self.W)
        gradsb = [None] * len(self.W)
        a_prev = hiddens[-1][0] if hiddens else X0
        gradsW[-1] = a_prev.T @ dz
        gradsb[-1] = dz.sum(axis=0)
        d = dz
        for i in range(len(self.W) - 2, -1, -1):
            a_curr = hiddens[i][0]
            a_prev = hiddens[i - 1][0] if i > 0 else X0
            da = d @ self.W[i + 1].T
            dz = da * np.where(a_curr > 0, 1, np.exp(np.clip(a_curr, -30, 30)))
            gradsW[i] = a_prev.T @ dz
            gradsb[i] = dz.sum(axis=0)
            d = dz
        # Adam 更新
        self.t += 1
        if lr:
            self.lr = lr
        b1, b2, eps = 0.9, 0.999, 1e-8
        for i in range(len(self.W)):
            for params, grads, ms, vs in ((self.W, gradsW, self.mW, self.vW), (self.b, gradsb, self.mb, self.vb)):
                g = grads[i]
                ms[i] = b1 * ms[i] + (1 - b1) * g
                vs[i] = b2 * vs[i] + (1 - b2) * (g * g)
                mh = ms[i] / (1 - b1 ** self.t)
                vh = vs[i] / (1 - b2 ** self.t)
                params[i] -= self.lr * mh / (np.sqrt(vh) + eps)
        return loss

    def predict(self, X):
        p, _ = self.forward(X)
        return p


def build_features(closes, vols=None):
    """从小时收盘价序列构造特征 (最近一行用于预测)"""
    c = np.asarray(closes, dtype=float)
    if len(c) < 40:
        return None
    r = np.diff(np.log(c))[-30:]
    feats = []
    for k in (1, 2, 3, 6, 12, 24):
        if len(r) >= k:
            feats.append(r[-k:].sum())
        else:
            feats.append(0.0)
    # 波动率特征
    for w in (6, 12, 24):
        seg = r[-w:]
        feats.append(seg.std() if len(seg) > 2 else 0.0)
    # RSI-ish
    gains = np.clip(r[-14:], 0, None).mean()
    losses = np.clip(-r[-14:], 0, None).mean()
    feats.append(gains / (gains + losses) if gains + losses > 0 else 0.5)
    # 距 24h 高低价位置
    seg = c[-25:]
    pos = (c[-1] - seg.min()) / max(seg.max() - seg.min(), 1e-9)
    feats.append(pos)
    # 连续涨跌计数
    signs = np.sign(r[-10:])
    streak = 0
    for s in signs[::-1]:
        if s == signs[-1] and s != 0:
            streak += s
        else:
            break
    feats.append(np.clip(streak / 10, -1, 1))
    return np.array(feats, dtype=float)


class AILab:
    def __init__(self):
        self.model = TinyMLP()
        self.X = deque(maxlen=3000)
        self.y = deque(maxlen=3000)
        self.loss_hist = deque(maxlen=240)
        self.acc_hist = deque(maxlen=120)
        self.last_prob = None
        self.last_hour = -1
        self.last_features = None
        self.epochs_run = 0
        self.n_samples = 0

    def on_hour_close(self, closes):
        """每收一根小时线: 补样本 + 增量训练"""
        f = build_features(closes)
        if f is None:
            return
        r_next = np.log(closes[-1] / closes[-2]) if len(closes) >= 2 else 0
        # 用"当前特征 -> 下一根方向": 特征取收线时刻, 标签为这根的方向 (滞后一步的对齐)
        if self.last_features is not None:
            self.X.append(self.last_features)
            self.y.append(1.0 if r_next > 0 else 0.0)
            self.n_samples += 1
        self.last_features = f
        self._maybe_train()
        self.last_hour += 1

    def _maybe_train(self):
        if len(self.X) < 60:
            return
        X = np.stack(list(self.X))
        y = np.array(list(self.y))
        rng = np.random.default_rng(self.epochs_run)
        losses = []
        for ep in range(24):
            idx = rng.permutation(len(X))
            for i in range(0, len(X), 64):
                b = idx[i:i + 64]
                losses.append(self.model.train_batch(X[b], y[b]))
        self.epochs_run += 24
        self.loss_hist.append(float(np.mean(losses[-8:])))
        # 滚动准确率 (最近 25% 样本, 简化: 全量内测)
        p = self.model.predict(X)
        acc = float(((p.reshape(-1) > 0.5) == (y > 0.5)).mean())
        self.acc_hist.append(acc)
        if self.last_features is not None:
            self.last_prob = float(self.model.predict(self.last_features[None, :])[0][0])

    def snapshot(self):
        return {
            "ready": len(self.X) >= 60,
            "n_samples": self.n_samples,
            "epochs": self.epochs_run,
            "loss_hist": list(self.loss_hist),
            "acc_hist": [round(a * 100, 1) for a in self.acc_hist],
            "acc_now": round(self.acc_hist[-1] * 100, 1) if self.acc_hist else None,
            "prob_up": round(self.last_prob * 100, 1) if self.last_prob is not None else None,
            "params": sum(w.size for w in self.model.W) + sum(b.size for b in self.model.b),
            "arch": "MLP 12→24→16→1 · ELU · Adam(0.003) · 在线增量训练",
        }
