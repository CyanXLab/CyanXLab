# -*- coding: utf-8 -*-
"""游戏化系统 —— XP / 等级头衔 / 成就 / 连胜 / 战绩统计 (多巴胺引擎)"""
import time
from collections import deque

LEVELS = [
    (0,     "韭菜新兵"),
    (100,   "合约新手"),
    (300,   "日内交易员"),
    (700,   "波段猎手"),
    (1500,  "稳健操盘手"),
    (3000,  "杠杆艺术家"),
    (6000,  "市场狙击手"),
    (12000, "顶级庄家"),
    (25000, "币圈传奇"),
]

ACHIEVEMENTS = [
    {"id": "first_trade", "name": "踏入赌场",  "icon": "🎯", "desc": "完成第一笔开仓"},
    {"id": "first_win",   "name": "首战告捷",  "icon": "🥇", "desc": "第一次平仓盈利"},
    {"id": "first_sl",    "name": "纪律之王",  "icon": "🛡️", "desc": "第一次触发止损（活着最重要）"},
    {"id": "win10",       "name": "小赚一笔",  "icon": "💰", "desc": "单笔收益率 ≥ +10%"},
    {"id": "win50",       "name": "以小博大",  "icon": "🚀", "desc": "单笔收益率 ≥ +50%"},
    {"id": "win200",      "name": "百倍幻想",  "icon": "👑", "desc": "单笔收益率 ≥ +200%"},
    {"id": "lev20",       "name": "胆大包天",  "icon": "🧨", "desc": "首次使用 ≥ 20x 杠杆"},
    {"id": "lev100",      "name": "贴脸开大",  "icon": "🃏", "desc": "首次使用 ≥ 100x 杠杆"},
    {"id": "streak3",     "name": "三连击",    "icon": "🔥", "desc": "连续 3 笔盈利"},
    {"id": "streak5",     "name": "五连鞭",    "icon": "⚡", "desc": "连续 5 笔盈利"},
    {"id": "streak10",    "name": "十连胜",    "icon": "🌟", "desc": "连续 10 笔盈利"},
    {"id": "double",      "name": "资金翻倍",  "icon": "📈", "desc": "权益达到 20,000 USDT"},
    {"id": "tenx",        "name": "十倍俱乐部", "icon": "💎", "desc": "权益达到 100,000 USDT"},
    {"id": "million",     "name": "百万俱乐部", "icon": "🏦", "desc": "权益达到 1,000,000 USDT"},
    {"id": "survivor",    "name": "暴跌幸存者", "icon": "🌪️", "desc": "经历 ≥5% 剧烈波动并持有仓位存活"},
    {"id": "reborn",      "name": "爆仓重生",  "icon": "🐣", "desc": "被强平后再次实现盈利平仓"},
    {"id": "short_win",   "name": "空头猎手",  "icon": "🐻", "desc": "空单收益率 ≥ +20%"},
    {"id": "day20",       "name": "日内狂人",  "icon": "☕", "desc": "单个模拟日完成 20 笔交易"},
    {"id": "maker10",     "name": "挂单艺术家", "icon": "🎨", "desc": "限价单成交累计 10 次"},
    {"id": "crash_rich",  "name": "别人恐惧我贪婪", "icon": "🦈", "desc": "在新闻利空事件后 60 分钟内开多并盈利"},
]


class Game:
    def __init__(self):
        self.xp = 0
        self.achievements = {}          # id -> ts
        self.stats = {
            "trades": 0, "wins": 0, "losses": 0, "streak": 0, "best_streak": 0,
            "profit_sum": 0.0, "loss_sum": 0.0, "peak_equity": 10000.0, "max_dd": 0.0,
            "day_trades": 0, "day": -1, "was_liquidated": False, "maker_fills": 0,
        }
        self._lazy_set = set()
        self.equity_curve = deque(maxlen=3000)   # (sim_ts, equity)
        self.trade_events = deque(maxlen=40)     # 最近平仓记录
        self.news_opportunity = {}               # coin -> sim_ts (利空后做多次数)
        # ---- 行为成瘾追踪 (四阶段: 兴奋→追逐→强迫→负强化) ----
        self.behavior = {
            "trade_marks": deque(maxlen=300),   # (sim_minute, pnl, margin)
            "chase_events": 0,                   # 追损行为次数
            "violations": 0,                     # 冷静期违规
            "liq_count": 0,
        }
        self.cold_until = -1                     # 冷静期截止 sim_minute
        self.last_close_mark = None              # (sim_minute, pnl, margin)
        # ---- 每日任务 (每日重置, 完成后由 app.py 结算奖励到余额) ----
        self.daily = {"day": -1, "list": []}
        # ---- 劳动锚定 (让虚拟资金有真实时间成本) ----
        self.labor = {
            "day": -1, "tomatos": 0, "math_done": 0,
            "earned_total": 0.0, "tomato_log": deque(maxlen=30),
            "tomato_started": None,             # (session_id, real_ts)
        }
        self.config = {"wage_cny": 30.0, "cooling": True}
        self.warnings = deque(maxlen=30)         # 追损/冷静期警告记录

    def level(self):
        lv = 0
        for i, (need, _) in enumerate(LEVELS):
            if self.xp >= need:
                lv = i
        return lv

    def level_info(self):
        lv = self.level()
        cur_need = LEVELS[lv][0]
        next_need = LEVELS[lv + 1][0] if lv + 1 < len(LEVELS) else LEVELS[lv][0] * 2
        title = LEVELS[lv][1]
        return lv, title, cur_need, next_need

    def add_xp(self, n):
        before = self.level()
        self.xp = max(0, self.xp + int(n))
        after = self.level()
        return after > before

    # ---------- 事件驱动 ----------
    def on_fill(self, ev, unlock_out):
        self._unlock("first_trade", unlock_out)
        if abs(ev.get("lev", 1)) >= 20:
            self._unlock("lev20", unlock_out)
        if abs(ev.get("lev", 1)) >= 100:
            self._unlock("lev100", unlock_out)

    # ---------- 每日任务 ----------
    DAILY_TPL = [
        {"id": "d1", "desc": "完成 3 笔平仓", "target": 3, "reward": 100},
        {"id": "d2", "desc": "单笔收益率 ≥ 20%", "target": 20, "reward": 200},
        {"id": "d3", "desc": "今日累计盈利 ≥ +300 USDT", "target": 300, "reward": 150},
        {"id": "d4", "desc": "达成 3 连胜", "target": 3, "reward": 150},
    ]

    def ensure_daily(self, sim_day):
        if self.daily.get("day") == sim_day:
            return
        self.daily = {"day": sim_day, "list": [
            {**t, "progress": 0, "done": False, "paid": False} for t in self.DAILY_TPL]}

    def _bump_daily(self, mid, value):
        for m in self.daily.get("list", []):
            if m["id"] == mid and not m["done"]:
                m["progress"] = round(max(m["progress"], value), 2)
                if m["progress"] >= m["target"]:
                    m["done"] = True

    def on_close(self, ev, unlock_out, sim_ts, sim_day):
        pnl = ev.get("pnl", 0)
        roi = ev.get("roi", 0)
        s = self.stats
        s["trades"] += 1
        if s["day"] != sim_day:
            s["day"] = sim_day
            s["day_trades"] = 0
        s["day_trades"] += 1
        if pnl >= 0:
            s["wins"] += 1
            s["streak"] += 1
            s["profit_sum"] += pnl
            s["best_streak"] = max(s["best_streak"], s["streak"])
            self.add_xp(6 + min(60, int(abs(roi) * 0.6)))
            self._unlock("first_win", unlock_out)
            if roi >= 10:
                self._unlock("win10", unlock_out)
            if roi >= 50:
                self._unlock("win50", unlock_out)
            if roi >= 200:
                self._unlock("win200", unlock_out)
            if ev.get("side", 1) == -1 and roi >= 20:
                self._unlock("short_win", unlock_out)
            if s["was_liquidated"]:
                self._unlock("reborn", unlock_out)
            if s["streak"] >= 3:
                self._unlock("streak3", unlock_out)
            if s["streak"] >= 5:
                self._unlock("streak5", unlock_out)
            if s["streak"] >= 10:
                self._unlock("streak10", unlock_out)
            if s["day_trades"] >= 20:
                self._unlock("day20", unlock_out)
            # 利空后抄底成就
            coin = ev.get("coin")
            if coin and sim_ts - self.news_opportunity.get(coin, 1e18) < 3600:
                self._unlock("crash_rich", unlock_out)
        else:
            s["losses"] += 1
            s["streak"] = 0
            s["loss_sum"] += abs(pnl)
            self.add_xp(3)
            if ev.get("reason") == "sl":
                self._unlock("first_sl", unlock_out)
        self.trade_events.appendleft({
            "coin": ev.get("coin"), "side": ev.get("side"), "lev": ev.get("lev"),
            "pnl": round(pnl, 2), "roi": roi, "reason": ev.get("reason"), "ts": sim_ts,
        })
        # 每日任务进度
        self.ensure_daily(sim_day)
        day_pnl = s["profit_sum"] - s["loss_sum"]
        self._bump_daily("d1", s["day_trades"])
        self._bump_daily("d2", roi)
        self._bump_daily("d3", max(0, day_pnl))
        self._bump_daily("d4", s["streak"])

    def on_liq(self, ev, unlock_out):
        self.stats["was_liquidated"] = True
        self.stats["streak"] = 0
        self.stats["losses"] += 1
        self.stats["loss_sum"] += abs(ev.get("loss", 0))
        self.behavior["liq_count"] += 1
        self.add_xp(5)

    # ---------- 行为追踪 ----------
    def mark_trade(self, sim_minute, pnl, margin):
        self.behavior["trade_marks"].append((sim_minute, pnl, margin))
        # 追损检测: 上笔亏损后 90 分钟内保证金放大 >= 1.5x
        prev = self.last_close_mark
        self.last_close_mark = (sim_minute, pnl, margin)
        chase = False
        if prev and prev[1] < 0 and pnl < 0 and margin >= prev[2] * 1.5 and sim_minute - prev[0] <= 90:
            self.behavior["chase_events"] += 1
            chase = True
        # 连亏 3 笔 -> 冷静期
        if self.config.get("cooling", True):
            marks = list(self.behavior["trade_marks"])[-3:]
            if len(marks) == 3 and all(m[1] < 0 for m in marks) and sim_minute >= self.cold_until:
                self.cold_until = sim_minute + 180
                return chase, "cooldown"
        return chase, None

    def violation(self):
        self.behavior["violations"] += 1
        self.warnings.append({"t": self.wage_note(), "text": "冷静期内尝试强行开仓（已记录为违规行为）"})

    def in_cold(self, sim_minute):
        return sim_minute < self.cold_until

    def stage_info(self):
        b = self.behavior
        s = self.stats
        now = getattr(self, "_now_mi", 0)
        t24 = sum(1 for m in b["trade_marks"] if now - m[0] <= 1440)
        score = 0.0
        score += min(30, t24 * 2.5)
        score += min(28, b["chase_events"] * 9)
        score += min(15, b["liq_count"] * 5)
        score += min(15, b["violations"] * 7)
        if s["streak"] <= -2 and t24 >= 5:
            score += 12
        stages = [
            (25, "兴奋期", "间歇性奖赏正带给你高多巴胺 —— 这是最危险的阶段，因为你还没疼过。试着设好止盈止损再开仓。"),
            (50, "追逐期", "检测到你亏损后加倍投入的行为模式。追逐亏损是赌博成瘾的核心特征，此时胜率通常低于直觉。"),
            (75, "强迫期", "交易频率显著异常，开仓动机已从'追求盈利'转向'缓解不交易的难受'。建议暂停，去搬砖页冷静。"),
            (101, "负强化期", "交易已被系统判定为情绪调节工具。请认真对待：真实市场中这一步之后往往是债务。"),
        ]
        for th, name, advice in stages:
            if score < th:
                return {"score": round(score, 1), "stage": name, "advice": advice,
                        "trades_24h": t24, "chase_events": b["chase_events"],
                        "liq_count": b["liq_count"], "violations": b["violations"]}
        return stages[-1]

    # ---------- 劳动锚定 ----------
    def labor_daily_reset(self, sim_day):
        if self.labor["day"] != sim_day:
            self.labor["day"] = sim_day
            self.labor["tomatos"] = 0
            self.labor["math_done"] = 0

    def wage_note(self):
        import time as _t
        return _t.strftime("%H:%M")

    def pain_hours(self, pnl_usdt):
        """亏损/盈利换算成时薪小时数 (1 USDT ≈ 7.2 CNY 模拟汇率)"""
        rate = 7.2
        per_hour_usdt = max(1.0, self.config["wage_cny"] / rate)
        return abs(pnl_usdt) / per_hour_usdt

    def on_minute(self, sim_ts, equity, regime, news, marks_move, has_position):
        s = self.stats
        s["peak_equity"] = max(s["peak_equity"], equity)
        if s["peak_equity"] > 0:
            dd = (s["peak_equity"] - equity) / s["peak_equity"]
            s["max_dd"] = max(s["max_dd"], dd)
        if len(self.equity_curve) == 0 or sim_ts - self.equity_curve[-1][0] >= 300:
            self.equity_curve.append((sim_ts, round(equity, 2)))
        if equity >= 20000:
            self._unlock_lazy("double")
        if equity >= 100000:
            self._unlock_lazy("tenx")
        if equity >= 1000000:
            self._unlock_lazy("million")
        # 幸存者: 市场剧动时持仓未爆仓
        if has_position and marks_move <= -5.0:
            self._unlock_lazy("survivor")

    def on_news(self, ev, sim_ts):
        if ev.get("mood") == "bear" and ev.get("coin"):
            self.news_opportunity[ev["coin"]] = sim_ts

    def on_maker_fill(self):
        self.stats["maker_fills"] += 1
        if self.stats["maker_fills"] >= 10:
            self._unlock_lazy("maker10")

    def flush_unlocks(self, unlock_out):
        for aid in list(self._lazy_set):
            self._unlock(aid, unlock_out)
        self._lazy_set.clear()

    def _unlock_lazy(self, aid):
        if aid not in self.achievements:
            self._lazy_set.add(aid)

    def _unlock(self, aid, out):
        if aid in self.achievements:
            return
        self.achievements[aid] = time.time()
        meta = next((a for a in ACHIEVEMENTS if a["id"] == aid), None)
        if meta:
            out.append({"type": "achievement", "aid": aid, "name": meta["name"],
                        "icon": meta["icon"], "desc": meta["desc"]})
            self.add_xp(50)

    # ---------- 快照 ----------
    def snapshot(self, equity):
        lv, title, cur, nxt = self.level_info()
        s = self.stats
        wr = s["wins"] / s["trades"] * 100 if s["trades"] else 0.0
        pf = s["profit_sum"] / s["loss_sum"] if s["loss_sum"] > 0 else (99.0 if s["profit_sum"] > 0 else 0.0)
        return {
            "xp": self.xp, "level": lv, "title": title, "xp_cur": cur, "xp_next": nxt,
            "equity": round(equity, 2),
            "roi": round((equity / 10000 - 1) * 100, 2),
            "trades": s["trades"], "wins": s["wins"], "losses": s["losses"],
            "win_rate": round(wr, 1), "streak": s["streak"], "best_streak": s["best_streak"],
            "profit_factor": round(pf, 2), "max_dd": round(s["max_dd"] * 100, 1),
            "peak": round(s["peak_equity"], 2),
            "achievements": [
                {"id": a["id"], "name": a["name"], "icon": a["icon"], "desc": a["desc"],
                 "unlocked": a["id"] in self.achievements}
                for a in ACHIEVEMENTS
            ],
            "equity_curve": list(self.equity_curve)[-500:],
            "recent_trades": list(self.trade_events)[:20],
        }
