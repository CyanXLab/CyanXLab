# -*- coding: utf-8 -*-
"""模拟公链 + DeFi —— Web3 全仿真设施 (v1.1: JSON-RPC 兼容层)

包含:
  - SimChain: 出块 (每 120 模拟分钟), mempool, tx 生命周期 (pending -> confirmed)
  - 钱包账户体系 (外部账户 EOA), 交易所热钱包充提币
  - 区块浏览器数据 (块 / 交易哈希 / 确认数 / gas)
  - AMM DEX: 恒定乘积 x*y=k, 与 CEX 价格偏差 -> 套利玩法; 模拟套利机器人缓慢搬平价差
  - 质押金库: 浮动 APY, 周期结算, 小概率"协议风险事件" (DeFi 风险教育)
  - v1.1: EIP-155 raw 交易执行 (keccak/R LP/公钥恢复), nonce/回执/日志 (eth_getLogs),
          内置合约 (CST ERC-20 + Faucet), 区块 keccak 哈希, 开发链即时出块 (anvil 语义)
"""
import hashlib
import json
import random
import time

from .crypto_core import wallet_from_mnemonic, generate_mnemonic, keccak256, rlp_encode, recover_address

GAS_FEE_USD = 0.12          # 每笔链上操作的模拟 gas 费 (USDT 计价)
BLOCK_MINUTES = 120          # 2 模拟小时一个块
CONFIRMATIONS = 3            # 充币确认块数
ARBITRAGE_SPEED = 0.15       # 套利机器人每小时搬平价差的比例
STAKE_APY_BASE = 0.12
STAKE_RISK_P = 0.004         # 每 8h 协议风险事件概率
STAKE_RISK_LOSS = 0.10
CHAIN_ID = 1337              # geth 私有开发链惯例
WEI = 10 ** 18
GAS_PRICE_WEI = 1_000_000_000        # 1 gwei
GAS_TRANSFER = 21000
GAS_CONTRACT_CALL = 48000

CST_ADDRESS = "0x" + keccak256(b"CoinSprint Token CST").hex()[-40:]
FAUCET_ADDRESS = "0x" + keccak256(b"CoinSprint Faucet").hex()[-40:]
FAUCET_AMOUNT = 1000 * WEI            # 每次领 1000 CST
FAUCET_COOLDOWN_S = 3600

# 函数选择器 (真实 keccak 签名前 4 字节)
def _sel(sig: str) -> str:
    return keccak256(sig.encode()).hex()[:8]

SEL = {
    "name": _sel("name()"),                     # 06fdde03
    "symbol": _sel("symbol()"),                 # 95d89b41
    "decimals": _sel("decimals()"),             # 313ce567
    "totalSupply": _sel("totalSupply()"),       # 18160ddd
    "balanceOf": _sel("balanceOf(address)"),    # 70a08231
    "transfer": _sel("transfer(address,uint256)"),  # a9059cbb
    "faucet": _sel("faucet()"),
}
TRANSFER_EVENT = keccak256(b"Transfer(address,address,uint256)").hex()   # 完整 32 字节事件 topic
TRANSFER_SELECTOR = _sel("transfer(address,uint256)")                     # 4 字节函数选择器 a9059cbb


def _tx_hash(payload):
    return "0x" + keccak256((json.dumps(payload, sort_keys=True, default=str) + str(time.time())).encode()).hex()


def _blk_hash(block):
    return "0x" + keccak256(rlp_encode([block["height"], block.get("parent", ""), block["ts"],
                                        "".join(block["txs"])])).hex()


def _addr_bin(a: str) -> bytes:
    try:
        return bytes.fromhex(a.lower().replace("0x", ""))
    except ValueError:
        return b""


def _pad32(data: bytes) -> bytes:
    return data + b"\x00" * (32 - len(data) % 32) if len(data) % 32 else data


def _u256(data: bytes, idx: int) -> int:
    chunk = data[idx * 32:(idx + 1) * 32]
    return int.from_bytes(chunk, "big") if len(chunk) == 32 else None


def _rlp_decode_list(raw: bytes):
    """解码 RLP 编码的顶层列表 (仅 raw tx 用): 返回字节段列表"""
    if not raw or raw[0] < 0xC0:
        raise ValueError("not a list")
    p = raw[0]
    if p < 0xF8:
        payload = raw[1:1 + (p - 0xC0)]
        i = 1
    else:
        nl = p - 0xF7
        ln = int.from_bytes(raw[1:1 + nl], "big")
        payload = raw[1 + nl:1 + nl + ln]
        i = 1 + nl
    items = []
    i = 0
    while i < len(payload):
        q = payload[i]; i += 1
        if q < 0x80:
            items.append(bytes([q]))
        elif q < 0xB8:
            items.append(payload[i:i + (q - 0x80)]); i += q - 0x80
        elif q < 0xC0:
            nl2 = q - 0xB7
            n = int.from_bytes(payload[i:i + nl2], "big"); i += nl2
            items.append(payload[i:i + n]); i += n
        else:
            raise ValueError("nested list in raw tx")
    return items


def _topic_addr(addr: str) -> str:
    """地址 -> 32 字节左填充 topic (0x + 12 个 00 + 20 字节地址)"""
    return "0x" + "0" * 24 + addr.lower().replace("0x", "")


def _abi_string(s: str) -> str:
    """ABI 编码动态 string: offset(32) + len(32) + 数据(左对齐右填充)"""
    b = s.encode()
    out = (32).to_bytes(32, "big") + len(b).to_bytes(32, "big") + b
    out += b"\x00" * ((32 - len(b) % 32) % 32)
    return "0x" + out.hex()


class SimChain:
    def __init__(self, engine_ref):
        self.engine = engine_ref            # 引用 MarketEngine 读时间/价格
        self.wallets = {}                   # user: {"eth":addr,"btc":addr,"mnemonic":...,"balances":{coin:qty},"staked":...}
        self.mempool = []
        self.blocks = []                    # [{"height","ts","txs":[hash]}]
        self._make_genesis()                # 创世块 (真实区块链语义: 链初始化即有高度 1, 重置后浏览器不再显 0)
        self.txs = {}                       # hash -> {..., "confirms": n}
        self.faucet = None
        self.stake_pool = {"usdt": 0.0, "apy": STAKE_APY_BASE}
        self.stake_accrued = 0.0
        self.risk_events = []
        # DEX 池
        self.pools = {
            "SOL/USDT": {"x": 520000.0, "y": 520000.0 * 103.0, "coin": "SOLUSDT", "lp_fee": 0.003},
            "ETH/USDT": {"x": 48000.0, "y": 48000.0 * 2437.0, "coin": "ETHUSDT", "lp_fee": 0.003},
            "DOGE/USDT": {"x": 88000000.0, "y": 88000000.0 * 0.085, "coin": "DOGEUSDT", "lp_fee": 0.003},
        }
        # ---- v1.1 JSON-RPC 状态 ----
        self.nonces = {}                    # addr(lower) -> int
        self.native_balances = {}           # addr(lower) -> wei int (非钱包 EOA/合约原生余额)
        self.receipts = {}                  # txhash -> receipt dict (仅在内存, 存档只保留块高)
        self.logs = []                      # [{address,topics,data,blockNumber,txHash,...}]
        self.contracts = {
            CST_ADDRESS.lower(): {"name": "CoinSprint Token", "symbol": "CST", "kind": "erc20",
                                   "balances": {}, "total_supply": 0},
        }
        self.faucet_last = {}               # addr -> ts
        self.raw_tx_count = 0

    def _make_genesis(self):
        """创世块: 高度 1, 空交易, parent 全零 (对齐真实公链)"""
        blk = {"height": 1, "ts": self.engine.sim_time() if self.engine else time.time(),
               "sim_str": self.engine.sim_time_str() if self.engine else "",
               "txs": [], "miner_reward": 0, "parent": "0x" + "0" * 64}
        blk["hash"] = _blk_hash(blk)
        blk["gas_used"] = 0
        self.blocks.append(blk)

    # ---------- 钱包 ----------
    def create_wallet(self):
        mn = generate_mnemonic()
        w = wallet_from_mnemonic(mn)
        wid = "user-" + hashlib.sha256(w["eth"].encode()).hexdigest()[:8]
        self.wallets[wid] = {
            "id": wid, "mnemonic": mn, "eth": w["eth"], "btc": w["btc"],
            # 测试网水龙头语义: 开号即空投体验金 (Sepolia faucet 同理), 保证开箱即可玩赌场/链上
            "balances": {"USDT": 2000.0, "SOL": 10.0, "ETH": 2.0, "DOGE": 3000.0, "BNB": 5.0},
            "staked_usdt": 0.0, "nfts": [], "created": time.time(),
            "airdropped": True,          # 空投一次性标记: 防「清空钱包→重启→再领」无限刷钱 (经济守恒)
        }
        return self.wallets[wid]

    def airdrop_if_empty(self, w):
        """老档升级: 链上钱包完全空且从未领过空投 -> 补一次体验金 (幂等 + 一次性, 防重复刷领)"""
        if w.get("airdropped"):
            return False
        b = w.get("balances", {})
        if any(v > 0 for v in b.values()):
            w["airdropped"] = True       # 有资产视为已领过, 补标记
            return False
        w["balances"] = {"USDT": 2000.0, "SOL": 10.0, "ETH": 2.0, "DOGE": 3000.0, "BNB": 5.0}
        w["airdropped"] = True
        self.submit_tx("mint", "0xFAUCET", w["eth"], 2000, coin="USDT", note="测试网空投 (水龙头)")
        return True

    # ---------- 交易 ----------
    def submit_tx(self, kind, frm, to, amount, coin="USDT", note=""):
        tx = {
            "hash": _tx_hash((kind, frm, to, amount, coin)),
            "type": kind,           # transfer / swap / stake / unstake / mint
            "from": frm, "to": to, "amount": round(amount, 8), "coin": coin,
            "fee": GAS_FEE_USD, "note": note,
            "ts": time.time(), "block": None, "confirms": 0,
            "sim_str": self.engine.sim_time_str(),
        }
        self.mempool.append(tx)
        self.txs[tx["hash"]] = tx
        return tx

    def on_minute(self, sim_minute):
        if sim_minute % BLOCK_MINUTES != 0:
            return
        height = len(self.blocks) + 1
        packed = self.mempool[:64]
        self.mempool = self.mempool[64:]
        block = {"height": height, "ts": self.engine.sim_time(), "sim_str": self.engine.sim_time_str(),
                 "txs": [t["hash"] for t in packed], "miner_reward": 0.5,
                 "parent": self.blocks[-1].get("hash", "0x" + "0" * 64) if self.blocks else "0x" + "0" * 64}
        block["hash"] = _blk_hash(block)
        block["gas_used"] = GAS_TRANSFER * len(packed)
        self.blocks.append(block)
        for t in packed:
            t["block"] = height
            t["confirms"] = 1
        for t in self.txs.values():
            if t.get("block") is not None:
                t["confirms"] = min(CONFIRMATIONS, t.get("confirms", CONFIRMATIONS) + 1)

    # ---------- v1.1: 地址余额统一视图 (钱包 EOA / 外部 EOA / 合约) ----------
    def _wallet_by_addr(self, addr: str):
        a = (addr or "").lower()
        for w in self.wallets.values():
            if w["eth"].lower() == a:
                return w
        return None

    def native_balance_wei(self, addr: str) -> int:
        w = self._wallet_by_addr(addr)
        if w:
            return int(round(w["balances"].get("USDT", 0.0) * WEI))
        return self.native_balances.get((addr or "").lower(), 0)

    def _native_debit(self, addr: str, wei: int, dry=False):
        """扣原生币: 钱包 EOA 扣 USDT 余额; 外部 EOA 扣 native_balances"""
        w = self._wallet_by_addr(addr)
        if w:
            need = wei / WEI
            if w["balances"].get("USDT", 0.0) + 1e-9 < need:
                return False
            if not dry:
                w["balances"]["USDT"] = w["balances"].get("USDT", 0.0) - need
            return True
        a = (addr or "").lower()
        if self.native_balances.get(a, 0) < wei:
            return False
        if not dry:
            self.native_balances[a] -= wei
        return True

    def _native_credit(self, addr: str, wei: int):
        w = self._wallet_by_addr(addr)
        if w:
            w["balances"]["USDT"] = w["balances"].get("USDT", 0.0) + wei / WEI
            return
        a = (addr or "").lower()
        self.native_balances[a] = self.native_balances.get(a, 0) + wei

    def nonce_of(self, addr: str) -> int:
        return self.nonces.get((addr or "").lower(), 0)

    def _emit_log(self, address, topics, data_hex, tx_hash, height):
        self.logs.append({"address": address.lower(), "topics": topics,
                          "data": data_hex, "blockNumber": height,
                          "transactionHash": tx_hash, "blockHash": self.blocks[-1]["hash"] if self.blocks else "0x" + "0" * 64})
        if len(self.logs) > 2000:
            self.logs = self.logs[-1000:]

    def _mine_block(self, tx_hashes):
        """开发链语义: raw tx 即刻出块 (同 anvil/ganache auto-mine)"""
        height = len(self.blocks) + 1
        block = {"height": height, "ts": self.engine.sim_time(), "sim_str": self.engine.sim_time_str(),
                 "txs": list(tx_hashes), "miner_reward": 0.5,
                 "parent": self.blocks[-1].get("hash", "0x" + "0" * 64) if self.blocks else "0x" + "0" * 64,
                 "gas_used": GAS_TRANSFER * len(tx_hashes), "rpc": True}
        block["hash"] = _blk_hash(block)
        self.blocks.append(block)
        for h in tx_hashes:
            t = self.txs.get(h)
            if t:
                t["block"] = height
                t["confirms"] = min(CONFIRMATIONS, t.get("confirms", 0) + 1)
        return block

    def execute_raw_tx(self, raw_hex: str):
        """执行 EIP-155 签名交易 (dev-chain 即时出块, anvil 语义).
        支持: 原生转账 / CST ERC-20 transfer / faucet 领水. 返回 (ok, tx_hash 或错误信息)"""
        try:
            raw = bytes.fromhex(raw_hex[2:] if raw_hex.startswith("0x") else raw_hex)
            fields = _rlp_decode_list(raw)
            if len(fields) != 9:
                return False, "invalid raw tx fields"
            nonce = int.from_bytes(fields[0], "big")
            gas_price = int.from_bytes(fields[1], "big")
            gas = int.from_bytes(fields[2], "big")
            to_b = fields[3]
            value = int.from_bytes(fields[4], "big")
            data = fields[5]
            v = int.from_bytes(fields[6], "big")
            r = int.from_bytes(fields[7], "big")
            s = int.from_bytes(fields[8], "big")
            if v < 35:
                return False, "only EIP-155 transactions supported"
            chain_id, recid = (v - 35) // 2, (v - 35) % 2
            if chain_id != CHAIN_ID:
                return False, f"wrong chainId {chain_id} (expect {CHAIN_ID})"
            unsigned = fields[:6] + [chain_id.to_bytes((chain_id.bit_length() + 7) // 8, "big"), b"", b""]
            digest = keccak256(rlp_encode(unsigned))
            sender = recover_address(digest, r, s, recid)
            if not sender:
                return False, "signature recovery failed"
            sender = sender.lower()
            if nonce != self.nonce_of(sender):
                return False, f"nonce mismatch (have {self.nonce_of(sender)}, got {nonce})"
            if gas_price < GAS_PRICE_WEI:
                return False, f"gasPrice below floor ({GAS_PRICE_WEI} wei)"
            gas_cost = gas * gas_price
            if gas > GAS_CONTRACT_CALL:
                return False, "intrinsic gas too high"
            to = ("0x" + to_b.hex()) if to_b else ""
            sel = data[:4].hex() if len(data) >= 4 else ""
            kind = "transfer"
            extra_logs = []
            transfer_amount = value
            # ---- 合约调用分派 ----
            if to.lower() == CST_ADDRESS.lower() and sel:
                if sel != SEL["transfer"]:
                    return False, "unknown selector 0x" + sel + " (support: transfer(address,uint256))"
                if len(data) != 68:
                    return False, "bad ABI data"
                rcpt = "0x" + data[16:36].hex()
                amount = int.from_bytes(data[36:68], "big")
                tok = self.contracts[CST_ADDRESS.lower()]
                if tok["balances"].get(sender, 0) < amount:
                    return False, "ERC-20: transfer amount exceeds balance"
                kind = "erc20_transfer"
                transfer_amount = 0
                extra_logs = [(CST_ADDRESS.lower(),
                               ["0x" + TRANSFER_EVENT, _topic_addr(sender), _topic_addr(rcpt)],
                               "0x" + amount.to_bytes(32, "big").hex())]
                tok["balances"][sender] = tok["balances"][sender] - amount
                tok["balances"][rcpt.lower()] = tok["balances"].get(rcpt.lower(), 0) + amount
            elif to.lower() == FAUCET_ADDRESS.lower() and sel:
                if sel != SEL["faucet"]:
                    return False, "unknown selector 0x" + sel + " (support: faucet())"
                last = self.faucet_last.get(sender, 0)
                if time.time() - last < FAUCET_COOLDOWN_S:
                    remain = int(FAUCET_COOLDOWN_S - (time.time() - last))
                    return False, f"faucet cooldown ({remain}s)"
                self.faucet_last[sender] = time.time()
                tok = self.contracts[CST_ADDRESS.lower()]
                tok["balances"][sender] = tok["balances"].get(sender, 0) + FAUCET_AMOUNT
                tok["total_supply"] += FAUCET_AMOUNT
                kind = "faucet"
                transfer_amount = 0
            # ---- 余额检查 (gas + value) ----
            if not self._native_debit(sender, gas_cost + transfer_amount, dry=True):
                return False, "insufficient funds for value + gas"
            self._native_debit(sender, gas_cost + transfer_amount)
            if transfer_amount and to:
                self._native_credit(to, transfer_amount)
            self.nonces[sender] = nonce + 1
            tx_hash = "0x" + keccak256(raw).hex()
            self._register_rpc_tx(tx_hash, sender, to, transfer_amount, kind)
            self._finalize_rpc_tx(tx_hash, gas, ok=True)
            for (addr, topics, data_hex) in extra_logs:
                self._emit_log(addr, topics, data_hex, tx_hash, len(self.blocks) + 1)
            self._mine_block([tx_hash])
            self.raw_tx_count += 1
            return True, tx_hash
        except Exception as e:
            return False, f"bad raw tx: {e}"

    def _register_rpc_tx(self, tx_hash, frm, to, value, kind, value_unit="wei"):
        self.txs[tx_hash] = {"hash": tx_hash, "type": kind, "from": frm, "to": to,
                             "amount": round(value / WEI, 8), "coin": "USDT" if value_unit == "wei" else kind,
                             "fee": 0.0, "note": "JSON-RPC raw tx", "ts": time.time(),
                             "block": None, "confirms": 0, "sim_str": self.engine.sim_time_str()}

    def _finalize_rpc_tx(self, tx_hash, gas_used, ok=True):
        self.receipts[tx_hash] = {"status": 1 if ok else 0, "gasUsed": gas_used,
                                  "effectiveGasPrice": GAS_PRICE_WEI,
                                  "blockNumber": len(self.blocks) + 1, "from": self.txs[tx_hash]["from"],
                                  "to": self.txs[tx_hash]["to"], "transactionHash": tx_hash}

    def erc20_balance(self, addr: str) -> int:
        return self.contracts[CST_ADDRESS.lower()]["balances"].get((addr or "").lower(), 0)

    def eth_call_cst(self, data_hex: str, caller="0x" + "0" * 40) -> str:
        """eth_call 对 CST 合约: 返回 ABI 编码结果 (0x hex)"""
        try:
            data = bytes.fromhex(data_hex[2:] if data_hex.startswith("0x") else data_hex)
            if len(data) < 4:
                return "0x"
            sel = data[:4].hex()
            tok = self.contracts[CST_ADDRESS.lower()]
            if sel == SEL["name"]:
                return _abi_string("CoinSprint Token")
            if sel == SEL["symbol"]:
                return _abi_string("CST")
            if sel == SEL["decimals"]:
                return "0x" + (18).to_bytes(32, "big").hex()
            if sel == SEL["totalSupply"]:
                return "0x" + tok["total_supply"].to_bytes(32, "big").hex()
            if sel == SEL["balanceOf"] and len(data) >= 36:
                a = "0x" + data[16:36].hex()      # 4 字节选择器 + 12 字节填充 -> 地址在 16:36
                return "0x" + self.erc20_balance(a).to_bytes(32, "big").hex()
            return "0x"
        except Exception:
            return "0x"

    def wallet_balance(self, wid, coin="USDT"):
        w = self.wallets.get(wid)
        if not w:
            return 0.0
        return w["balances"].get(coin, 0.0)

    def explorer_recent(self, n=12):
        recent = sorted(self.txs.values(), key=lambda t: t["ts"], reverse=True)
        return recent[:n]

    # ---------- AMM DEX ----------
    def pool_price(self, pair):
        p = self.pools[pair]
        return p["y"] / p["x"]

    def swap_quote(self, pair, amount_in, direction):
        """direction: 'coin_to_usdt' 或 'usdt_to_coin'; 返回 (amount_out, price_effective, fee)"""
        p = self.pools[pair]
        f = p["lp_fee"]
        if direction == "coin_to_usdt":
            x_in = amount_in
        else:
            x_in = amount_in  # usdt 计为 y 输入 -> 输出 coin; 用对称公式处理
        if direction == "coin_to_usdt":
            amount_out = (p["y"] * x_in * (1 - f)) / (p["x"] + x_in * (1 - f))
            eff = amount_out / x_in
            return amount_out, eff, x_in * f
        else:
            amount_out = (p["x"] * amount_in * (1 - f)) / (p["y"] + amount_in * (1 - f))
            eff = amount_in / amount_out if amount_out > 0 else 0
            return amount_out, eff, amount_in * f

    def swap(self, pair, amount_in, direction):
        p = self.pools[pair]
        if direction == "coin_to_usdt":
            out, eff, fee = self.swap_quote(pair, amount_in, direction)
            p["x"] += amount_in
            p["y"] -= out
            return out, eff, fee
        else:
            out, eff, fee = self.swap_quote(pair, amount_in, direction)
            p["y"] += amount_in
            p["x"] -= out
            return out, eff, fee

    def arbitrage_tick(self, cex_prices):
        """套利机器人每小时搬平 DEX 与 CEX 价差 (创造可抢跑窗口)"""
        for pair, p in self.pools.items():
            cex = cex_prices.get(p["coin"])
            if not cex:
                continue
            dex = p["y"] / p["x"]
            gap = (dex - cex) / cex
            if abs(gap) < 0.0004:
                continue
            move = ARBITRAGE_SPEED * gap
            # 调整池子把 dex 价拉向 cex
            if gap > 0:   # dex 偏贵 -> 卖 coin 进池 (x 增 y 减)
                dx = p["x"] * move / (1 - move)
                p["x"] += dx
                p["y"] -= p["y"] * move
            else:         # dex 偏便宜 -> 买 coin (y 增 x 减)
                dy = p["y"] * (-move) / (1 - (-move))
                p["y"] += dy
                p["x"] -= p["x"] * (-move)

    # ---------- 质押 ----------
    def stake(self, wid, amount):
        w = self.wallets[wid]
        amount = round(float(amount), 2)
        if amount < 10:
            return False, "最低质押 10 USDT"
        if w["balances"].get("USDT", 0) < amount:
            return False, "钱包 USDT 不足"
        w["balances"]["USDT"] -= amount
        w["staked_usdt"] += amount
        self.stake_pool["usdt"] += amount
        self.submit_tx("stake", w["eth"], "0xSTAKE_POOL", amount, note="质押挖矿")
        return True, "ok"

    def unstake(self, wid, amount=None):
        w = self.wallets[wid]
        amt = min(w["staked_usdt"], amount if amount else w["staked_usdt"])
        if amt <= 0:
            return False, "无质押"
        w["staked_usdt"] -= amt
        w["balances"]["USDT"] = w["balances"].get("USDT", 0) + amt
        self.stake_pool["usdt"] -= amt
        self.submit_tx("unstake", "0xSTAKE_POOL", w["eth"], amt, note="赎回质押")
        return True, "ok"

    def stake_settle(self):
        """每 8 模拟小时结算一次利息"""
        total = self.stake_pool["usdt"]
        if total <= 0:
            return
        apy = self.stake_pool["apy"]
        interest = total * apy / (365 * 3)
        # 8h = 1/3 天
        for w in self.wallets.values():
            if w["staked_usdt"] > 0:
                gain = w["staked_usdt"] * apy / (365 * 3)
                w["staked_usdt"] += gain
        self.stake_pool["usdt"] += interest
        # 协议风险事件
        if random.random() < STAKE_RISK_P:
            loss = STAKE_RISK_LOSS
            for w in self.wallets.values():
                w["staked_usdt"] *= (1 - loss)
            self.stake_pool["usdt"] *= (1 - loss)
            self.risk_events.append({"t": self.engine.sim_time_str(), "loss": loss * 100})
            return {"risk": True, "loss_pct": loss * 100}
        return None

    # ---------- 快照 ----------
    def snapshot(self, wid=None, cex_prices=None):
        d = {
            "has_wallet": wid in self.wallets if wid else False,
            "wallet": None, "mempool_n": len(self.mempool),
            "height": len(self.blocks), "txs": self.explorer_recent(14),
            "pools": {pair: {"price": p["y"] / p["x"], "x": p["x"], "y": p["y"],
                             "cex": (cex_prices or {}).get(p["coin"]),
                             "gap_pct": round(((p["y"] / p["x"]) / (cex_prices or {}).get(p["coin"], p["y"] / p["x"]) - 1) * 100, 3)}
                      for pair, p in self.pools.items()},
            "stake_apy": round(self.stake_pool["apy"] * 100, 2),
            "stake_pool": round(self.stake_pool["usdt"], 2),
            "risk_events": self.risk_events[-5:],
            "confirmations": CONFIRMATIONS, "block_minutes": BLOCK_MINUTES,
        }
        w = self.wallets.get(wid) if wid else None
        if w:
            cex = cex_prices or {}
            total = w["balances"].get("USDT", 0.0)
            assets = []
            for coin, qty in w["balances"].items():
                if coin == "USDT" or qty <= 0:
                    continue
                px = cex.get(coin + "USDT", 0)          # 修复: cex_prices 键为 sym (ETHUSDT), 原 cex[s] 用裸名取 -> KeyError 500
                if not px and (coin + "/USDT") in self.pools:
                    p0 = self.pools[coin + "/USDT"]           # 桥接代币: 按 DEX 池价估值
                    px = p0["y"] / p0["x"] if p0["x"] else 0
                val = qty * (px or 0)
                total += val
                assets.append({"coin": coin, "qty": round(qty, 6), "price": px, "value": round(val, 2)})
            d["wallet"] = {
                "id": w["id"], "eth": w["eth"], "btc": w["btc"],
                "balances": {k: round(v, 6) for k, v in w["balances"].items()},
                "assets": assets, "total_usd": round(total, 2),
                "staked_usdt": round(w["staked_usdt"], 2),
                "nfts": w["nfts"],
                "mnemonic": w["mnemonic"],   # 前端仅在"备份"时展示
            }
        return d


# faucet: 交易所热钱包地址
HOT_WALLET = "0x0000d8cA0F1eB4cAfeD8a9C0fF00000000000001"
