# -*- coding: utf-8 -*-
"""用户级开放 API —— 每个账号可签发 API Key, 用程序替代 UI 完成几乎所有操作 (正式版 v1.1)

与 DevPlatform (外部游戏桥接) 并列: DevPlatform 服务"别的游戏", UserApiKeys 服务
"本平台玩家自己的程序化交易 / 外部 web3 软件接入".

鉴权 (对齐币安 REST API 惯例):
  X-API-KEY / X-TIMESTAMP / X-SIGNATURE
  signature = HMAC_SHA256(api_secret, "{METHOD}\\n{PATH}\\n{TIMESTAMP}\\n{BODY}") 的 hex
  BODY: POST/DELETE 为原始 JSON 串, GET 为空串
  时间戳窗口 ±120s (真实服务器时间); 限流 120 req/min/key

覆盖能力 (几乎所有 UI 功能都有 API 等价物):
  公开: ping / time / meta / exchangeInfo / ticker / klines / depth / leaderboard
  私有: account / positions / orders / history / income / wallet
        order (下/撤单) / order/close (平仓) / spot/order (现货)
        transfer (跨账号站内划转) / wallet/send (链上转账)
        games (赌场) / games/dice (下注) / games/fair (公平种子)
"""
import hashlib
import hmac
import json
import os
import secrets
import time

RATE_LIMIT_PER_MIN = 120
TS_WINDOW = 120
MAX_KEYS_PER_USER = 3


class UserApiError(Exception):
    def __init__(self, code, msg, http=400):
        super().__init__(msg)
        self.code = code
        self.msg = msg
        self.http = http


class UserApiKeys:
    def __init__(self):
        self.keys = {}        # api_key -> {uid, api_secret, created, label, last_used}
        self._rate = {}       # api_key -> [window_start, count]
        self.path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                 "instance", "userkeys.json")
        self.load()

    # ---------- 持久化 (独立于游戏存档, reset 不影响 API Key) ----------
    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(self.keys, f, ensure_ascii=False)

    def load(self):
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path) as f:
                self.keys = json.load(f)
        except Exception as e:
            print("[UserApiKeys] 加载失败, 使用全新密钥表:", e)

    # ---------- 管理 ----------
    def list_for(self, uid):
        out = []
        for k, v in self.keys.items():
            if v["uid"] == uid:
                out.append({"api_key": k, "api_secret": v["api_secret"], "label": v.get("label", ""),
                            "created": v["created"], "last_used": v.get("last_used", 0)})
        return sorted(out, key=lambda x: -x["created"])

    def create(self, uid, label=""):
        mine = [k for k, v in self.keys.items() if v["uid"] == uid]
        if len(mine) >= MAX_KEYS_PER_USER:
            raise UserApiError(-1100, f"每账号最多 {MAX_KEYS_PER_USER} 把 API Key, 请先吊销旧的")
        label = (label or "").strip()[:20]
        key = "uk_" + secrets.token_hex(12)
        secret = "us_" + secrets.token_hex(24)
        self.keys[key] = {"uid": uid, "api_secret": secret, "created": time.time(),
                          "label": label, "last_used": 0}
        self.save()
        return self.keys[key] | {"api_key": key}

    def revoke(self, uid, api_key):
        v = self.keys.get(api_key)
        if not v or v["uid"] != uid:
            raise UserApiError(-2015, "API Key 不存在或不属于当前账号", 404)
        self.keys.pop(api_key)
        self.save()
        return True

    def owner_uid(self, api_key):
        v = self.keys.get(api_key or "")
        if not v:
            raise UserApiError(-2015, "无效的 API-Key (API key 无效)", 401)
        return v["uid"]

    # ---------- 鉴权 / 限流 ----------
    def check_rate(self, api_key):
        now = time.time()
        win = self._rate.get(api_key)
        if not win or now - win[0] >= 60:
            self._rate[api_key] = [now, 1]
            return
        win[1] += 1
        if win[1] > RATE_LIMIT_PER_MIN:
            raise UserApiError(-2112, f"触发限流 ({RATE_LIMIT_PER_MIN} req/min)", 429)

    def verify(self, method, path, timestamp, sig, body_str, api_key) -> str:
        """返回 key 所属 uid; 校验失败抛 UserApiError"""
        self.check_rate(api_key)
        v = self.keys.get(api_key or "")
        if not v:
            raise UserApiError(-2015, "无效的 API-Key (API key 无效)", 401)
        try:
            ts = int(float(timestamp))
        except (TypeError, ValueError):
            raise UserApiError(-1100, "时间戳缺失/非法 (Mandatory parameter 'timestamp' was not sent)", 400)
        if abs(time.time() * 1000 - ts) > TS_WINDOW * 1000 and abs(time.time() - ts) > TS_WINDOW:
            raise UserApiError(-1021, "时间戳超出同步窗口 (Timestamp for this request is outside of the recvWindow)")
        expect = hmac.new(v["api_secret"].encode(),
                          f"{method}\n{path}\n{timestamp}\n{body_str}".encode(),
                          hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expect, (sig or "").lower()):
            raise UserApiError(-1022, "签名不匹配 (Signature for this request is not valid)")
        v["last_used"] = time.time()
        return v["uid"]

    @staticmethod
    def meta():
        return {
            "name": "CoinSprint User Open API", "version": "v1",
            "auth": "HMAC-SHA256(X-API-KEY / X-TIMESTAMP / X-SIGNATURE)",
            "sign_string": "{METHOD}\\n{PATH}\\n{TIMESTAMP}\\n{BODY}",
            "recv_window_sec": TS_WINDOW, "rate_limit_per_min": RATE_LIMIT_PER_MIN,
            "endpoints": [
                "GET  /open/v1/ping                     # 公开",
                "GET  /open/v1/time                     # 公开",
                "GET  /open/v1/meta                     # 公开: 全部端点自描述",
                "GET  /open/v1/exchangeInfo             # 公开: 交易规则 (tick/lot/杠杆/MMR)",
                "GET  /open/v1/ticker?coin=BTCUSDT      # 公开: 最新价/24h 统计",
                "GET  /open/v1/klines?coin=&interval=1m&limit=320   # 公开: K 线",
                "GET  /open/v1/depth?coin=BTCUSDT       # 公开: 盘口",
                "GET  /open/v1/leaderboard              # 公开: 全服排行榜",
                "GET  /open/v1/account                  # 私有: 余额/权益/钱包/赌场",
                "GET  /open/v1/positions                # 私有: 当前持仓",
                "GET  /open/v1/orders                   # 私有: 挂单/触发单/平仓单/现货单",
                "GET  /open/v1/history?limit=30         # 私有: 成交战绩",
                "GET  /open/v1/income                   # 私有: 手续费/资金费累计",
                "GET  /open/v1/wallet                   # 私有: 链上钱包",
                "POST /open/v1/order    {coin,side,type,margin,leverage,price,trigger,tp_pct,sl_pct}",
                "POST /open/v1/order/close {position_id, fraction}",
                "POST /open/v1/spot/order {coin,side,type,usdt,price}",
                "POST /open/v1/transfer {to_username, amount, note}   # 跨账号站内划转",
                "POST /open/v1/wallet/send {to, amount, note}         # 链上转账 (0x 地址)",
                "POST /open/v1/games/dice {amount, target, direction} # 赌场下注",
            ],
        }
