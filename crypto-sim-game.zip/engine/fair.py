# -*- coding: utf-8 -*-
"""可证明公平 (Provably Fair) 引擎 —— 与 Stake.com 同源算法, 全部可独立复算.

规范 (来自 stake.us 官方公平性文档):
  bytes = HMAC_SHA256(key=server_seed, msg=client_seed:nonce)
  每 4 字节 -> float = b0/256 + b1/256^2 + b2/256^3 + b3/256^4 ∈ [0, 1)
  游戏结果全部由这些 float 确定性推导 —— 玩家可在种子公开后 100% 复算。

游戏:
  Dice   : roll = floor(float*10001)/100 -> 0.00 ~ 100.00, 赔率 = 99/胜率 (1% 边缘)
  Crash  : crash = floor((100*2^52 - h) / (2^52 - h)) / 100, h%33==0 -> 1.00x 秒崩 (1% 边缘)
  Mines  : Fisher-Yates 用 float 洗牌布雷; 倍率 = 0.99 * C(25,k) / C(25-m,k)
  Plinko : 每行一个 bit (float<0.5 -> 左), 落入桶 = 二项分布; 桶表与 Stake 16/12/8 行一致
"""
import hashlib
import hmac
import math

HOUSE_EDGE = 0.99          # 1% 房屋边缘 (与 Stake Originals 一致)
CRASH_E = 2 ** 52
CRASH_CAP = 1_000_000.0


# ---------------- 种子对 ----------------
class SeedPair:
    """一对 (server_seed, client_seed) + nonce 计数器.

    开局前公布 sha256(server_seed) 承诺; 旋转时揭示 server_seed 供玩家复算历史.
    """

    def __init__(self, server_seed: str, client_seed: str, nonce: int = 0):
        self.server_seed = server_seed
        self.client_seed = client_seed
        self.nonce = int(nonce)

    def commit_hash(self) -> str:
        """开局前公示的承诺: sha256(server_seed)"""
        return hashlib.sha256(self.server_seed.encode()).hexdigest()

    def next_nonce(self) -> int:
        self.nonce += 1
        return self.nonce

    def snapshot(self):
        return {"server_seed": self.server_seed, "client_seed": self.client_seed, "nonce": self.nonce}

    @classmethod
    def from_snapshot(cls, d):
        return cls(d["server_seed"], d.get("client_seed", ""), d.get("nonce", 0))


def game_bytes(server_seed: str, client_seed: str, nonce: int) -> bytes:
    """HMAC_SHA256(server_seed, 'client_seed:nonce') -> 32 字节"""
    msg = f"{client_seed}:{nonce}".encode()
    return hmac.new(server_seed.encode(), msg, hashlib.sha256).digest()


def floats(server_seed: str, client_seed: str, nonce: int, n: int) -> list:
    """n 个 [0,1) 浮点 (Stake 标准: 每 4 字节一个).
    每轮 HMAC 产出 8 个; 不够时轮次 r 追加: msg = 'client:nonce:r' (确定性可复算)."""
    out = []
    r = 0
    while len(out) < n:
        b = game_bytes(server_seed, client_seed, nonce) if r == 0 else \
            hmac.new(server_seed.encode(), f"{client_seed}:{nonce}:{r}".encode(), hashlib.sha256).digest()
        for i in range(0, 32, 4):
            if len(out) >= n:
                break
            c = b[i:i + 4]
            out.append(c[0] / 256 + c[1] / 256**2 + c[2] / 256**3 + c[3] / 256**4)
        r += 1
    return out


# ---------------- Dice ----------------
def dice_roll(server_seed: str, client_seed: str, nonce: int) -> float:
    """roll ∈ {0.00, 0.01, ..., 100.00}: floor(float*10001)/100"""
    f = floats(server_seed, client_seed, nonce, 1)[0]
    return math.floor(f * 10001) / 100.0


def dice_mult(target: float, direction: str) -> tuple:
    """返回 (胜率%, 倍率). under: roll<target 胜; over: roll>target 胜"""
    if direction == "under":
        chance = max(2.0, min(98.0, float(target)))
    else:
        chance = max(2.0, min(98.0, 100.0 - float(target)))
    return chance, round(HOUSE_EDGE * 100.0 / chance, 6)


# ---------------- Crash ----------------
def crash_point(server_seed: str, client_seed: str, nonce: int) -> float:
    """bustabit/Stake 公式: h = 52bit 整数
    h % 33 == 0 -> 1.00x (秒崩); 否则 floor((100*E - h)/(E - h))/100, 封顶 1e6"""
    raw = game_bytes(server_seed, client_seed, nonce)
    h = int.from_bytes(raw[:7], "big") >> 4          # 52 bit
    if h % 33 == 0:
        return 1.00
    cp = math.floor((100 * CRASH_E - h) / (CRASH_E - h)) / 100.0
    return min(max(cp, 1.0), CRASH_CAP)


# ---------------- Mines ----------------
def mines_layout(server_seed: str, client_seed: str, nonce: int, n_mines: int) -> list:
    """Fisher-Yates 洗牌布雷 (float 驱动), 返回雷的格号列表 (0~24)"""
    f = floats(server_seed, client_seed, nonce, 24)
    deck = list(range(25))
    for i in range(n_mines):
        j = i + int(f[i] * (25 - i)) % (25 - i)
        deck[i], deck[j] = deck[j], deck[i]
    return sorted(deck[:n_mines])


def mines_mult(n_mines: int, picks: int) -> float:
    """倍率 = 0.99 * C(25,k) / C(25-m,k)"""
    if picks <= 0 or n_mines <= 0 or n_mines >= 25:
        return 0.0
    p = math.comb(25 - n_mines, picks) / math.comb(25, picks)
    return round(HOUSE_EDGE / p, 6)


# ---------------- Plinko ----------------
def plinko_path(server_seed: str, client_seed: str, nonce: int, rows: int) -> list:
    """每行一个 bit: float<0.5 -> 0(左), 否则 1(右); 桶号 = sum(bits)"""
    f = floats(server_seed, client_seed, nonce, rows)
    return [0 if x < 0.5 else 1 for x in f[:rows]]


PLINKO_TABLES = {
    16: {
        "low":    [16, 9, 2, 1.4, 1.4, 1.2, 1.1, 1, 0.5, 1, 1.1, 1.2, 1.4, 1.4, 2, 9, 16],
        "medium": [110, 41, 10, 5, 3, 1.5, 1, 0.5, 0.3, 0.5, 1, 1.5, 3, 5, 10, 41, 110],
        "high":   [1000, 130, 26, 9, 4, 2, 0.2, 0.2, 0.2, 0.2, 0.2, 2, 4, 9, 26, 130, 1000],
    },
    12: {
        "low":    [10, 3, 1.6, 1.4, 1.1, 1, 0.5, 1, 1.1, 1.4, 1.6, 3, 10],
        "medium": [33, 11, 4, 2, 1.1, 0.6, 0.3, 0.6, 1.1, 2, 4, 11, 33],
        "high":   [170, 24, 8.1, 2, 0.7, 0.2, 0.2, 0.2, 0.7, 2, 8.1, 24, 170],
    },
    8: {
        "low":    [5.6, 2.1, 1.1, 1, 0.5, 1, 1.1, 2.1, 5.6],
        "medium": [13, 3, 1.3, 0.7, 0.4, 0.7, 1.3, 3, 13],
        "high":   [29, 4, 1.5, 0.3, 0.2, 0.3, 1.5, 4, 29],
    },
}


def plinko_bucket(path: list) -> int:
    return sum(path)


def plinko_mult(rows: int, risk: str, bucket: int) -> float:
    return PLINKO_TABLES[rows][risk][bucket]


# ---------------- 复算/验证 ----------------
def verify_dice(server_seed, client_seed, nonce, target, direction):
    roll = dice_roll(server_seed, client_seed, nonce)
    chance, mult = dice_mult(target, direction)
    win = roll < target if direction == "under" else roll > target
    return {"roll": roll, "win": win, "chance": chance, "mult": mult}


def verify_crash(server_seed, client_seed, nonce):
    return {"crash_point": crash_point(server_seed, client_seed, nonce)}


def verify_mines(server_seed, client_seed, nonce, n_mines):
    return {"mines": mines_layout(server_seed, client_seed, nonce, n_mines)}


def verify_plinko(server_seed, client_seed, nonce, rows):
    path = plinko_path(server_seed, client_seed, nonce, rows)
    return {"path": path, "bucket": plinko_bucket(path)}


if __name__ == "__main__":
    # 自检: 分布合理性 + 确定性
    import random
    sp = SeedPair("s" * 32, "client-demo")
    rolls = [dice_roll("s" * 32, "c", n) for n in range(2000)]
    assert 49.0 < sum(rolls) / len(rolls) < 51.0, f"dice 均值异常 {sum(rolls)/len(rolls)}"
    cps = [crash_point("s" * 32, "c", n) for n in range(4000)]
    inst = sum(1 for c in cps if c <= 1.0) / len(cps)
    assert 0.035 < inst < 0.046, f"秒崩比例 {inst}"        # 1/33(3.03%) + ~1% 公式边界 ≈ 4%
    below2 = sum(1 for c in cps if c < 2) / len(cps)
    assert 0.48 < below2 < 0.56, f"<2x 比例 {below2}"      # ~51%
    lay = mines_layout("s" * 32, "c", 7, 3)
    assert len(set(lay)) == 3 and all(0 <= x < 25 for x in lay)
    assert mines_mult(3, 1) == 1.125, mines_mult(3, 1)
    assert mines_mult(24, 1) == 24.75
    path = plinko_path("s" * 32, "c", 3, 16)
    assert len(path) == 16 and set(path) <= {0, 1}
    assert abs(plinko_mult(16, "high", 0) - 1000) < 1e-9
    h1 = dice_roll("abc", "xyz", 5)
    assert h1 == dice_roll("abc", "xyz", 5) and h1 != dice_roll("abc", "xyz", 6)
    print("[fair.py] 自检通过: dice 均值 / crash 秒崩率&分布 / mines / plinko / 确定性 ✓")
