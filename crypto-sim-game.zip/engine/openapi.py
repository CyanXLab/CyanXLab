# -*- coding: utf-8 -*-
"""CyanXPan 开放平台 —— 跨游戏资产桥接 + 开发者 API (正式版 v1)

设计目标:
  外部游戏 (别的项目) 注册应用后, 其游戏币可以:
    充值进本平台 web3 钱包 (bridge mint, 真实上链)
      → DEX swap 成 USDT → 充入交易所 → 合约/现货交易
      → 提币回钱包 → swap 回游戏币 → 提现烧毁 (bridge burn, 游戏侧入账)
  开发者也可以在本平台空投资产、开发测试 web3 应用, 无需任何真实链。

鉴权 (对齐主流交易所开放 API 惯例):
  X-DEV-KEY / X-TIMESTAMP / X-SIGNATURE
  signature = HMAC_SHA256(api_secret, f"{method}\n{path}\n{timestamp}\n{body}") 的 hex
  时间戳窗口 ±120s (真实服务器时间, 不受游戏内时间加速影响)

错误码风格对齐交易所:
  -1000 未知错误 / -1002 无权访问 / -1021 时间戳越窗 / -1100 参数缺失
  -2015 无效API密钥 / -2019 余额不足 / -2112 限流
"""
import hashlib
import hmac
import json
import os
import secrets
import time
from collections import deque

from .history_data import COIN_META

RESERVED_SYMBOLS = {"USDT", "SOL", "ETH", "DOGE", "BNB", "BTC", "GLD"}
SEED_SUPPLY = 1_000_000.0        # 桥接池初始流动性 (平台提供, 不可撤)
RATE_LIMIT_PER_MIN = 120         # 每密钥每分钟
TS_WINDOW = 120                  # 签名时间戳窗口 (真实秒)
GAS = 0.0                        # 开放接口 mint/burn 不收 gas (开发者友好)


class ApiError(Exception):
    def __init__(self, code, msg, http=400):
        super().__init__(msg)
        self.code = code
        self.msg = msg
        self.http = http


class DevPlatform:
    def __init__(self, chain):
        self.chain = chain
        self.apps = {}                 # app_id -> app dict
        self.by_key = {}               # api_key -> app_id
        self._rate = {}                # api_key -> [window_start, count]
        self._addr_idx = {}            # eth addr -> wid (懒建索引)
        self.path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "instance", "devapps.json")
        self.load()

    # ---------- 持久化 (独立于游戏存档, reset 不影响外部开发者) ----------
    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        data = {aid: {**a, "holders": list(a["holders"]),
                      "recent": list(a["recent"])[-50:]} for aid, a in self.apps.items()}
        with open(self.path, "w") as f:
            json.dump(data, f, ensure_ascii=False)

    def load(self):
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path) as f:
                data = json.load(f)
            for aid, a in data.items():
                a["recent"] = deque(a.get("recent", []), maxlen=50)
                a["holders"] = set(a.get("holders", []))
                self.apps[aid] = a
                self.by_key[a["api_key"]] = aid
            # 重建 DEX 池 (池状态随链存档, 缺失则按初始参数重建)
            for a in self.apps.values():
                pair = self._pair(a["symbol"])
                if pair not in self.chain.pools:
                    self._ensure_pool(a)
        except Exception as e:
            print("[DevPlatform] 加载失败, 使用全新注册表:", e)

    # ---------- 应用管理 ----------
    @staticmethod
    def _pair(symbol):
        return f"{symbol}/USDT"

    def _ensure_pool(self, app):
        pair = self._pair(app["symbol"])
        if pair in self.chain.pools:
            return
        seed_price = app.get("seed_price", 0.1)
        x = SEED_SUPPLY
        self.chain.pools[pair] = {"x": x, "y": x * seed_price, "coin": app["symbol"] + "USDT",
                                  "lp_fee": 0.003, "bridge": app["app_id"]}

    def register(self, name, symbol, full="", seed_price=0.1):
        symbol = (symbol or "").strip().upper()
        if not (2 <= len(symbol) <= 8 and symbol.isalnum()):
            raise ApiError(-1100, "代币符号需为 2-8 位字母/数字", 400)
        if symbol in RESERVED_SYMBOLS:
            raise ApiError(-1100, f"符号 {symbol} 为平台保留", 400)
        if any(a["symbol"] == symbol for a in self.apps.values()):
            raise ApiError(-1100, f"符号 {symbol} 已被其他应用注册", 400)
        if not (len(name or "") <= 24):
            raise ApiError(-1100, "应用名过长 (≤24 字)", 400)
        seed_price = min(max(float(seed_price or 0.1), 0.000001), 1000.0)
        app_id = "app-" + secrets.token_hex(4)
        app = {
            "app_id": app_id, "name": name.strip() or symbol, "symbol": symbol,
            "full": (full or "").strip()[:60], "seed_price": seed_price,
            "api_key": "dk_" + secrets.token_hex(16),
            "api_secret": "ds_" + secrets.token_hex(24),
            "created": time.time(), "status": "active",
            "minted": 0.0, "burned": 0.0, "airdropped": 0.0,
            "deposits": 0, "withdrawals": 0, "holders": set(),
            "recent": deque(maxlen=50),
        }
        self.apps[app_id] = app
        self.by_key[app["api_key"]] = app_id
        self._ensure_pool(app)
        self.save()
        return app

    def rotate_secret(self, app_id):
        app = self.apps.get(app_id)
        if not app:
            raise ApiError(-2015, "应用不存在", 404)
        app["api_secret"] = "ds_" + secrets.token_hex(24)
        self.save()
        return app

    def _app_by_key(self, key):
        aid = self.by_key.get(key or "")
        if not aid:
            raise ApiError(-2015, "无效的 API-Key", 401)
        app = self.apps[aid]
        if app["status"] != "active":
            raise ApiError(-1002, "应用已被停用", 403)
        return app

    # ---------- 鉴权 / 限流 ----------
    def check_rate(self, api_key):
        now = time.time()
        win = self._rate.get(api_key)
        if not win or now - win[0] >= 60:
            self._rate[api_key] = [now, 1]
            return
        win[1] += 1
        if win[1] > RATE_LIMIT_PER_MIN:
            raise ApiError(-2112, f"触发限流 ({RATE_LIMIT_PER_MIN} req/min), 请稍后重试", 429)

    def verify_auth(self, method, path, timestamp, sig, body_str, api_key):
        self.check_rate(api_key)
        app = self._app_by_key(api_key)
        try:
            ts = int(float(timestamp))
        except (TypeError, ValueError):
            raise ApiError(-1100, "时间戳缺失/非法", 400)
        if abs(time.time() * 1000 - ts) > TS_WINDOW * 1000 and abs(time.time() - ts) > TS_WINDOW:
            raise ApiError(-1021, "时间戳超出同步窗口 (±120s)", 400)
        expect = hmac.new(app["api_secret"].encode(),
                          f"{method}\n{path}\n{timestamp}\n{body_str}".encode(),
                          hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expect, (sig or "").lower()):
            raise ApiError(-1022, "签名不匹配 (Signature does not match)", 401)
        return app

    # ---------- 钱包地址 ----------
    def _wid_by_addr(self, addr):
        if not addr:
            raise ApiError(-1100, "缺少 user_address", 400)
        wid = self._addr_idx.get(addr)
        if wid and wid in self.chain.wallets:
            return wid
        for wid, w in self.chain.wallets.items():
            if w["eth"].lower() == addr.lower() or wid == addr:
                self._addr_idx[addr] = wid
                return wid
        raise ApiError(-1101, "平台钱包地址不存在 (用户需先在本平台创建钱包)", 400)

    def _credit(self, app, wid, amount, kind, note):
        w = self.chain.wallets[wid]
        w["balances"][app["symbol"]] = w["balances"].get(app["symbol"], 0.0) + amount
        tx = self.chain.submit_tx(kind, f"ext:{app['symbol']}", w["eth"], amount,
                                  coin=app["symbol"], note=note)
        app["recent"].append({"t": time.time(), "kind": kind, "addr": w["eth"],
                              "amount": amount, "hash": tx["hash"]})
        return tx

    # ---------- 桥接核心 ----------
    def deposit(self, app, addr, amount):
        amount = round(float(amount), 6)
        if amount <= 0 or amount > 1e12:
            raise ApiError(-1100, "金额非法", 400)
        wid = self._wid_by_addr(addr)
        tx = self._credit(app, wid, amount, "bridge_mint", f"{app['name']} 跨游戏充值")
        app["minted"] = round(app["minted"] + amount, 6)
        app["deposits"] += 1
        app["holders"].add(wid)
        self.save()
        return {"tx_hash": tx["hash"], "symbol": app["symbol"], "amount": amount,
                "credited": True, "confirmations_needed": self.chain_confirmations()}

    def withdraw(self, app, addr, amount):
        amount = round(float(amount), 6)
        if amount <= 0 or amount > 1e12:
            raise ApiError(-1100, "金额非法", 400)
        wid = self._wid_by_addr(addr)
        w = self.chain.wallets[wid]
        if w["balances"].get(app["symbol"], 0.0) < amount:
            raise ApiError(-2019, "钱包余额不足 (先让玩家充值或在 DEX 买入)", 400)
        w["balances"][app["symbol"]] -= amount
        tx = self.chain.submit_tx("bridge_burn", w["eth"], f"ext:{app['symbol']}", amount,
                                  coin=app["symbol"], note=f"{app['name']} 跨游戏提现 (已销毁)")
        app["burned"] = round(app["burned"] + amount, 6)
        app["withdrawals"] += 1
        app["recent"].append({"t": time.time(), "kind": "bridge_burn", "addr": w["eth"],
                              "amount": amount, "hash": tx["hash"]})
        self.save()
        return {"tx_hash": tx["hash"], "symbol": app["symbol"], "amount": amount,
                "burned": True, "credit_to_player": True}

    def airdrop(self, app, addrs, amount):
        amount = round(float(amount), 6)
        if not isinstance(addrs, list) or not addrs:
            raise ApiError(-1100, "缺少空投地址列表 to[]", 400)
        if amount <= 0 or len(addrs) > 500:
            raise ApiError(-1100, "空投参数非法 (每批 ≤500 地址)", 400)
        results, failed = [], []
        for addr in addrs[:500]:
            try:
                wid = self._wid_by_addr(addr)
                tx = self._credit(app, wid, amount, "airdrop", f"{app['name']} 官方空投")
                app["airdropped"] = round(app["airdropped"] + amount, 6)
                app["holders"].add(wid)
                results.append({"address": addr, "tx_hash": tx["hash"]})
            except ApiError as e:
                failed.append({"address": addr, "code": e.code, "msg": e.msg})
        self.save()
        return {"airdropped": len(results), "failed": failed, "detail": results[:20]}

    def transfer(self, app, frm, to, amount):
        amount = round(float(amount), 6)
        if amount <= 0:
            raise ApiError(-1100, "金额非法", 400)
        wid_from = self._wid_by_addr(frm)
        wid_to = self._wid_by_addr(to)
        w = self.chain.wallets[wid_from]
        if w["balances"].get(app["symbol"], 0.0) < amount:
            raise ApiError(-2019, "付款方余额不足", 400)
        w["balances"][app["symbol"]] -= amount
        self.chain.wallets[wid_to]["balances"][app["symbol"]] = \
            self.chain.wallets[wid_to]["balances"].get(app["symbol"], 0.0) + amount
        tx = self.chain.submit_tx("transfer", self.chain.wallets[wid_from]["eth"],
                                  self.chain.wallets[wid_to]["eth"], amount,
                                  coin=app["symbol"], note=f"{app['name']} 链上转账")
        app["recent"].append({"t": time.time(), "kind": "transfer", "addr": w["eth"],
                              "amount": amount, "hash": tx["hash"]})
        self.save()
        return {"tx_hash": tx["hash"], "amount": amount}

    def balance(self, app, addr):
        wid = self._wid_by_addr(addr)
        w = self.chain.wallets[wid]
        pair = self._pair(app["symbol"])
        px = self.chain.pools[pair]["y"] / self.chain.pools[pair]["x"] if pair in self.chain.pools else 0
        qty = w["balances"].get(app["symbol"], 0.0)
        return {"address": w["eth"], "symbol": app["symbol"], "balance": round(qty, 6),
                "usd_value": round(qty * px, 2), "dex_price": round(px, 8),
                "platform_coins": {k: round(v, 6) for k, v in w["balances"].items() if v > 0}}

    def chain_confirmations(self):
        from .chain import CONFIRMATIONS
        return CONFIRMATIONS

    # ---------- 汇总 (开发者页) ----------
    def overview(self, wid=None):
        out = []
        for a in self.apps.values():
            pair = self._pair(a["symbol"])
            pool = self.chain.pools.get(pair, {})
            out.append({
                "app_id": a["app_id"], "name": a["name"], "symbol": a["symbol"],
                "full": a["full"], "created": a["created"], "status": a["status"],
                "api_key": a["api_key"],
                "api_secret": a["api_secret"],  # 平台即开发者后台, 直接展示 (可随时 rotate)
                "minted": a["minted"], "burned": a["burned"], "airdropped": a["airdropped"],
                "deposits": a["deposits"], "withdrawals": a["withdrawals"],
                "holders": len(a["holders"]),
                "dex_price": round(pool.get("y", 0) / pool.get("x", 1), 8) if pool else 0,
                "pool_usdt": round(pool.get("y", 0), 0) if pool else 0,
                "recent": list(a["recent"])[-10:],
            })
        return sorted(out, key=lambda x: -x["created"])

    # ---------------- 开放 API 供外部调用方使用的自描述信息 ----------------
    @staticmethod
    def api_meta():
        return {
            "name": "CyanXPan Open API", "version": "v1",
            "auth": "HMAC-SHA256(X-DEV-KEY / X-TIMESTAMP / X-SIGNATURE)",
            "sign_string": "{METHOD}\\n{PATH}\\n{TIMESTAMP}\\n{BODY}",
            "ts_window_sec": TS_WINDOW, "rate_limit_per_min": RATE_LIMIT_PER_MIN,
            "endpoints": [
                "GET  /api/v1/ping",
                "GET  /api/v1/time",
                "GET  /api/v1/app/info",
                "POST /api/v1/app/deposit   {user_address, amount}   # 外部游戏币 → 平台钱包",
                "POST /api/v1/app/withdraw  {user_address, amount}   # 平台钱包 → 外部游戏",
                "POST /api/v1/app/airdrop   {to: [addr...], amount}  # 官方空投",
                "POST /api/v1/app/transfer  {from, to, amount}       # 链上转账",
                "GET  /api/v1/app/balance?user_address=0x..          # 查询余额/估值",
            ],
        }

    def rebind(self, chain):
        """游戏重置 (reset_game 重建 SimChain) 后, 开发平台重新挂载新链并恢复桥接池"""
        self.chain = chain
        self._addr_idx = {}
        for a in self.apps.values():
            self._ensure_pool(a)
