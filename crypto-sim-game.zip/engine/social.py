# -*- coding: utf-8 -*-
"""社交放大仿真 —— KOL 喊单频道 + 虚拟玩家排行榜 (成瘾机制中的社会性奖赏线索).

KOL: 6 个性格鲜明的虚拟交易员, 行情联动发言 (暴涨晒单/暴跌喊抄底/装死/互相嘲讽),
     发出的"信号"可被玩家一键跟单, 每个 KOL 有真实历史胜率统计 —— 让玩家亲眼看到"大V也会翻车"。
排行榜: 24 个 AI 机器人玩家, 各有交易风格, 收益与真实模拟行情联动, 玩家混排其中 —— 社会比较压力。
"""
import random
import time

KOLS = [
    {"id": "laowang", "name": "币圈老王", "emoji": "🀄", "style": "trend", "bio": "十年老韭菜，主打趋势单", "color": "#f7931a"},
    {"id": "satoshix", "name": "Satoshi大侠", "emoji": "🥷", "style": "scalp", "bio": "5分钟战法创始人（自封）", "color": "#3f8cff"},
    {"id": "gemhunter", "name": "百倍猎人", "emoji": "🏹", "style": "shill", "bio": "只打山寨，梭哈主义", "color": "#14f195"},
    {"id": "quantqueen", "name": "量化女王", "emoji": "👸", "style": "quant", "bio": "数学不会骗人，会骗人的是人", "color": "#b78aff"},
    {"id": "budaoge", "name": "不倒翁哥", "emoji": "🪆", "style": "safe", "bio": "3x封顶，活着最重要", "color": "#2ebd85"},
    {"id": "leek", "name": "反指小韭", "emoji": "🥬", "style": "contrarian", "bio": "我说多你就空，感恩", "color": "#f6465d"},
]

BOT_NAMES = [
    "持仓过夜侠", "凌晨三点哥", "梭哈老太太", "止损？没听过", "基金亏麻了", "贷款炒币王",
    "Web3扫地僧", "合约小钢炮", "躺平吃息翁", "目 trend 党", "阴间K线侠", "马斯克嘴替",
    "清风徐来", "FOMO不断", "回本就跑", "永远差一步", "杠杆艺术家", "币安蒲公英",
    "温水煮青蛙", "韭菜观察员", "一点半睡", "梭哈一时爽", "利息还房贷", "稳健如狗",
]


class Social:
    def __init__(self, engine):
        self.engine = engine
        self.rng = random.Random(20260829)
        self.feed = []            # KOL 消息流
        self.signals = []         # 可跟单信号
        self.msg_id = 1
        # KOL 持仓与战绩
        self.kol_state = {}
        for k in KOLS:
            self.kol_state[k["id"]] = {
                "pos": None,          # {coin, side, lev, entry, opened_ts, sig_id}
                "wins": self.rng.randint(12, 40), "losses": self.rng.randint(15, 45),
                "last_speak": -9999, "cooldown": 0,
            }
        # 排行榜机器人
        self.bots = []
        styles = ["trend", "scalp", "shill", "quant", "safe", "contrarian", "yolo", "holder"]
        for i, name in enumerate(BOT_NAMES):
            style = styles[i % len(styles)]
            self.bots.append({
                "name": name, "style": style,
                "equity": 10000 * (0.4 + self.rng.random() ** 1.6 * 3.2),   # 初始分化
                "win_rate": 30 + self.rng.random() * 30,
                "trades": self.rng.randint(8, 90),
                "curve": [],
                "is_player": False,
            })
        self.hour_mark = -1

    # ---------- KOL 发言 ----------
    def _kline_regime(self):
        return self.engine.regime

    def _market_move_pct(self, sym):
        c = self.engine.coins[sym]
        return (c.price / c.close0_24 - 1) * 100

    def kol_speak(self, evts):
        eng = self.engine
        rng = self.rng
        mi = eng.minute_index
        for k in KOLS:
            st = self.kol_state[k["id"]]
            if mi - st["last_speak"] < 45 + rng.randint(0, 90):
                continue
            move = self._market_move_pct("BTCUSDT")
            sym = rng.choice(["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT"])
            sname = sym.replace("USDT", "")
            px = eng.coins[sym].price
            # 持仓中: 随盈亏发言
            if st["pos"]:
                p = st["pos"]
                c = eng.coins[p["coin"]]
                pnl = p["side"] * (c.price - p["entry"]) / p["entry"] * p["lev"] * 100
                if pnl > 25:
                    self._say(k, f"{p['coin'].replace('USDT','')} {p['lev']}x 多单已吃 {pnl:+.0f}%，跟上的兄弟扣个1，我直接拿到强平价反方向 🚀", sig=None)
                    st["last_speak"] = mi
                    self._close_kol_pos(st, win=True)
                    continue
                if pnl < -35:
                    self._say(k, f"止损了{sname}，这单当交学费。技术面没坏，中线继续看多，别恐慌 🙏", sig=None)
                    st["last_speak"] = mi
                    self._close_kol_pos(st, win=False)
                    continue
                continue
            # 空仓: 按风格生成信号
            if k["style"] == "trend":
                side = 1 if eng.regime == 0 else (-1 if eng.regime == 1 else rng.choice([1, -1]))
                lev = rng.choice([5, 10, 10, 20])
                tpl = [
                    f"BTC 站稳日线中枢，趋势没坏，{sname} 拉回就是机会，{lev}x 接多 📈",
                    f"趋势多单继续持有思路，{sname} 突破前高就追，{lev}x 不贪",
                ]
            elif k["style"] == "scalp":
                side = rng.choice([1, -1])
                lev = rng.choice([20, 30, 50])
                tpl = [
                    f"5分钟级别 {sname} 底背离，短线{('多' if side==1 else '空')}一手，{lev}x 快进快出 ⚡",
                    f"{sname} 插针到位，{('多' if side==1 else '空')}单上车，止损带好，{lev}x",
                ]
            elif k["style"] == "shill":
                if sname == "BTC":
                    continue
                side = 1
                lev = rng.choice([25, 50, 50, 100])
                tpl = [
                    f"庄家吸筹结束，{sname} 起飞前夜，{lev}x 梭哈，格局打开 🏹",
                    f"所有均线金叉，{sname} 就是你拿住翻身的币，{lev}x 干就完了",
                ]
            elif k["style"] == "quant":
                side = 1 if rng.random() < 0.5 else -1
                lev = rng.choice([3, 5, 8])
                tpl = [
                    f"模型信号：{sname} 未来1h 上行概率 {(55+rng.random()*12):.0f}%，{'多' if side==1 else '空'} {lev}x，纪律执行 🤖",
                    f"波动率收缩至历史 23 分位，做多波动率方向，{sname} {('多' if side==1 else '空')} {lev}x",
                ]
            elif k["style"] == "safe":
                side = 1 if eng.regime == 0 else -1
                lev = 3
                tpl = [
                    f"轻仓 {sname} {'多' if side==1 else '空'}，3x，亏了当没事发生，赚了请我喝咖啡 ☕",
                ]
            else:  # contrarian
                side = -1 if move > 2 else (1 if move < -2 else rng.choice([1, -1]))
                lev = rng.choice([10, 20])
                tpl = [
                    f"都看{'涨' if move>0 else '跌'}的时候我就说反话：{sname} 要{'跌' if move>0 else '涨'}，{'空' if side==-1 else '多'} {lev}x 反着干 🥬",
                ]
            sig_id = self.msg_id
            self._say(k, rng.choice(tpl), sig={
                "id": sig_id, "coin": sym, "side": side, "lev": lev,
                "entry": px, "margin_suggest": 200,
            })
            st["pos"] = {"coin": sym, "side": side, "lev": lev, "entry": px, "sig_id": sig_id}
            st["last_speak"] = mi

    def _say(self, k, text, sig):
        ev = {"id": self.msg_id, "kol": k["id"], "name": k["name"], "emoji": k["emoji"],
              "color": k["color"], "text": text, "t": self.engine.sim_time_str()}
        st = self.kol_state[k["id"]]
        ev["win_rate"] = round(st["wins"] / max(1, st["wins"] + st["losses"]) * 100)
        if sig:
            ev["signal"] = sig
            self.signals.append({"id": sig["id"], "kol": k["name"], "coin": sig["coin"],
                                 "side": sig["side"], "lev": sig["lev"], "entry": sig["entry"],
                                 "margin": sig["margin_suggest"],
                                 "result": None, "t": self.engine.sim_time_str()})
            if len(self.signals) > 40:
                self.signals.pop(0)
        self.msg_id += 1
        self.feed.append(ev)
        del self.feed[:-120]

    def _close_kol_pos(self, st, win):
        p = st["pos"]
        if p:
            for s in self.signals:
                if s["id"] == p["sig_id"] and s["result"] is None:
                    s["result"] = "win" if win else "loss"
        if win:
            st["wins"] += 1
        else:
            st["losses"] += 1
        st["pos"] = None

    def resolve_kol_positions(self):
        """每分钟检查 KOL 虚拟仓位的强平/止盈 (跟单参考胜率)"""
        eng = self.engine
        for k in KOLS:
            st = self.kol_state[k["id"]]
            p = st["pos"]
            if not p:
                continue
            c = eng.coins[p["coin"]]
            chg = (c.price / p["entry"] - 1) * p["side"] * p["lev"]
            hold = eng.minute_index - st["last_speak"]
            if chg <= -(100 / p["lev"]) * 0.85:
                self._close_kol_pos(st, win=False)
                self._say(k, f"{p['coin'].replace('USDT','')} 这单爆了…市场专治不服，休息两小时 🤡", sig=None)
                st["cooldown"] = eng.minute_index + 120
            elif chg >= 30 or hold > 600:
                self._close_kol_pos(st, win=chg > 0)
                if chg > 0:
                    self._say(k, f"{p['coin'].replace('USDT','')} 落袋 +{chg:.0f}%，分批止盈，落袋为安 ✅", sig=None)

    def follow_signal(self, sig_id):
        for s in self.signals:
            if s["id"] == sig_id and s["result"] is None:
                return {"coin": s["coin"], "side": s["side"], "lev": s["lev"], "margin": s["margin"], "entry": s["entry"]}
        return None

    def snapshot(self):
        kols = []
        for k in KOLS:
            st = self.kol_state[k["id"]]
            kols.append({
                "id": k["id"], "name": k["name"], "emoji": k["emoji"], "color": k["color"],
                "bio": k["bio"], "win_rate": round(st["wins"] / max(1, st["wins"] + st["losses"]) * 100),
                "wins": st["wins"], "losses": st["losses"],
                "has_pos": st["pos"] is not None,
            })
        return {"feed": self.feed[-60:], "kols": kols, "signals": list(reversed(self.signals[-25:]))}

    # ---------- 排行榜 ----------
    def bots_hour(self, marks, regime):
        """每模拟小时: 机器人按风格+行情更新收益"""
        mi = self.engine.minute_index
        if mi == self.hour_mark:
            return
        self.hour_mark = mi
        regime_ret = {0: 0.012, 1: -0.010, 2: 0.0008}[regime]
        rng = self.rng
        for b in self.bots:
            noise = rng.gauss(0, 0.028)
            style_bias = {
                "trend": 1.2 if regime == 0 else 0.7, "scalp": 1.0, "shill": 1.6 if regime != 1 else 0.3,
                "quant": 0.55, "safe": 0.4, "contrarian": 1.1 if regime == 1 else 0.8,
                "yolo": 2.2 * rng.choice([1, 1, -0.8]), "holder": 0.9 if regime != 1 else 0.5,
            }.get(b["style"], 1.0)
            b["equity"] *= (1 + (regime_ret * style_bias + noise) * 0.85)
            b["equity"] = max(80, b["equity"])
            b["trades"] += rng.randint(0, 3)
            if rng.random() < 0.5:
                b["win_rate"] = min(95, max(8, b["win_rate"] + rng.choice([-1.5, 1.5])))
            b["curve"].append(round(b["equity"], 0))
            del b["curve"][:-72]

    def leaderboard(self, player_equity, player_name="你"):
        rows = [{"name": b["name"], "equity": b["equity"], "roi": (b["equity"] / 10000 - 1) * 100,
                 "win_rate": b["win_rate"], "trades": b["trades"], "curve": b["curve"][-48:],
                 "is_player": False, "style": b["style"]} for b in self.bots]
        rows.append({"name": player_name, "equity": player_equity, "roi": (player_equity / 10000 - 1) * 100,
                     "win_rate": None, "trades": None, "curve": [], "is_player": True, "style": "player"})
        rows.sort(key=lambda r: -r["equity"])
        for i, r in enumerate(rows):
            r["rank"] = i + 1
        return rows

    # ---------- 玩家动态广播 (爆仓/暴富自动发帖, 社交传播) ----------
    def broadcast(self, name, text, emoji="\U0001F4E3", color="#f0b90b"):
        """玩家大事记进入全服社交墙 (KOL 流), 打造币圈式围观/图馆文化"""
        ev = {"id": self.msg_id, "kol": "broadcast", "name": (name or "匿名玩家")[:16],
              "emoji": emoji, "color": color, "text": text,
              "t": self.engine.sim_time_str(), "win_rate": None, "broadcast": True}
        self.msg_id += 1
        self.feed.append(ev)
        del self.feed[:-120]
