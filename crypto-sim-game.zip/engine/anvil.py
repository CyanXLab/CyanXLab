# -*- coding: utf-8 -*-
"""Anvil 真实 EVM 节点管理器 —— 「更真实」模式

把 Foundry 的 anvil (真实以太坊模拟器) 作为外挂节点接入:
- 一键启动/停止, Flask 子进程托管 (服务器退出自动回收)
- /anvil-rpc 透明代理: 任何 web3 工具 (web3.py / ethers / cast / forge) 都可直接连
- 与站内 mini 链 (chain.py, chainId 1337) 并存: 造真实 EVM 字节码合约/opcode 执行走 anvil
"""
import json
import os
import subprocess
import time
import urllib.request

ANVIL_BIN = os.environ.get("ANVIL_BIN", "/home/z/.foundry/bin/anvil")
ANVIL_PORT = int(os.environ.get("ANVIL_PORT", "8546"))
ANVIL_CHAIN_ID = 31337          # foundry 默认
RPC_TIMEOUT = 8


class AnvilNode:
    def __init__(self):
        self.proc = None
        self.started_at = None
        self.version = None
        self.log_tail = []

    # ---------- 生命周期 ----------
    def installed(self):
        return os.path.exists(ANVIL_BIN)

    def running(self):
        return self.proc is not None and self.proc.poll() is None

    def start(self):
        if not self.installed():
            return False, "anvil 未安装 — 安装: curl -L https://foundry.paradigm.xyz | bash && foundryup"
        if self.running():
            return True, "已在运行"
        try:
            self.proc = subprocess.Popen(
                [ANVIL_BIN, "--port", str(ANVIL_PORT), "--chain-id", str(ANVIL_CHAIN_ID),
                 "--block-time", "1", "--silent", "--no-request-size-limit"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                preexec_fn=getattr(os, "setsid", None))
        except Exception as e:
            self.proc = None
            return False, f"启动失败: {e}"
        self.started_at = time.time()
        ok, msg = self._wait_ready()
        if not ok:
            self.stop()
            return False, msg
        v = self.call("web3_clientVersion")
        self.version = v.get("result", "anvil") if isinstance(v, dict) else "anvil"
        return True, f"anvil 就绪 @ 127.0.0.1:{ANVIL_PORT} (chainId {ANVIL_CHAIN_ID})"

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
            except Exception:
                pass
        self.proc = None
        self.started_at = None
        return True, "已停止"

    def _wait_ready(self, timeout=12):
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self.proc and self.proc.poll() is not None:
                return False, "anvil 进程异常退出"
            try:
                r = self.call("eth_chainId")
                if isinstance(r, dict) and "result" in r:
                    return True, "ok"
            except Exception:
                pass
            time.sleep(0.4)
        return False, "anvil 就绪超时"

    # ---------- RPC ----------
    def call(self, method, params=None):
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or []}
        req = urllib.request.Request(
            f"http://127.0.0.1:{ANVIL_PORT}", data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=RPC_TIMEOUT) as resp:
            return json.loads(resp.read().decode())

    def proxy(self, payload):
        """透明代理 (支持单条与 batch)"""
        req = urllib.request.Request(
            f"http://127.0.0.1:{ANVIL_PORT}", data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=RPC_TIMEOUT) as resp:
            return json.loads(resp.read().decode())

    # ---------- 状态 ----------
    def status(self):
        if not self.installed():
            return {"installed": False, "running": False,
                    "hint": "安装: curl -L https://foundry.paradigm.xyz | bash && foundryup"}
        st = {"installed": True, "bin": ANVIL_BIN, "running": self.running(),
              "port": ANVIL_PORT, "chain_id": ANVIL_CHAIN_ID,
              "endpoints": {"http": f"http://127.0.0.1:{ANVIL_PORT}",
                            "site_proxy": "/anvil-rpc"},
              "cast_example": f"cast ETHlocalhost --rpc-url http://127.0.0.1:{ANVIL_PORT} blockNumber",
              "uptime_s": int(time.time() - self.started_at) if self.started_at else 0}
        if self.running():
            try:
                st["version"] = self.version or "anvil"
                st["height"] = int(self.call("eth_blockNumber")["result"], 16)
                st["gas_price"] = int(self.call("eth_gasPrice")["result"], 16)
                st["accounts"] = len(self.call("eth_accounts")["result"])
            except Exception as e:
                st["error"] = str(e)[:120]
        return st
