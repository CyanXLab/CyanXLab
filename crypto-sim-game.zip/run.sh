#!/usr/bin/env bash
# CoinSprint 一键启动 (Linux / macOS)
cd "$(dirname "$0")"
PY=$(command -v python3.13 || command -v python3 || command -v python)
echo "使用解释器: $PY"
$PY -m pip install -q -r requirements.txt || $PY -m pip install -q --user --break-system-packages -r requirements.txt
$PY app.py
