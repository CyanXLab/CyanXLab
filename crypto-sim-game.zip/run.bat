@echo off
rem CoinSprint 一键启动 (Windows)
cd /d %~dp0
python -m pip install -q -r requirements.txt
python app.py
pause
